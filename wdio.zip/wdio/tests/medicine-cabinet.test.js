const { describeWithThemes } = require('../support/utilities');
const drugName = 'Levothyroxine Sodium';

const verifyMedCabMembers = (...members) => {
  const memberInfos = $$('[data-component="MedicineCabinetMemberInfo"]');

  expect(memberInfos.length).toEqual(members.length);

  members.forEach((member, i) => {
    expect(
      memberInfos[i]
        .getText()
        .toUpperCase()
        .includes(member.toUpperCase())
    ).toBeTruthy();
  });
};

const verifyAllMedCabMembers = () => {
  // Wait for "Show Medications For:" dropdown
  const showMedicationsSelect = $('[data-component="Dropdown"]').$('select');
  showMedicationsSelect.waitForDisplayed();

  browser.waitUntil(() => showMedicationsSelect.$$('option')[0].getText() === 'MEMBER KITCHENSINK');

  // Get the member options from the dropdown
  const memberOptions = showMedicationsSelect.$$('option');

  const primaryMemberOption = memberOptions[0];
  const authorizedMemberOption = memberOptions[1];
  const allMembersOption = memberOptions[2];

  // Verify that primary member is selected by default
  expect(showMedicationsSelect.getValue()).toBe(primaryMemberOption.getValue());

  // Verify that only one med cab is displayed and the name of the primary member is present
  verifyMedCabMembers(primaryMemberOption.getText());

  // Select authorized member in the dropdown
  showMedicationsSelect.selectByAttribute('value', authorizedMemberOption.getValue());

  // Verify that only one med cab is displayed and the name of the authorized member is present
  verifyMedCabMembers(authorizedMemberOption.getText());

  // Select all members in the dropdown
  showMedicationsSelect.selectByAttribute('value', allMembersOption.getValue());

  // Verify that two med cabs are displayed, and the names of the primary member and authorized member are present
  verifyMedCabMembers(primaryMemberOption.getText(), authorizedMemberOption.getText());
};

describeWithThemes('Medicine Cabinet', () => {
  beforeEach(() => {
    browser.waitForMedicineCabinetToBeLoaded();
  });

  afterEach(() => browser.deleteCookies());

  it('will validate navigation to proper use page', () => {
    const card = browser.getMedicineCard(drugName);

    // Click drug name
    card.$('[data-component="MedicineCabinetCardDrugName"]').click();

    // Verify proper use page appears and drug name matches
    $('[data-component="DrugTabProperUse"][aria-selected="true"]').waitForDisplayed();
    expect(
      $('[data-component="DrugName"]')
        .getText()
        .includes(drugName)
    ).toBeTruthy();

    // Click back button
    browser.back();

    // Verify nav back to med cab was successful
    browser.waitForMedicineCabinetToBeLoaded();
  });

  it('will validate navigation to pricing page', () => {
    const card = browser.getMedicineCard(drugName);

    // Click "Get Pricing" button
    card.$('[data-component="GetPricing"]').click();

    // Verify pricing page appears and drug name matches
    $('[data-component="DrugTabPrices"][aria-selected="true"]').waitForDisplayed();
    expect(
      $('[data-component="DrugName"]')
        .getText()
        .includes(drugName)
    ).toBeTruthy();

    // Click back button and verify nav back to med cab was successful
    browser.back();
    browser.waitForMedicineCabinetToBeLoaded();
  });

  it('will validate correct med cabs are displayed on launchpad', () => {
    // Verify all med cab member options
    verifyAllMedCabMembers();
  });

  it('will validate correct med cabs are displayed on drug search page', () => {
    // Navigate to find & price page
    const drugSearchButton = $('#DrugSearchButton');
    browser.waitForElementThenClick(drugSearchButton);

    // Verify the navigation
    $('[data-component="Typeahead"]').waitForDisplayed();

    // Verify all med cab member options
    verifyAllMedCabMembers();
  });
});
