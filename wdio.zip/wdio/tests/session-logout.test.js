const { describeWithSingleTheme } = require('../support/utilities');
let minorViolations = [];
let violations = [];

describe('Session logout', () => {
  afterEach(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'session-logout-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'session-logout-accessibilty-violations-report.json');
  });

  describeWithSingleTheme('uhc', 'Session logout', () => {
    it('displays "continue" link', () => {
      browser.url('session-logout');

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      const logoutContinueLink = $('[data-component="SessionLogoutContinueLink"]');
      logoutContinueLink.waitForDisplayed();
      expect(logoutContinueLink.getAttribute('href')).toContain('myuhc.com');
    });
  });

  describeWithSingleTheme('advantage', 'Session logout', () => {
    it('displays "continue" link', () => {
      browser.url('session-logout');

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      const logoutContinueLink = $('[data-component="SessionLogoutContinueLink"]');
      logoutContinueLink.waitForDisplayed();
      expect(logoutContinueLink.getAttribute('href')).toContain('rally-dev.com');
    });
  });
});
