const i18n = require('../../../src/i18n/all');
const { describeWithThemes } = require('../../support/utilities');

let minorViolations = [];
let violations = [];

describeWithThemes('Refills - Order Summary', () => {
  beforeEach(() => {
    browser.nagivateToRefillsDirectly();
  });

  afterAll(() => {
    browser.deleteCookies();

    browser.createA11yViolationReports(violations, minorViolations, 'refills-order-summary');
  });

  it('will see the shipping cost added to the total', () => {
    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    const shippingMethodOptions = i18n.refills.medications.shippingMethods.options;

    $('[data-component="RefillsShipingMethodDropdown"]').selectByVisibleText(
      shippingMethodOptions.standard.replace('{{cost}}', 'Free')
    );

    expect($('[data-component="RefillsOrderSummaryMedicationTotal"]').getText()).toEqual('$20.00');
    expect($('[data-component="RefillsOrderSummaryShippingTotal"]').getText()).toEqual('FREE');
    expect($('[data-component="RefillsOrderSummaryTotal"]').getText()).toEqual('$20.00');

    $('[data-component="RefillsShipingMethodDropdown"]').selectByVisibleText(
      shippingMethodOptions.twoDay.replace('{{cost}}', '$6.00')
    );

    expect($('[data-component="RefillsOrderSummaryMedicationTotal"]').getText()).toEqual('$20.00');
    expect($('[data-component="RefillsOrderSummaryShippingTotal"]').getText()).toEqual('$6.00');
    expect($('[data-component="RefillsOrderSummaryTotal"]').getText()).toEqual('$26.00');

    $('[data-component="RefillsShipingMethodDropdown"]').selectByVisibleText(
      shippingMethodOptions.expedited.replace('{{cost}}', '$12.50')
    );

    expect($('[data-component="RefillsOrderSummaryMedicationTotal"]').getText()).toEqual('$20.00');
    expect($('[data-component="RefillsOrderSummaryShippingTotal"]').getText()).toEqual('$12.50');
    expect($('[data-component="RefillsOrderSummaryTotal"]').getText()).toEqual('$32.50');
  });
});
