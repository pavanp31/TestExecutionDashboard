const { describeWithThemes } = require('../support/utilities');
let minorViolations = [];
let violations = [];

describeWithThemes('Home page', () => {
  beforeEach(() => {
    browser.waitForMedicineCabinetToBeLoaded();
  });

  afterEach(() => browser.deleteCookies());

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'home-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'home-accessibilty-violations-report.json');
  });

  it('has "Pharmacy" title', () => {
    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    expect(browser.getTitle()).toEqual('Pharmacy');
  });

  it('will hide View Current Medications popup if med cab is visible', () => {
    browser.setWindowSize(1300, 300); // ensure window is short enough to show scroll link

    const scrollToLink = $('[data-component="ScrollToSections"]');
    scrollToLink.waitForDisplayed();

    $('[data-component="MedicineCabinet"]').waitForDisplayed();
    $('[data-component="MedicineCabinet"]').scrollIntoView({ block: 'center' });

    browser.waitUntil(() => !scrollToLink.isDisplayed());

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });
});
