const { describeWithThemes } = require('../support/utilities');
const i18n = require('../../src/i18n/all');
let minorViolations = [];
let violations = [];

// current order numbers in kamaji used for testing
// 300384013-2: processing order
// 300384231-1: preparing order
// 222222-1: shipped order
// 666666-1: request placed order
// 777777-1: order delivered
// 666666-2: Preparing Medication: Preparing for shipment

// scroll to the selected medicine, verify order status and view status
const verifyOrderStatus = ({ medicineName, orderStatus, additionalInfo }) => {
  // Get all cards and then filter them by the next value found in
  // the drug name to find the medicine cabinet card that we want.
  const card = browser.getMedicineCard(medicineName);

  card.scrollIntoView({ block: 'center' });

  expect(
    card
      .$('[data-component="MedicineCabinetCardOrderStatus"]')
      .getText()
      .toLowerCase()
  ).toEqual(orderStatus);
  expect(card.$('[data-component="MedicineCabinetCardOrderFulfiller"]').getText()).toEqual(additionalInfo);

  const viewStatusButton = card.$('[data-component="ViewStatusButton"]');

  browser.waitForElementThenClick(viewStatusButton);
  $('.order-status-page-title').waitForDisplayed();

  browser.checkPageAccessibiltyViolations(violations, minorViolations);
};

// at order status page, verify title and delivery date
const verifyDeliveryDate = ({ deliveryDatePattern, deliveryDate }) => {
  expect($('.delivery-date').getText()).toMatch(new RegExp(deliveryDatePattern + deliveryDate));
};

// at order status page, verify progress bar
const verifyProgressBar = ({ ariaLabel, currentStepText, currentStepSubText }) => {
  const bar = $('[data-component="OrderStatusProgressBarImageContainer"]');

  bar.waitForDisplayed();

  expect(bar.getAttribute('aria-label')).toContain(ariaLabel);

  const segment = $('[data-component="OrderStatusProgressBarContainer"]').$('[data-current="true"]');

  expect(segment.getText()).toContain(currentStepText);
  expect(segment.getText()).toContain(currentStepSubText);
};

describeWithThemes('Order Status', () => {
  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'order-status-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'order-status-accessibilty-violations-report.json');
  });

  beforeEach(() => {
    browser.waitForMedicineCabinetToBeLoaded();
  });

  afterEach(() => browser.deleteCookies());

  it('will verify document title and page heading', () => {
    browser.url('orders/status?orderNumber=300384013-2');

    const title = $('.order-status-page-title');

    title.waitForDisplayed();

    expect(browser.getTitle()).toEqual('Order Status | Pharmacy');

    expect(title.isExisting()).toBeTruthy();
    expect(title.getText()).toContain(i18n.orders.status.pageTitle);
  });

  it('will see the page with order processing state', () => {
    verifyOrderStatus({
      medicineName: 'Bydureon BCise',
      orderStatus: i18n.medicineCabinet.order.status.OrderProcessingRequestReceived,
      additionalInfo: i18n.medicineCabinet.order.filledByOptumRx
    });

    verifyDeliveryDate({
      deliveryDatePattern: i18n.orders.status.deliveryStatus.expectedDelivery.concat(': '),
      deliveryDate: i18n.orders.status.deliveryStatus.pending
    });

    verifyProgressBar({
      ariaLabel: i18n.orders.status.progressBar.accessibility.OrderProcessingConfirmingWithYourHealthCareProvider,
      currentStepText: i18n.orders.status.progressBar.orderProcessing,
      currentStepSubText: i18n.orders.status.progressBar.statusHelperText.confirming
    });

    // Verify page is visible to screen readers
    expect($('#root').getAttribute('aria-hidden')).toBeFalsy();
  });

  it('will see the page with preparing -> Pharmacist is Reviewing order state', () => {
    verifyOrderStatus({
      medicineName: 'Digox',
      orderStatus: i18n.medicineCabinet.order.status.PreparingMedicationOptumRxPharmacistIsReviewing,
      additionalInfo: i18n.medicineCabinet.order.filledByOptumRx
    });

    verifyDeliveryDate({
      deliveryDatePattern: i18n.orders.status.deliveryStatus.expectedDelivery.concat(': '),
      deliveryDate: i18n.orders.status.deliveryStatus.pending
    });

    verifyProgressBar({
      ariaLabel: i18n.orders.status.progressBar.accessibility.PreparingMedicationOptumRxPharmacistIsReviewing,
      currentStepText: i18n.orders.status.progressBar.preparingMedication,
      currentStepSubText: i18n.orders.status.progressBar.statusHelperText.reviewing
    });
  });

  it('will see the page with delivered order state', () => {
    verifyOrderStatus({
      medicineName: 'Simvastatin',
      orderStatus: i18n.medicineCabinet.order.status.Delivered,
      additionalInfo: i18n.medicineCabinet.order.filledByOptumRx
    });

    verifyDeliveryDate({
      deliveryDatePattern: i18n.orders.status.deliveryStatus.delivered.concat(':.'),
      deliveryDate: '01/01/2020'
    });

    verifyProgressBar({
      ariaLabel: i18n.orders.status.progressBar.accessibility.Delivered,
      currentStepText: i18n.orders.status.progressBar.delivered,
      currentStepSubText: '01/01/2020'
    });
  });

  it('will see the page with shipped order state', () => {
    verifyOrderStatus({
      medicineName: 'Fluconazole',
      orderStatus: i18n.medicineCabinet.order.status.Shipped,
      additionalInfo: i18n.medicineCabinet.order.filledByOptumRx
    });

    verifyDeliveryDate({
      deliveryDatePattern: i18n.orders.status.deliveryStatus.expectedDelivery.concat(':.'),
      deliveryDate: '08/20/2020'
    });

    verifyProgressBar({
      ariaLabel: i18n.orders.status.progressBar.accessibility.Shipped,
      currentStepText: i18n.orders.status.progressBar.inTransit,
      currentStepSubText: i18n.orders.status.progressBar.statusHelperText.shipped
    });
  });

  it('will see the page with request placed order state', () => {
    verifyOrderStatus({
      medicineName: 'Acetaminophen',
      orderStatus: i18n.medicineCabinet.order.status.OrderProcessingRequestPlaced,
      additionalInfo: i18n.medicineCabinet.order.filledByOptumRx
    });

    verifyDeliveryDate({
      deliveryDatePattern: i18n.orders.status.deliveryStatus.expectedDelivery.concat(': '),
      deliveryDate: i18n.orders.status.deliveryStatus.pending
    });

    verifyProgressBar({
      ariaLabel: i18n.orders.status.progressBar.accessibility.OrderProcessingRequestPlaced,
      currentStepText: i18n.orders.status.progressBar.orderProcessing,
      currentStepSubText: i18n.orders.status.progressBar.statusHelperText.placed
    });
  });

  it('will see the page with PPREPARING-MEDICATION -> PREPARING-FOR-SHIPMENT order state', () => {
    verifyOrderStatus({
      medicineName: 'Dapsone',
      orderStatus: i18n.medicineCabinet.order.status.PreparingMedicationPreparingForShipment,
      additionalInfo: i18n.medicineCabinet.order.filledByOptumRx
    });

    verifyDeliveryDate({
      deliveryDatePattern: i18n.orders.status.deliveryStatus.expectedDelivery.concat(': '),
      deliveryDate: i18n.orders.status.deliveryStatus.pending
    });

    verifyProgressBar({
      ariaLabel: i18n.orders.status.progressBar.accessibility.PreparingMedicationPreparingForShipment,
      currentStepText: i18n.orders.status.progressBar.preparingMedication,
      currentStepSubText: i18n.orders.status.progressBar.statusHelperText.preparing
    });
  });

  it('will see missing page error for bad order', () => {
    browser.url('orders/status?orderNumber=bad-order');

    $('[data-component="PageNotFound"]').waitForDisplayed();

    expect(browser.getTitle()).toEqual('Error 404 Page Not Found | Pharmacy');

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });
});
