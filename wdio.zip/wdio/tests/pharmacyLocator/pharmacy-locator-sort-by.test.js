const { describeWithThemes } = require('../../support/utilities');
let minorViolations = [];
let violations = [];

const sortPharmacySearchResults = sortBy => {
  // scroll back to the top of the page
  $('[data-component="BackButton"]').scrollIntoView({ block: 'center' });

  const dropdown = $('[data-component="PharmacySearchHeader"] select');

  browser.waitForElementThenClick(dropdown);

  // select and click the sorting option
  dropdown
    .$$('option')
    .find(sortOption => sortOption.getText().includes(sortBy))
    .click();

  // wait for the results
  browser.waitForPharmacyLocatorPageToBeLoaded();

  // return pharmacy names from search results
  return $$('[data-component="PharmacySearchContentItem"]').map(item =>
    item.$('[data-component="PharmacyLink"]').getText()
  );
};

describeWithThemes('Pharmacy Locator - Sort By', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'pharmacy-name-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'pharmacy-name-accessibilty-violations-report.json');
  });

  it('will sort pharmacies by distance', () => {
    const distances = $$('.pharmacy-distance').map(item => {
      const aElement = item.$('a');

      // not all pharmacies have miles away element
      if (aElement) {
        const miles = aElement.getText().replace(/[^0-9.]/g, '');
        return parseFloat(miles) || 0.0;
      }
    });

    const sortedDistances = [...distances].sort((a, b) => a - b);

    expect(distances).toEqual(sortedDistances);
  });

  it('will sort pharmacies by name in ascending order', () => {
    const results = sortPharmacySearchResults('A-Z');
    const sortedResults = [...results].sort();

    expect(results).toEqual(sortedResults);
  });

  it('will sort pharmacies by name in descending order', () => {
    const results = sortPharmacySearchResults('Z-A');
    const sortedResults = [...results].sort().reverse();

    expect(results).toEqual(sortedResults);
  });
});
