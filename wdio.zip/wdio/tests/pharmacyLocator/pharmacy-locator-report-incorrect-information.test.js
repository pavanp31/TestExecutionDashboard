const { describeWithThemes } = require('../../support/utilities');
let minorViolations = [];
let violations = [];

describeWithThemes('Pharmacy Locator - Report Incorrect Information', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'pharmacy-report-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'pharmacy-report-accessibilty-violations-report.json');
  });

  it('will see report incorrect information form', () => {
    const npi = '1598787202';

    browser.selectTypeaheadAddOnOption('NPI');

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    browser.doTypeaheadSearchAndSubmit(npi);

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // validates the npi # on the pharmacy list title
    expect(browser.getPharmacyQueryTypeIdentifierFromSearch()).toContain(npi);

    // gets the Pharmacy Name from the npi search list and verifies it matches on the details page
    const pharmacyName = browser.getPharmacyNameFromSearch();

    browser.goToPharmacyDetailsFromSearch();

    browser.waitForPharmacyDetailsPageToBeLoaded();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    expect(browser.getPharmacyNameFromDetails()).toContain(pharmacyName);

    // navigates to report incorrect information modal
    $('[data-component="ReportIncorrectInformationButton"]').click();

    $('[id="ReportIncorrectInformationModalHeader"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });
});
