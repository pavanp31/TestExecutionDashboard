const { describeWithThemes } = require('../../support/utilities');
const keyCodes = require('../../support/keyCodes');

describeWithThemes('Pharmacy Locator - Accessibility', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();
  });

  it('will skip to main content', () => {
    const button = $('#rxSkipToMainContent');

    browser.execute(el => el.focus(), button);

    expect(button.isFocused()).toBeTruthy();

    browser.keys(keyCodes.enter);

    expect($('#firstPharmacySearchResultListItem').isFocused()).toBeTruthy();
  });
});
