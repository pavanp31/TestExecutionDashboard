const { describeWithThemes } = require('../../support/utilities');
const i18n = require('../../../src/i18n/pharmacy');

let minorViolations = [];
let violations = [];

describeWithThemes('Pharmacy Locator - Search by State License', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(
      minorViolations,
      'pharmacy-state-license-minor-accessibility-violations-report.json'
    );
    browser.createViolationsReport(violations, 'pharmacy-state-license-accessibilty-violations-report.json');
  });

  it('will select pharmacy by State License and validate query selection', () => {
    const stateLicense = '054013330';

    browser.selectTypeaheadAddOnOption(i18n.pharmacies.search.queryType.stateLicense);

    // Searches for the pharmacy using the State License number
    $(`[placeholder="${i18n.pharmacies.search.input.placeholders.stateLicense}"]`).waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    browser.doTypeaheadSearchAndSubmit(stateLicense);

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // validates the state License # on the pharmacy list title
    expect(browser.getPharmacyQueryTypeIdentifierFromSearch()).toContain(stateLicense);

    // gets the Pharmacy Name from the State License search list and verifies it matches on the details page
    const pharmacyName = browser.getPharmacyNameFromSearch();

    browser.goToPharmacyDetailsFromSearch();

    browser.waitForPharmacyDetailsPageToBeLoaded();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    expect(browser.getPharmacyNameFromDetails()).toContain(pharmacyName);
  });

  it('will search by State License and confirm query type and value are in URL', () => {
    const stateLicense = '054013330';

    browser.selectTypeaheadAddOnOption(i18n.pharmacies.search.queryType.stateLicense);

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // Searches for the pharmacy using the NPI number
    $(`[placeholder="${i18n.pharmacies.search.input.placeholders.stateLicense}"]`).waitForDisplayed();

    browser.doTypeaheadSearchAndClickOnResult(stateLicense);

    expect(browser.getUrl()).toContain('queryType=stateLicense');
    expect(browser.getUrl()).toContain(`term=${stateLicense}`);
  });
});
