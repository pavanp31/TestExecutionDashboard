const i18n = require('../../../src/i18n/pharmacy');
const { describeWithThemes } = require('../../support/utilities');

let minorViolations = [];
let violations = [];

describeWithThemes('Pharmacy Locator - Search', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createA11yViolationReports(violations, minorViolations, 'pharmacy-locator-search');
  });

  it('will not see search results when typing search term', () => {
    browser.doTypeaheadSearch('cvs');

    expect($('[data-component="PharmacySearchResults"]').isDisplayed()).toBeFalsy();
  });

  it('will search by State License then go back and reset search input', () => {
    browser.goToNextPage();

    $('[data-component="PharmacySearchResults"]').waitForDisplayed();

    expect(browser.getUrl()).toContain('page=2');

    browser.selectTypeaheadAddOnOption(i18n.pharmacies.search.queryType.stateLicense);

    // Searches for the pharmacy using the State License number
    $(`[placeholder="${i18n.pharmacies.search.input.placeholders.stateLicense}"]`).waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    browser.doTypeaheadSearchAndSubmit('054013330');

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    expect(browser.getUrl()).not.toContain('page');
    expect(browser.getUrl()).toContain('queryType');
    expect(browser.getUrl()).toContain('term');
    expect($('[data-component="ResetPharmacyResultsButton"]')).toBeDefined();

    browser.executeScript('window.history.back()', []);

    expect(browser.getUrl()).not.toContain('queryType');
    expect(browser.getUrl()).not.toContain('term');
    expect(browser.getUrl()).toContain('page');
    expect($('[data-component="ResetPharmacyResultsButton"]')).toBeDefined();
    expect($('[data-component="TypeaheadDropdownToggleButton"]').getText()).toEqual(
      i18n.pharmacies.search.queryType.pharmacyName
    );
    expect($('[data-component="SearchBarInput"]').getValue()).toEqual('');
  });

  it('will fetch new results when distance changes', () => {
    const element = $('[data-component="PharmacySearchNumberOfResults"]');

    const initialCount = element.getText().split(' ')[0];

    $('[data-component="PharmacySearchDistanceDropdown"]').selectByVisibleText('5 Miles');

    expect(browser.getUrl()).toContain('distance=5');

    const newCount = element.getText().split(' ')[0];

    expect(initialCount).not.toEqual(newCount);
  });
});
