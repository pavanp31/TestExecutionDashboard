const { describeWithThemes } = require('../../support/utilities');
const i18n = require('../../../src/i18n/pharmacy');

let minorViolations = [];
let violations = [];

const selectPharmacyfilters = (...filters) => {
  for (let filter of filters) {
    $(`//label[contains(.,"${filter}")]`).click();
    $(`//button[@aria-checked="true"]/label[contains(.,"${filter}")]`).waitForDisplayed();
  }
};

const verifyFiltersAreDeselected = (filters, expectedStatus) => {
  const checkboxes = $$('[data-component="Checkbox"]');

  // Confirm all filters pass the test
  return filters.every(
    filter =>
      // Find the matching checkbox based on the current `filter` text and
      // ensure its "aria-checked" value is equal to the expected status.
      checkboxes.find(checkbox => checkbox.getText().includes(filter)).getAttribute('aria-checked') === expectedStatus
  );
};

describeWithThemes('Pharmacy Locator - Filters', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'pharmacy-name-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'pharmacy-name-accessibilty-violations-report.json');
  });

  it('will validate setting and resetting filters', () => {
    // Select (check) the desired filters on the pharmacy search page
    selectPharmacyfilters(
      i18n.pharmacies.pharmacy.services.items.delivery.title,
      i18n.pharmacies.pharmacy.services.items.immunizations.title,
      'Arabic (' // doesn't need i18n (it is unchanging)
    );

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    browser.goToPharmacyDetailsFromSearch();

    browser.waitForPharmacyDetailsPageToBeLoaded();

    browser.clickBackButton();

    const filterOptions = [
      i18n.pharmacies.pharmacy.services.items.delivery.title,
      i18n.pharmacies.pharmacy.services.items.immunizations.title,
      'Arabic' // doesn't need i18n (it is unchanging)
    ];

    // Verify filter options are not reset when user returns from pharmacy detail page
    expect(verifyFiltersAreDeselected(filterOptions, 'true')).toBeTruthy();

    // Click on reset button
    browser.waitForElementThenClick($('.reset-pharmacy-filters'));

    // Verify filter options are reset
    expect(verifyFiltersAreDeselected(filterOptions, 'false')).toBeTruthy();
  });

  it('will verify services set in search filters exist on details page', () => {
    // select and set some filters on the search results page
    selectPharmacyfilters(
      i18n.pharmacies.pharmacy.services.items.delivery.title,
      i18n.pharmacies.pharmacy.services.items.immunizations.title,
      'Arabic (' // doesn't need i18n (it is unchanging)
    );

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    browser.goToPharmacyDetailsFromSearch();

    browser.waitForPharmacyDetailsPageToBeLoaded();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    browser.verifyBasicModalExists(
      'DeliveryPharmacyServiceModalButton',
      i18n.pharmacies.pharmacy.services.items.delivery.title
    );
    browser.verifyBasicModalExists(
      'ImmunizationsPharmacyServiceModalButton',
      i18n.pharmacies.pharmacy.services.items.immunizations.title
    );
    expect(
      $$('[data-component="PharmacyLanguages"] li').filter(selector => selector.getText().includes('Arabic')).length
    ).toEqual(1);
  });
});
