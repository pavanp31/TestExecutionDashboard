const { describeWithThemes } = require('../../support/utilities');
const i18n = require('../../../src/i18n/pharmacy');

let minorViolations = [];
let violations = [];

describeWithThemes('Pharmacy Locator - Search by NPI', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'pharmacy-npi-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'pharmacy-npi-accessibilty-violations-report.json');
  });

  it('will search by NPI and validate selection', () => {
    const npi = '1598787202';

    browser.selectTypeaheadAddOnOption(i18n.pharmacies.search.queryType.npi);

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // Searches for the pharmacy using the NPI number
    $(`[placeholder="${i18n.pharmacies.search.input.placeholders.npi}"]`).waitForDisplayed();

    browser.doTypeaheadSearchAndSubmit(npi);

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // validates the npi # on the pharmacy list title
    expect(browser.getPharmacyQueryTypeIdentifierFromSearch()).toContain(npi);

    // gets the Pharmacy Name from the npi search list and verifies it matches on the details page
    const pharmacyName = browser.getPharmacyNameFromSearch();

    browser.goToPharmacyDetailsFromSearch();

    browser.waitForPharmacyDetailsPageToBeLoaded();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    expect(browser.getPharmacyNameFromDetails()).toContain(pharmacyName);
  });

  it('will search by NPI and confirm query type and value are in URL', () => {
    const npi = '1598787202';

    browser.selectTypeaheadAddOnOption(i18n.pharmacies.search.queryType.npi);

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // Searches for the pharmacy using the NPI number
    $(`[placeholder="${i18n.pharmacies.search.input.placeholders.npi}"]`).waitForDisplayed();

    browser.doTypeaheadSearchAndClickOnResult(npi);

    expect(browser.getUrl()).toContain('queryType=npi');
    expect(browser.getUrl()).toContain(`term=${npi}`);
  });
});
