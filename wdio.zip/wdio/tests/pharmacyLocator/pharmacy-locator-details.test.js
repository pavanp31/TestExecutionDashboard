const { describeWithThemes } = require('../../support/utilities');
const i18n = require('../../../src/i18n/pharmacy');

let minorViolations = [];
let violations = [];

describeWithThemes('Pharmacy Locator - Details', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'pharmacy-name-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'pharmacy-name-accessibilty-violations-report.json');
  });

  it('will verify information exists on details page', () => {
    browser.doTypeaheadSearchAndSubmit('10942');

    const pharmacyName = browser.getPharmacyNameFromSearch();

    browser.goToPharmacyDetailsFromSearch();

    browser.waitForPharmacyDetailsPageToBeLoaded();

    // verify hours modal exists
    browser.waitForElementThenClick($(`[data-component="ViewHoursButton"]`));
    $(`[data-component="HoursModalTitle"]`).waitForDisplayed();
    browser.waitForElementThenClick($('.close-button'));

    // verify pharmacy details
    expect(browser.getPharmacyNameFromDetails()).toEqual(pharmacyName);
    expect($('[data-component="PharmacyTwentyFourHourFeature"]').isExisting()).toBeTruthy();
    expect($(`[data-component="PharmacyNumber"]`).getText()).toEqual(`${i18n.pharmacies.pharmacy.storeNumber}10942`);
    expect($('[data-component="PharmacyAddressBlock"]').getText()).toContain('310 S MICHIGAN AVE');
    expect($('[data-component="PharmacyAddressBlock"]').getText()).toContain('CHICAGO, IL 60604');
    expect($('[data-component="PharmacyHoursOpen"]').getText()).toEqual(i18n.pharmacies.pharmacy.openTwentyFourHours);
    expect($('[data-component="PharmacyPhoneNumberLink"]').getText()).toEqual('(312) 588-0704');
    expect($('[data-component="PharmacyFax"]').getText()).toContain('(401) 765-1500');
  });
});
