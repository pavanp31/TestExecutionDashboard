const { describeWithThemes } = require('../../support/utilities');
let minorViolations = [];
let violations = [];

describeWithThemes('Pharmacy Locator - Search by Pharmacy Name', () => {
  beforeEach(() => {
    browser.startNewPharmacySearch();

    browser.resetPharmacyLocation();
  });

  afterAll(() => {
    browser.deleteCookies();

    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'pharmacy-name-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'pharmacy-name-accessibilty-violations-report.json');
  });

  it('will validate result in list matches entered search term', () => {
    const initialResult = browser.getPharmacyNameFromSearch();

    const searchTerm = initialResult.includes('WALG') ? 'CVS' : 'WALG';

    browser.doTypeaheadSearchAndSubmit(searchTerm);

    expect(browser.getPharmacyNameFromSearch()).toContain(searchTerm);
  });
});
