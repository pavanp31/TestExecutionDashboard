const { describeWithThemes } = require('../../support/utilities');
const i18n = require('../../../src/i18n/all');
const { DRUGS } = require('../../support/constants');

let minorViolations = [];
let violations = [];

describeWithThemes('Drug Pricing - Alternative Medications', () => {
  afterEach(() => browser.deleteCookies());

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'drug-pricing-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'drug-pricing-accessibilty-violations-report.json');
  });

  it('will validate alternatives tab when no alternative drugs are available', () => {
    browser.navigateToDrugPrices(DRUGS.atorvastatin);

    // Go through hang tight so we are waiting for prices to load before visiting alternatives tab
    browser.waitForElementThenClick($('[data-component="DrugTabAlternativeMedications"]'));

    const noResultSelector = $('[data-component="AlternativeResults"] li');

    noResultSelector.waitForDisplayed();

    expect(noResultSelector.getText()).toContain(`${i18n.drugs.info.prices.alternatives.noAlternatives}`);
  });

  it('will sort alternative drugs price descending, and navigate to pricing when clicked', () => {
    browser.navigateToDrugPrices(DRUGS.zithromax);

    browser.waitForElementThenClick($('[data-component="DrugTabAlternativeMedications"]'));

    $('[data-component="AlternativeMedicationsHeader"]').waitForDisplayed();

    const pricesArray = $('[data-component="AlternativeResults"]')
      .getText()
      .split('per day')
      .filter(price => price.includes('$'))
      .map(str => str.slice(-5));

    expect(pricesArray.sort()).toEqual(pricesArray);

    browser.waitForElementThenClick($('.check-alternatve-pricing-button'));

    $('[data-component="DrugTabPrices"]').waitForDisplayed();

    const drugName = $('[data-component="DrugName"]').getText();

    expect(drugName).toEqual('Cipro (Brand)');
  });

  describe('Modals', () => {
    beforeEach(() => {
      browser.navigateToDrugPrices(DRUGS.zithromax);

      // Go through hang tight so we are waiting for and validating Other Medication Available
      // tile and before clicking View More
      $(
        `(//h3[text()="${i18n.drugs.info.prices.results.content.alternativeMedications.alternativeMedicationsAvailable}"])`
      ).waitForDisplayed();

      // Selecting the View More button in the Other Medications Available tile
      $('.view-more-button').click();

      // Waits for and validates Other Medications page
      $('[data-component="AlternativeMedicationsHeader"]').waitForDisplayed();

      $('[data-component="AlternativeResults"]').scrollIntoView();
    });

    afterEach(() => {
      browser.waitForElementThenClick($('.close-button'));

      expect($('[data-component="AlternativeMedicationsHeader"]').waitForDisplayed()).toBeTruthy();
    });

    it('will open Prior Authorization Required modal', () => {
      $(`button[aria-label="${i18n.drugs.info.prices.warnings.priorAuthRequired.learnMoreA11y}"`).click();

      $('#ModalBasicHeader').waitForDisplayed();

      expect($('#ModalBasicHeader').getText()).toContain(i18n.drugs.info.prices.warnings.priorAuthRequired.title);
    });

    it('will open New Prescription modal', () => {
      browser.waitForElementThenClick(
        $(`button[aria-label="${i18n.drugs.info.prices.warnings.newPrescriptionRequired.learnMoreA11y}"`)
      );

      $('#ModalBasicHeader').waitForDisplayed();

      expect($('#ModalBasicHeader').getText()).toContain(i18n.drugs.info.prices.warnings.newPrescriptionRequired.title);
    });
  });
});
