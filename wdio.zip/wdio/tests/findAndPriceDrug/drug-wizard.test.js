const { describeWithThemes } = require('../../support/utilities');
let minorViolations = [];
let violations = [];

const getComboBox = type => $(`[data-component="DrugFilters${type}"] select`);
const getQuantityComboBox = () => getComboBox('Quantity');
const getFormComboBox = () => getComboBox('Form');
const getStrengthComboBox = () => getComboBox('Strength');
const getDaySupplyComboBox = () => getComboBox('DaySupply');

// set custom quantity value function defaults with blank input
const setCustomQuantityValue = (comboBox, filter, value = '') => {
  browser.waitUntil(() => {
    comboBox.click();

    return comboBox.isFocused();
  });

  const indexOfCustomOption = comboBox.$$('option').length - 1; // index of last option, which causes the input field to show

  comboBox.selectByAttribute('value', indexOfCustomOption);

  const input = $(`[data-component="DrugFilters${filter}"] input`);

  input.waitForDisplayed();

  browser.waitUntil(() => input.isFocused());

  expect(input.isFocused()).toBeTruthy();

  // sets the custom value
  if (value != '') {
    input.setValue(value);
  }
};

describeWithThemes('Drug Wizard', () => {
  beforeEach(() => {
    browser.waitForMedicineCabinetToBeLoaded();

    browser.url('drugs/carisoprodol/wizard');
    getStrengthComboBox().waitForDisplayed();
  });

  afterEach(() => browser.deleteCookies());

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'drug-wizard-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'drug-wizard-accessibilty-violations-report.json');
  });

  it('will show form and strength for a searched drug', () => {
    expect(
      getFormComboBox()
        .getText()
        .toUpperCase()
    ).toContain('TABLET');

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    expect(getStrengthComboBox().getText()).toContain('350 MG');
  });

  it('selectors update when antecedent selector changes', () => {
    // change total quantity to something new
    browser.waitUntil(() => {
      browser.waitForElementThenClick(getQuantityComboBox());
      return getQuantityComboBox().isFocused();
    });
    browser.keys('5');

    // change the strength quantity... should trigger a reload of filters
    getStrengthComboBox().click();
    $('option=250 MG').click();

    // wait until filters have reloaded
    getQuantityComboBox().waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // make sure total quantity has refreshed
    expect(getQuantityComboBox().getText()).not.toEqual('5');
  });

  it('will validate error message and input focus when Quantity and Day Supply values are left blank', () => {
    getFormComboBox().waitForDisplayed();

    const selectQuantity = getQuantityComboBox();
    const selectDaySupply = getDaySupplyComboBox();

    selectQuantity.waitForDisplayed();

    setCustomQuantityValue(selectQuantity, 'Quantity');

    setCustomQuantityValue(selectDaySupply, 'DaySupply');

    $('[data-component="DrugWizardSubmitButton"]').click();

    expect(
      $('[data-component="DrugFiltersQuantity"] [data-component="FilterComboBoxErrorMessage"]').waitForDisplayed()
    ).toBeTruthy();

    expect(
      $('[data-component="DrugFiltersDaySupply"] [data-component="FilterComboBoxErrorMessage"]').waitForDisplayed()
    ).toBeTruthy();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    browser.waitUntil(() => $('[data-component="DrugFiltersQuantity"] input').isFocused());

    expect($('[data-component="DrugFiltersQuantity"] input').isFocused()).toBeTruthy();
  });

  it('will validate custom value persistence set for Quantity and Days Supply', () => {
    getFormComboBox().waitForDisplayed();

    const selectQuantity = getQuantityComboBox();

    const selectDaySupply = getDaySupplyComboBox();

    selectQuantity.waitForDisplayed();

    setCustomQuantityValue(selectQuantity, 'Quantity', '200');

    setCustomQuantityValue(selectDaySupply, 'DaySupply', '60');

    $('[data-component="DrugWizardSubmitButton"]').click();

    browser.waitForHangTightLoaderToAppearAndDisappear();

    $('[data-component="DrugTabPrices"]').waitForDisplayed();

    $('[data-component="SidebarHeader"]').waitForDisplayed();

    $('[data-component="DrugFiltersQuantity"] input').scrollIntoView({ block: 'center' });

    expect($('[data-component="DrugFiltersQuantity"] [value="200"]').waitForDisplayed()).toBeTruthy();

    expect($('[data-component="DrugFiltersDaySupply"] [value="60"]').waitForDisplayed()).toBeTruthy();
  });
});
