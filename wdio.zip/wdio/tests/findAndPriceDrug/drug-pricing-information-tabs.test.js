const { describeWithThemes } = require('../../support/utilities');
const { DRUGS } = require('../../support/constants');

describeWithThemes('Drug Pricing', () => {
  let minorViolations = [];
  let violations = [];

  afterEach(() => browser.deleteCookies());

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'drug-pricing-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'drug-pricing-accessibilty-violations-report.json');
  });

  it('will validate drug proper use tab navigation', () => {
    browser.navigateToDrugPrices(DRUGS.soma);

    // navigates to the proper use page
    browser.waitForElementThenClick($('[data-component="DrugTabProperUse"]'));

    // validate navigation to the proper use page
    $('[data-component="DrugProperUseContent"]').waitForDisplayed();

    // validate navigation back to the drug pricing page
    $('[data-component="BackButton"]').click();
    $('[data-component="DrugTabPrices"][aria-selected="true"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });

  it('will validate drug possible side effects tab navigation', () => {
    browser.navigateToDrugPrices(DRUGS.soma);

    // navigates to the possible side effects page
    browser.waitForElementThenClick($('[data-component="DrugTabPossibleSideEffects"]'));

    // validate navigation to the possible side effects page
    $('[data-component="DrugPossibleSideEffectsContent"]').waitForDisplayed();

    // validate navigation back to the drug pricing page
    $('[data-component="BackButton"]').click();
    $('[data-component="DrugTabPrices"][aria-selected="true"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });
});
