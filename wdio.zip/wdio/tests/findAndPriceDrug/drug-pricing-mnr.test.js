const i18n = require('../../../src/i18n/all');
const { DRUGS } = require('../../support/constants');
const { describeWithSingleTheme } = require('../../support/utilities');

describeWithSingleTheme('uhc', 'Drug Pricing - M&R', () => {
  let minorViolations = [];
  let violations = [];

  beforeAll(() => {
    browser.deleteCookies();
    browser.reloadSession();
  });

  afterEach(() => browser.deleteCookies());

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'drug-pricing-mnr-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'drug-pricing-mnr-accessibilty-violations-report.json');

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });

  describe('Drug Tiers', () => {
    it('will show tier indicators', () => {
      // This will make a call to waitForMedicineCabinetToBeLoaded with the fake mnr user
      browser.navigateToDrugPrices(DRUGS.fluticasone_mnr);
      $('.tier-indicator-title').waitForDisplayed();

      // Check pricing page
      expect($('.tier-indicator-title').getText()).toContain(i18n.drugs.info.tiers.tierTitle.replace('{{number}}', 3));
      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      // Navigate to alternatives tab
      browser.waitForElementThenClick($('[data-component="DrugTabAlternativeMedications"]'));

      // Check alternative page
      expect(
        $('[data-component="AlternativeResults"]')
          .$('.tier-indicator-title')
          .getText()
      ).toContain(i18n.drugs.info.tiers.tierTitle.replace('{{number}}', 2));
    });
  });

  describe('Price Warnings', () => {
    it('will validate Medicare Part B or Part D modal', () => {
      browser.navigateToDrugPrices(DRUGS.nulojix_mnr, true);

      // Click button and open modal
      browser.waitForElementThenClick($('(//div[text()="Medicare Part B or Part D"]/parent::button)[2]'));

      // validate navigation to the Medicare Part B or Part D modal
      $('#ModalBasicHeader').waitForDisplayed();
      expect($('#ModalBasicHeader').getText()).toContain(i18n.drugs.info.prices.warnings.medicarePartBOrPartD.title);
    });

    it('will validate Step Therapy Required modal', () => {
      browser.navigateToDrugPrices(DRUGS.fluticasone_mnr, true);

      // Click button and open modal
      browser.waitForElementThenClick($('(//div[text()="Step Therapy Required"]/parent::button)[2]'));

      // validate navigation to the Step Therapy Required modal
      $('#ModalBasicHeader').waitForDisplayed();
      expect($('#ModalBasicHeader').getText()).toContain(i18n.drugs.info.prices.warnings.stepTherapyRequired.title);
    });
  });

  describe('Tier descriptions for MAPD', () => {
    it('will open the tier modal when tier link is clicked on', () => {
      // Log in as MAPD user and navigate to drug in tier 5
      browser.navigateToDrugPrices(DRUGS.nulojix_mnr);

      // Click tier button in header and open modal
      $('.tier-indicator-title').waitForDisplayed();
      $('.tier-indicator-title').click();

      // validate navigation to the Tier Definitions modal
      $('#ModalBasicHeader').waitForDisplayed();
      expect($('#ModalBasicHeader').getText()).toContain(i18n.drugs.info.tiers.drugTiers);
    });
  });

  describe('Tier descriptions for PDP', () => {
    it('will open the tier modal when tier link is clicked on', () => {
      // Log in as PDP user and navigate to drug in tier 4
      browser.navigateToDrugPrices(DRUGS.vraylar_pdp);

      // Click tier button in header and open modal
      $('.tier-indicator-title').waitForDisplayed();
      $('.tier-indicator-title').click();

      // validate navigation to the Tier Definitions modal
      $('#ModalBasicHeader').waitForDisplayed();
      expect($('#ModalBasicHeader').getText()).toContain(i18n.drugs.info.tiers.drugTiers);
    });
  });

  describe('Coverage stages', () => {
    it('will show correct labels', () => {
      browser.navigateToDrugPrices(DRUGS.testim); // this drug has appropriate coverage stage response

      // first price result should be catastrophic coverage stage
      expect($('#price-results > li:nth-child(1) div.coverage-stage-label').getText()).toBe(
        'Catastrophic Coverage Stage'
      );

      // second price result should be coverage gap stage
      expect($('#price-results > li:nth-child(2) div.coverage-stage-label').getText()).toBe('Coverage Gap Stage');
    });

    it('will show Catastropic Coverage modal', () => {
      browser.navigateToDrugPrices(DRUGS.testim); // this drug has appropriate coverage stage response

      // open coverage stage modal for first result (Catastrophic Coverage)
      browser.waitForElementThenClick($('#price-results > li:nth-child(1) button.see-stages-link'));

      // check past stages
      const pastStageContainers = $$('.past-stage-container');
      expect(pastStageContainers.length).toBe(3);
      pastStageContainers.forEach(container => {
        expect(container.getText()).toContain(i18n.drugs.info.stages.stageComplete);
      });

      // check current stage
      expect($$('.current-stage-container').length).toBe(1);
      expect($('.current-stage-container').getText()).toContain(i18n.drugs.info.stages.catastrophicCoverage);
      expect($$('.current-stage-container .stage-price').length).toBe(1);

      // assert no future stage
      expect($$('.future-stage-container').length).toBe(0);
    });

    it('will show Coverage Gap modal', () => {
      browser.navigateToDrugPrices(DRUGS.testim); // this drug has appropriate coverage stage response

      // open coverage stage modal for second result (Coverage Gap)
      browser.waitForElementThenClick($('#price-results > li:nth-child(2) button.see-stages-link'));

      // check past stages
      const pastStageContainers = $$('.past-stage-container');
      expect(pastStageContainers.length).toBe(2);
      pastStageContainers.forEach(container => {
        expect(container.getText()).toContain(i18n.drugs.info.stages.stageComplete);
      });

      // check current stage is Coverage Gap
      expect($$('.current-stage-container').length).toBe(1);
      expect($('.current-stage-container').getText()).toContain(i18n.drugs.info.stages.coverageGap);
      expect($$('.current-stage-container .stage-price').length).toBe(1);

      // check future stage is Catastrophic Coverage
      expect($$('.future-stage-container').length).toBe(1);
      expect($('.future-stage-container').getText()).toContain(i18n.drugs.info.stages.catastrophicCoverage);
      expect($$('.future-stage-container .stage-price').length).toBe(1);
    });

    it('will show Annual Deductible Stage modal', () => {
      browser.navigateToDrugPrices(DRUGS.olanzapine_mnr); // this drug has appropriate coverage stage response

      const priceRegExp = /^\$\d/; // displayed cost during stage, ex: $9 or $100.57

      // Runs these tests on every Retail or Home Delivery result
      $$('#price-results > li').forEach(result => {
        if (
          !result.$('[data-component="DrugPriceResultRetail"]').isExisting() &&
          !result.$('[data-component="DrugPriceResultHomeDelivery"]').isExisting()
        ) {
          return;
        }

        // adjust the Annual Deductible stage label into view
        result.$('.coverage-stage-label').scrollIntoView({ block: 'center' });

        // Checks result is in the Annual Deductible stage
        expect(
          result
            .$('.coverage-stage-label')
            .getText()
            .includes(i18n.drugs.info.stages.deductible)
        ).toBe(true);

        result.$('.see-stages-link').click();

        // checks current stage is Annual Deductible
        expect($$('.current-stage-container').length).toBe(1);
        expect($('.current-stage-container').getText()).toContain(i18n.drugs.info.stages.deductible);
        expect($$('.current-stage-container .stage-price').length).toBe(1);
        // checks stage has a price
        expect($('.current-stage-container .stage-price').getText()).toMatch(priceRegExp);

        // checks that all remaining stages are future stages
        const futureStageContainers = $$('.future-stage-container');
        expect(futureStageContainers.length).toBe(3);
        // checks each future stage is labeled future stage and has a price
        futureStageContainers.forEach(container => {
          expect(container.getText()).toContain(i18n.drugs.info.stages.futureStage);
          expect(container.$('.stage-price').getText()).toMatch(priceRegExp);
        });

        $('.close-button').click();
      });
    });

    it('will not show see stages labels or link for group mnr users', () => {
      browser.navigateToDrugPrices(DRUGS.fluconazole_mnr_group);

      expect($$('.see-stages-link').length).toBe(0);
      expect($$('.coverage-stage-label').length).toBe(0);
    });
  });
});
