const { describeWithThemes } = require('../../support/utilities');
const { DRUGS } = require('../../support/constants');
const keyCodes = require('../../support/keyCodes');

let minorViolations = [];
let violations = [];

describeWithThemes('Drug Pricing - Details', () => {
  afterEach(() => browser.deleteCookies());

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'drug-pricing-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'drug-pricing-accessibilty-violations-report.json');
  });

  it('will validate drug exception alert', () => {
    browser.navigateToDrugPrices(DRUGS.soma);

    // validate exception alert banner displays with only first alert displayed
    $('[data-component="Banner"]').waitForDisplayed();
    $('[data-component="BannerContent"]').waitForDisplayed();
    $('[data-component="ReadMoreContent"][aria-hidden="true"]').waitForDisplayed();

    browser.waitForElementThenClick($('[data-component="ReadMoreButton"][aria-expanded="false"]'));

    $('[data-component="ReadMoreContent"][aria-hidden="false"]').waitForDisplayed();

    // validate the second alert content is not displayed after clicking the read less link
    browser.waitForElementThenClick($('[data-component="ReadMoreButton"][aria-expanded="true"]'));
    $('[data-component="ReadMoreContent"][aria-hidden="true"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });

  it('will validate updating the member location from the drug pricing sidebar', () => {
    browser.navigateToDrugPrices(DRUGS.soma);

    const initialLocation = '200 E Randolph St';
    const secondaryLocation = 'Taco Bell';
    const changeLocationElement = $('[data-component="CurrentLocationParagraph"]');

    changeLocationElement.waitForDisplayed();

    // gets the current location from the drug pricing page
    const currentLocation = changeLocationElement.getText().toUpperCase();

    // navigates to the change location page
    browser.waitForElementThenClick($('[data-component="ChangeLocationParagraphButton"]'));

    $('#LocationSelectorHeader').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // checks if current location is already set to the "Randolph St" address
    // before inputting this address, otherwise it will input the "Taco Bell"
    // address. This will avoid updating and validating against a current location
    const locationInputValue = currentLocation.includes('RANDOLPH') ? secondaryLocation : initialLocation;
    const locationInput = $('[data-component="SearchBarInput"]');
    locationInput.setValue(locationInputValue);
    expect(locationInput.getValue()).toBe(locationInputValue);
    browser.waitForElementThenClick($('[data-component="TypeaheadResultItem"]:first-child'));

    // saves the updated address and validates navigation back to the drug pricing page
    browser.waitForElementThenClick($('[data-component="ChangeLocationUpdateButton"]'));
    changeLocationElement.waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // validates the updated location is displayed properly on the drug pricing page
    const expectedLocation = currentLocation.includes('RANDOLPH') ? 'TACO BELL' : 'RANDOLPH';
    expect(changeLocationElement.getText().toUpperCase()).toContain(expectedLocation);
  });

  it('will validate drug details and navigation', () => {
    browser.navigateToDrugPrices(DRUGS.soma);
    // validate brand drug name, form and strength details
    $('//h1[contains(.,"Soma") and contains(.,"Brand")]').waitForDisplayed();
    $('//div[text()="Form" and contains(.,"Tablet")]').waitForDisplayed();
    $('//div[text()="Strength" and contains(.,"350 MG")]').waitForDisplayed();

    // validate generic drug is available on the brand drug page
    $('[data-component="DrugAlternatives"]').waitForDisplayed();
    $('//a[contains(.,"Carisoprodol") and contains(.,"Generic")]').waitForDisplayed();

    // validate navigation to the generic drug pricing page
    browser.waitForElementThenClick($('[data-component="DrugAlternatives"] a'));

    browser.waitForHangTightLoaderToAppearAndDisappear();

    $('[data-component="DrugName"]').waitForDisplayed();
    $('//h1[contains(.,"Carisoprodol") and contains(.,"Generic")]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
    $('[data-component="Banner"]').scrollIntoView({ block: 'center' });

    // validate brand drug is available on the generic drug page
    $('[data-component="DrugAlternatives"]').waitForDisplayed();
    $('//a[contains(.,"Soma") and contains(.,"Brand")]').waitForDisplayed();

    // validate navigation back to brand drug pricing page
    $('[data-component="DrugAlternatives"] a').click();
    browser.waitForHangTightLoaderToAppearAndDisappear();

    $('[data-component="DrugName"]').waitForDisplayed();
    $('//h1[contains(.,"Soma") and contains(.,"Brand")]').waitForDisplayed();
  });

  it('will validate drug new search link navigation', () => {
    browser.navigateToDrugPrices(DRUGS.soma);

    // validate navigation to new drug search page
    browser.waitForElementThenClick($('[data-component="NewDrugSearch"]'));

    // validate navigation to the drug search page
    $('[data-component="SearchBarInput"][aria-label="Search Medications by Name"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });

  it('will validate prior authorization modal', () => {
    browser.navigateToDrugPrices(DRUGS.soma);

    // validate navigation to new drug search page
    browser.waitForElementThenClick($('(//div[text()="Prior Authorization"]/parent::button)[2]'));

    // validate navigation to the prior authorization modal
    $('#ModalBasicHeader').waitForDisplayed();
    expect($('#ModalBasicHeader').getText()).toContain('Prior Authorization');

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });

  it('will validate prior authorization approved modal', () => {
    browser.navigateToDrugPrices(DRUGS.testosterone);

    // validate navigation to new drug search page
    browser.waitForElementThenClick($('(//div[text()="Prior Authorization Approved"]/parent::button)[2]'));

    // validate navigation to the prior authorization approved modal
    $('#ModalBasicHeader').waitForDisplayed();
    expect($('#ModalBasicHeader').getText()).toContain('Prior Authorization Approved');

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });

  fit('will validate list of additional pharmacy locations from drug pricing page', () => {
    browser.navigateToDrugPrices(DRUGS.soma);

    // validate pricing page

    $('[data-component="DrugPriceResultsHeader"]').waitForDisplayed();
    $('[data-component="PharmacyAddressBlock"]').waitForDisplayed();

    // validate navigation to Additional Locations for a pharmacy
    browser.waitForElementThenClick($('[data-component="PharmacyAdditionalLocationsLink"]'));

    browser.waitUntil(() => {
      return $('[data-component="PaginationNavigationBar"]').isDisplayed();
    });

    // validate navigation to the Pharmacies 'Locations' tab
    $('[data-component="PaginationNavigationBar"]').waitForDisplayed();
    $('[data-component="PharmacyHeaderExpanded"]').waitForDisplayed();
    $('[data-component="Locations"]').waitForDisplayed();
    $('#NumberOfLocations*=Additional Location').waitForDisplayed(); // finding by id and partial text
    $('[data-component="PharmacyHeaderInline"]').waitForDisplayed();
    $('[data-component="ViewHoursButton"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
    // validate navigation to the Pharmacies 'Overview' tab
    browser.waitForElementThenClick($('[data-component="DrugPharmacyTabOverview"]'));

    $('[data-component="Overview"]').waitForDisplayed();
    $('[data-component="ViewHoursButton"]').waitForDisplayed();
    $('[data-component="ReportIncorrectInformationButton"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);
  });

  it('will skip to main content', () => {
    browser.navigateToDrugPrices(DRUGS.soma);

    $('[data-component="DrugPriceResultsHeader"]').waitForDisplayed();

    const button = $('#rxSkipToMainContent');

    browser.execute(el => el.focus(), button);

    expect(button.isFocused()).toBeTruthy();

    browser.keys(keyCodes.enter);

    expect($('#firstPriceResult').isFocused()).toBeTruthy();
  });
});
