const { describeWithThemes } = require('../../support/utilities');
let minorViolations = [];
let violations = [];

describeWithThemes('Drug Wizard: Change Location', () => {
  beforeEach(() => {
    browser.waitForMedicineCabinetToBeLoaded();
    browser.url('drugs/carisoprodol/wizard');
  });

  afterEach(() => browser.deleteCookies());

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'change-location-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'change-location-accessibilty-violations-report.json');
  });

  it('will show updated location of the primary member', () => {
    const locationInput = $('[data-component="SearchBarInput"]');
    const initialLocation = '200 E Randolph St';
    const secondaryLocation = 'Taco Bell';
    const currentLocationElement = $('[data-component="CurrentLocation"]');

    currentLocationElement.waitForDisplayed();

    // gets the current location from the drug wizard page
    const currentLocation = currentLocationElement.getText().toUpperCase();

    // navigates to the change location page
    $('[data-component="ChangeLocationButton"]').click();
    $('[id="LocationSelectorHeader"]').waitForDisplayed();

    // checks if current location is already set to the "Randolph St" address
    // before inputting this address, otherwise it will input the "Southport"
    // address. This will avoid updating and validating against a current location
    const locationInputValue = currentLocation.includes('RANDOLPH') ? secondaryLocation : initialLocation;
    locationInput.setValue(locationInputValue);
    expect(locationInput.getValue()).toBe(locationInputValue);

    browser.waitForElementThenClick($('[data-component="TypeaheadResultItem"]:first-child'));

    // saves the updated address and validates navigation back to the drug wizard page
    browser.waitForElementThenClick($('[data-component="ChangeLocationUpdateButton"]'));

    currentLocationElement.waitForDisplayed();
    // This button selector interpolates the expected location
    $(`//button[contains(.,"${locationInputValue}")]`).waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // validates the updated location is displayed properly on the drug wizard page
    const expectedLocation = currentLocation.includes('RANDOLPH') ? 'TACO BELL' : 'RANDOLPH';
    expect(currentLocationElement.getText()).toContain(expectedLocation);
  });
});
