const { describeWithThemes } = require('../../support/utilities');
let minorViolations = [];
let violations = [];

const typeSearchQuery = query => {
  const searchBox = $('[data-component="SearchBarInput"]');
  searchBox.waitForDisplayed();
  browser.waitUntil(() => {
    // NOTE a single .click() call fails to focus the input ~5% of the time
    searchBox.click();
    return searchBox.isFocused();
  });
  browser.keys(query);
};

describeWithThemes('Drug Search', () => {
  beforeEach(() => {
    browser.startNewDrugSearch();
  });

  afterEach(() => browser.deleteCookies());

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'drug-search-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'drug-search-accessibilty-violations-report.json');
  });

  it('will redirect to wizard when a drug search typeahead result is clicked', () => {
    typeSearchQuery('amoxicillin');

    const searchResult = $('[data-component="TypeaheadResultItem"]');
    searchResult.waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    searchResult.click();
    $('[data-component="DrugFiltersStrength"] select').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    expect(browser.getUrl()).toMatch('.*/drugs/amoxicillin/wizard');
  });

  it('will hide Medicine Cabinet when search is focused', () => {
    typeSearchQuery('amoxicillin');

    expect($('[data-component="MedicineCabinet"]').isExisting()).toBeFalsy();
  });

  it('will redirect to wizard when a full drug search result is clicked', () => {
    typeSearchQuery('amoxicillin');
    $('[data-component="SearchBarSubmitButton"]').click();

    const searchResult = $('[data-component="DrugSearchResultLink"]');

    browser.waitForElementThenClick(searchResult);

    $('[data-component="DrugFiltersStrength"] select').waitForDisplayed();

    expect(browser.getUrl()).toMatch('.*/drugs/amoxicillin/wizard');
  });

  it('will go to last page of results if trying to go over the top', () => {
    browser.url('drugs/results?q=cis&page=999');

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    browser.waitForElementThenClick($('[data-component="PaginationPreviousControl"]'));

    $('[data-component="DrugSearchResultItem"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // extract the last page from the url
    const lastPage = browser
      .getUrl()
      .split('page=')
      .pop();

    // validate the url page matches the last page text
    expect(`Page ${lastPage} of ${lastPage}`).toEqual($('[data-component="PaginationPageLabel"]').getText());

    $('[data-component="PaginationPreviousControl"]').click();

    $('[data-component="DrugSearchResultItem"]').waitForDisplayed();

    // validate the second to last page
    expect(browser.getUrl()).toContain(`?q=cis&page=${parseInt(lastPage) - 1}`);
  });

  it('will hide Medicine Cabinet for M&R users', () => {
    if (browser.hasUHCTheme()) {
      browser.startNewDrugSearch({ isMnr: true });

      expect($('[data-component="MedicineCabinet"]').isExisting()).toBeFalsy();
    } else {
      expect(true).toBe(true);
    }
  });
});
