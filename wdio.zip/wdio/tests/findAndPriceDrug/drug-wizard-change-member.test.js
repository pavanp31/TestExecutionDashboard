const { describeWithThemes } = require('../../support/utilities');
let minorViolations = [];
let violations = [];

describeWithThemes('Drug Wizard - Change Member', () => {
  const getCurrentMember = () => $('[data-component="ChangeCurrentMember"]').getText();

  beforeEach(() => {
    browser.waitForMedicineCabinetToBeLoaded();
    browser.url('drugs/carisoprodol/wizard');
  });

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'change-member-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'change-member-accessibilty-violations-report.json');
  });

  it('will change the current member in drug wizard, click cancel, and confirm the original current member is still valid', () => {
    $('[data-component="ChangeCurrentMember"]').waitForDisplayed();
    browser.waitUntil(() => getCurrentMember().includes('Member'));

    // validates the primary member is listed when landing on the drug wizard page
    expect(getCurrentMember()).toContain('Member');

    // click the change current member button and navigates to the change member page
    $('[data-component="ChangeCurrentMemberButton"]').click();
    $('[data-component="ChangeCurrentMemberModal"]').waitForDisplayed();

    // clicks the the cancel button and navigates back to the drug wizard page
    $('[data-component="ChangeCurrentMemberCancelButton"]').click();
    $('[data-component="DrugFilters"]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // validates the primary member is still displayed
    expect(getCurrentMember()).toContain('Member');
  });

  it('will change the current member in drug wizard, click update, and confirm the current member is changed', () => {
    $('[data-component="ChangeCurrentMember"]').waitForDisplayed();
    browser.waitUntil(() => getCurrentMember().includes('Member'));

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    // validates the primary member is listed when landing on the drug wizard page
    expect(getCurrentMember()).toContain('Member');

    // click the change current member button and navigates to the change member page
    $('[data-component="ChangeCurrentMemberButton"]').click();
    $('[data-component="ChangeCurrentMemberModal"]').waitForDisplayed();

    // changes the member to authorized, then navigates back to the drug wizard page
    $('//label[contains(.,"Authorized KitchenSink")]').waitForDisplayed();
    browser.waitUntil(() => {
      $('//label[contains(.,"Authorized KitchenSink")]').click();
      return $('[name=ChangeCurrentMember]:checked + label')
        .getText()
        .includes('Authorized');
    });
    $('[data-component="ChangeCurrentMemberUpdateMemberButton"]').click();

    // validates member has updated to authorized
    $('[data-component="DrugFilters"]').waitForDisplayed();
    $('//button[contains(.,"Authorized")]').waitForDisplayed();

    browser.checkPageAccessibiltyViolations(violations, minorViolations);

    expect(getCurrentMember()).toContain('Authorized');
  });
});
