const dogapi = require('dogapi');
const WDIOReporter = require('@wdio/reporter').default;
const util = require('util');

function getBuildType() {
  const isJenkins = process.env.JENKINS_HOME !== undefined;
  const isPR = process.env.CHANGE_ID !== undefined;

  if (isPR) {
    return 'pr';
  } else if (isJenkins) {
    return 'master';
  } else {
    return 'local';
  }
}

const buildType = getBuildType();

/**
 * The DataDog reporter emits test failure statistics to DataDog after
 * every test execution.
 */
module.exports = class DatadogReporter extends WDIOReporter {
  constructor(options) {
    super(options);

    if (options.apiKey && options.appKey) {
      const dogParams = {
        api_key: options.apiKey,
        app_key: options.appKey
      };

      dogapi.initialize(dogParams);

      console.log('DataDog API initialized. Real events will be sent to DataDog.');
    } else {
      console.log('DataDog API key and App key are necessary configs. Will NOT be sending events to DataDog.');
    }
  }

  onSuiteEnd(suite) {
    const datadogHandler = (err, results, statusCode) => {
      if (err) {
        this.write(`Sent metric to DataDog, received statusCode = ${statusCode}\n`);
        this.write(`Response:\n`);
        this.write(`${err}\n`);
      }

      if (suite.tests[0].error) {
        this.write(`Suite: ${suite.title}\n`);
        this.write(util.inspect(suite.tests, { depth: null }) + '\n\n');
        this.write(`${results}\n`);
        this.write(`Sent metric to DataDog, received statusCode = ${statusCode}\n`);
        this.write(`Response:\n`);
      }
    };

    // For each test in the suite, emit a metric.
    suite.tests
      // We only care about tests that are passed or failed. Any other states (e.g. skipped) can be ignored.
      .filter(test => ['passed', 'failed'].includes(test.state))
      .map(test => {
        const metric = 'rx.e2e.test';
        const dataPoint = 1;
        const tags = ['state:' + test.state, 'title:' + `${suite.title} ${test.title}`, 'build_type:' + buildType];

        this.write(`sent to datadog: '${metric}'='${dataPoint}' '${tags}'\n`);
        dogapi.metric.send(metric, dataPoint, { tags, type: 'count' }, datadogHandler);
      });
  }
};
