const process = require('process');

let minorViolations = [];
let violations = [];

describe('Smoke test', () => {
  beforeAll(() => {
    let loginPage;
    const fakeRallyId = process.env.FAKE_RALLY_ID;
    const fakeHsid = process.env.FAKE_HSID;
    if (browser.options.baseUrl.includes('member.uhc.com')) {
      // If running against prod, use myuhc.com
      loginPage = 'https://myuhc.com';
    } else if (fakeRallyId || fakeHsid) {
      // if using a fake Rally ID or HSID, then we want to use fakesso
      loginPage = '/pharmacy-uhc/fakesso?';
      if (fakeRallyId) {
        loginPage += `rid=${fakeRallyId}&`;
      }

      if (fakeHsid) {
        loginPage += `hsid=${fakeHsid}`;
      } else {
        loginPage += 'resolveHsid=true';
      }
    } else {
      // If none of the above, then assume that the login page is sufficient as given
      loginPage = browser.options.baseUrl;
    }
    const LOGIN_WAIT_MILLISECONDS = 2 * 60 * 1000; // 2 minutes
    browser.url(loginPage);
    if (!loginPage.includes('fakesso')) {
      // If not using fakesso, then we landed on DHP and need to click through to RallyRx
      if (loginPage === 'https://myuhc.com') {
        // Wait for login
        $('a[data-track-id="MANAGE_PRESCRIPTIONS"]').waitForDisplayed(LOGIN_WAIT_MILLISECONDS);
        // Close iperceptions
        browser.url('');
        $('a[data-track-id="MANAGE_PRESCRIPTIONS"]').waitForDisplayed();
        // The covid modal prevents the MANAGE_PRESCRIPTIONS button from being clickable and causes the beforeAll block to fail
        // close it to prevent a spurious error if it is shown
        browser.pause(1000);
        if (browser.getUrl().includes('coronavirus-prompt')) {
          $('button[data-testid="close-mini-modal"]').waitForDisplayed();
          $('button[data-testid="close-mini-modal"]').click();
        }
      }
      $('a[data-track-id="MANAGE_PRESCRIPTIONS"]').waitForDisplayed(LOGIN_WAIT_MILLISECONDS);
      $('a[data-track-id="MANAGE_PRESCRIPTIONS"]').click();
    }
    $('[data-component="MedicineCabinet"]').waitForDisplayed();
  });

  beforeEach(() => {
    browser.pause(2000); // We want to confirm what browser is actually doing during the smoke test.
  });

  afterAll(() => {
    // write accessibility violations to json file
    browser.createViolationsReport(minorViolations, 'smoke-minor-accessibility-violations-report.json');
    browser.createViolationsReport(violations, 'smoke-accessibilty-violations-report.json');
  });

  describe('Home', () => {
    it('has "Pharmacy" title', () => {
      browser.url('/pharmacy-uhc');
      $('[data-component="MedicineCabinet"]').waitForDisplayed();
      expect(browser.getTitle()).toEqual('Pharmacy');

      browser.checkPageAccessibiltyViolations(violations, minorViolations);
    });
  });

  describe('Find and Price Drug', () => {
    beforeEach(() => {
      browser.url('/pharmacy-uhc/drugs/carisoprodol/wizard');
      $(`[data-component="DrugFiltersStrength"] select`).waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);
    });

    it('will input medication in the search bar and navigate to correct drug wizard', () => {
      const medication = 'Valium';
      // navigates and inputs the drug in the medication search page
      browser.url('/pharmacy-uhc/drugs');
      $('[data-component="SearchBarInput"]').waitForDisplayed();
      $('[data-component="SearchBarInput"]').setValue(medication);

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      // clicks the search button and selects the drug from the results list
      $('[data-component="SearchBarSubmitButton"]').click();
      $('//h1[contains(.,"Medication search results")]').waitForDisplayed();
      $(`//h2[contains(.,"${medication}")]`).waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);
      // scroll back to the top of the page after violation check
      $(`//h2[contains(.,"${medication}")]`).scrollIntoView();

      // clicks the the first drug within the list
      $('[data-component="DrugSearchResultItem"]:first-of-type [data-component="DrugSearchResultLink"]').click();

      // verifies navigation to the correct drug wizard page
      $('[data-component="DrugFilters"]').waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      expect($('h1 span:first-of-type').getText()).toContain(medication);
    });

    it('will show form and strength for a searched drug', () => {
      expect($(`[data-component="DrugFiltersForm"] select`).getText()).toContain('Tablet');
      expect($(`[data-component="DrugFiltersStrength"] select`).getText()).toContain('350 MG');
    });

    it('will show updated location of the primary member', () => {
      const locationInput = $('[data-component="SearchBarInput"]');
      const initialLocation = '200 E Randolph St, Chicago, IL 60601';
      const secondaryLocation = '3733 North Southport Avenue, Chicago, IL 60613';
      const currentLocationElement = $('[data-component="CurrentLocation"]');

      //gets the current location from the drug wizard page and assigns it to a variable
      const currentLocation = currentLocationElement.getText().toUpperCase();

      //scrolling to ChangeLocationButton doesn't put it fully on screen because of the floating header
      $('[data-component="BackButton"]').scrollIntoView();
      //navigates to the change location page
      $('[data-component="ChangeLocationButton"]').click();
      $('[id="LocationSelectorHeader"]').waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      //checks if current location is already set to the "Randolph St" address
      //before inputting this address, otherwise it will input the "Southport"
      // address. This will avoid updating and validating against a current location
      const locationInputValue = currentLocation.includes('RANDOLPH') ? secondaryLocation : initialLocation;
      locationInput.setValue(locationInputValue);
      $('[data-component="TypeaheadResultItem"]:first-child').waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      $('[data-component="TypeaheadResultItem"]:first-child').click();

      //saves the updated address and validates navigation back to the drug wizard page
      $('[data-component="ChangeLocationUpdateButton"]').waitForDisplayed();
      $('[data-component="ChangeLocationUpdateButton"]').click();
      currentLocationElement.waitForDisplayed();
      $(`//div[text()="${locationInputValue}"]`).waitForDisplayed();

      // validates the updated location is displayed properly on the drug wizard page
      const expectedLocation = currentLocation.includes('RANDOLPH') ? 'SOUTHPORT' : 'RANDOLPH';
      expect(currentLocationElement.getText()).toContain(expectedLocation);
    });

    it('selectors update when antecedent selector changes', () => {
      // change total quantity to something new
      browser.waitUntil(() => {
        $(`[data-component="DrugFiltersQuantity"] select`).click();

        browser.checkPageAccessibiltyViolations(violations, minorViolations);

        return $(`[data-component="DrugFiltersQuantity"] select`).isFocused();
      });
      browser.keys('5');

      // change the strength quantity... should trigger a reload of filters
      $(`[data-component="DrugFiltersStrength"] select`).click();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      $('option=250 MG').click();

      // wait until filters have reloaded
      $(`[data-component="DrugFiltersQuantity"] select`).waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      // make sure total quantity has refreshed
      expect($(`[data-component="DrugFiltersQuantity"] select`).getText()).not.toEqual('5');
    });

    it('will show drug on pricing page', () => {
      const hangTightModal = $('[data-component="hangTight"]');

      $('[data-component="DrugWizardSubmitButton"]').waitForDisplayed();
      $('[data-component="DrugWizardSubmitButton"]').click();

      // validate navigation to the generic drug pricing page
      browser.waitUntil(() => {
        $('[data-component="DrugPriceResultsHeader"]').waitForDisplayed();
        return !hangTightModal.isDisplayed();
      });

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      $('[data-component="DrugName"]').scrollIntoView();

      $('[data-component="DrugName"]').waitForDisplayed();
      expect($('//h1[contains(.,"Carisoprodol") and contains(.,"Generic")]').waitForDisplayed()).toBe(true);
    }, 2); // retry this test since it seems sometimes Optum BPE times out in INT the first time
  });

  describe('Pharmacy Locator', () => {
    beforeEach(() => {
      browser.url('/pharmacy-uhc/pharmacies');
      $('[data-component="PharmacySearchResults"]').waitForDisplayed();
    });

    it('will show updated location of the primary member', () => {
      const locationInput = $('(//form)[2]/input');
      const initialLocation = '200 E Randolph St, Chicago, IL 60601';
      const secondaryLocation = '3733 North Southport Avenue, Chicago, IL 60613';
      const currentLocationElement = $('[data-component="CurrentLocationParagraph"]');

      //gets the current location from the pharmacy locator page and assigns it to a variable
      $('[data-component="PharmacySearchContentItem"]').waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);
      // scroll back to the top of the page after violation check
      $('//h1[contains(.,"Results for Pharmacies Near")]').scrollIntoView();

      const currentLocation = currentLocationElement.getText().toUpperCase();

      //navigates to the change location page
      $('[data-component="ChangeLocationParagraphButton"]').click();
      $('[id="LocationSelectorHeader"]').waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);
      // scroll back to the top of the page after violation check
      $('[id="LocationSelectorHeader"]').scrollIntoView();

      //checks if current location is already set to the "Randolph St" address
      //before inputting this address, otherwise it will input the "Southport"
      // address. This will avoid updating and validating against a current location
      const locationInputValue = currentLocation.includes('RANDOLPH') ? secondaryLocation : initialLocation;
      locationInput.setValue(locationInputValue);
      $('[data-component="TypeaheadResultItem"]:first-child').waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      $('[data-component="TypeaheadResultItem"]:first-child').click();

      //saves the updated address and validates navigation back to the drug wizard page
      $('[data-component="ChangeLocationUpdateButton"]').waitForDisplayed();
      $('[data-component="ChangeLocationUpdateButton"]').click();
      currentLocationElement.waitForDisplayed();
      $('[data-component="CurrentLocationParagraph"]').waitForDisplayed();

      // validates the updated location is displayed properly on the drug wizard page
      const expectedLocation = currentLocation.includes('RANDOLPH') ? 'SOUTHPORT' : 'RANDOLPH';
      expect(currentLocationElement.getText().toUpperCase()).toContain(expectedLocation);
    });

    it('will search for pharmacy by name', () => {
      const pharmacyNameInput = $('(//form)[1]/input');
      const primarySearchTerm = 'walg';
      const secondarySearchTerm = 'cvs';
      const firstResultElement = $('[data-component="PharmacyLink"]');

      // choose search term that ensures the first result will change
      const searchTerm = firstResultElement.getText().includes('WALG') ? secondarySearchTerm : primarySearchTerm;

      // search on that search term
      pharmacyNameInput.setValue(searchTerm);

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      $('[data-component="SearchBarSubmitButton"]').click();

      // check that the result has the correct text
      $('[data-component="PharmacySearchResults"]').waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);
      // scroll back to the top of the page after violation check
      $('[data-component="PharmacySearchResults"]').scrollIntoView();

      expect(firstResultElement.getText()).toContain(searchTerm.toUpperCase());

      // navigate to the pharmacy details page
      firstResultElement.click();

      // check that the details page also has the correct text
      $('[data-component="PharmacyHeaderExpanded"]').waitForDisplayed();

      browser.checkPageAccessibiltyViolations(violations, minorViolations);

      expect($('[data-component="PharmacyHeaderExpanded"]').getText()).toContain(searchTerm.toUpperCase());
    });
  });

  describe('Session logout', () => {
    it('displays "continue" link', () => {
      browser.url('/pharmacy-uhc/session-logout');

      const logoutContinueLink = $('[data-component="SessionLogoutContinueLink"]');
      logoutContinueLink.waitForDisplayed();
      expect(logoutContinueLink.getAttribute('href')).toContain('myuhc.com');
    });
  });
});
