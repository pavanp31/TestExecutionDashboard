/**
 *
 * This is a storage for all final global constants.
 * NOTE: this file uses old-school require/exports syntax because it's accessed by wdio.conf.js which runs before babel
 */

module.exports = {
  // configuration
  IMPLICIT_WAIT_MILLISECONDS: 20 * 1000, // 20 seconds
  EXPLICIT_WAIT_MILLISECONDS: 40 * 1000, // 40 seconds
  MAX_EXPLICIT_WAIT_MILLISECONDS: 60 * 1000, // 60 seconds
  CONNECTION_RETRY_TIMEOUT_MILLISECONDS: 90 * 1000, // 90 seconds
  JASMINE_DEFAULT_TIMEOUT_INTERVAL_MILLISECONDS: 120 * 1000, // 2 minutes
  SMALL_WAIT_MILLISECONDS: 10 * 1000, // 10 seconds
  DEFAULT_PRIMARY_MEMBER: 'MEMBER KITCHENSINK',
  MNR_PRIMARY_MEMBER: 'RETIRED KITCHENSINK',
  FAKE_SESSION_URI: 'fakesso?hsid=fake-user-case-7',
  MNR_FAKE_SESSION_URI: 'fakesso?hsid=fake-mnr-case-1&rid=fake-mnr-case-1',
  MNR_PDP_FAKE_SESSION_URI: 'fakesso?hsid=fake-mnr-case-2&rid=fake-mnr-case-2',
  MNR_GROUP_FAKE_RETIREE_SESSION_URI: 'fakesso?hsid=fake-mnr-case-3&rid=fake-mnr-case-3',
  DRUGS: {
    zithromax: {
      url:
        'drugs/zithromax/details/prices?daySupply=5&form=Tablet&quantity=6&strength=250%20MG&productId=548ce911-7aed-3209-99f5-4ec16f3d626c',
      name: 'Zithromax',
      type: 'Brand'
    },
    atorvastatin: {
      url:
        'drugs/atorvastatin-calcium/details/prices?quantity=30&daySupply=30&productId=c10759fd-7f6f-311b-abaf-691fdfb8ee8c',
      name: 'Atorvastatin',
      type: 'Generic'
    },
    soma: {
      url:
        'drugs/soma/details/prices?daySupply=30&form=Tablet&quantity=90&strength=350%20MG&productId=104361c2-c2da-3151-9161-cabd2a65aa6a',
      name: 'Soma',
      type: 'Brand'
    },
    testim: {
      url:
        'drugs/testim/details/prices?daySupply=30&form=Gel&packageSize=5.00%20GM%20Tube&quantity=30&strength=50%20MG/5GM%20(1%25)&productId=abb490e0-dc10-38d7-ab82-79645e88e6ca',
      name: 'Testim',
      type: 'Brand',
      isMnr: true
    },
    testosterone: {
      url:
        'drugs/testosterone/details/prices?daySupply=30&form=Gel&packageSize=75.00%20GM%20Pump%20Btl&quantity=1&strength=20.25%20MG/ACT%20(1.62%)&productId=06de161d-b56d-3b3a-9c56-6f33b7e4fff4',
      name: 'Testosterone',
      type: 'Generic'
    },
    fluticasone_mnr: {
      url:
        'drugs/fluticasone-propionate/details/prices?daySupply=30&form=Suspension&packageSize=16.00%20GM%20Bottle&quantity=1&strength=50%20MCG/ACT&productId=2314403d-c76f-30cb-b0aa-6f2a7e79a7f4',
      name: 'Fluticasone Propionate',
      type: 'Generic',
      isMnr: true
    },
    nulojix_mnr: {
      url:
        'drugs/nulojix/details/prices?daySupply=28&form=Solution%20Reconstituted&packageSize=1.00%20EA%20Vial&quantity=1&strength=250%20MG&productId=6bbcac6c-ea1c-39d7-987b-cf7d47ba440b',
      name: 'Nulojix',
      type: 'Brand',
      isMnr: true
    },
    vraylar_pdp: {
      url:
        'drugs/vraylar/details/prices?daySupply=30&form=Capsule&quantity=30&strength=3%20MG&productId=8f23a558-ea4b-35d3-ad47-4c4f3d49770c',
      name: 'Vraylar',
      type: 'Brand',
      isMnr: true,
      isPdp: true
    },
    olanzapine_mnr: {
      url:
        'drugs/olanzapine/details/prices?daySupply=30&form=Tablet&quantity=30&strength=15%20MG&productId=d6259472-0b4b-35dc-af53-1ffdd4a0e10f',
      name: 'OLANZapine',
      type: 'Generic',
      isMnr: true
    },
    fluconazole_mnr_group: {
      url:
        'drugs/fluconazole/details/prices?daySupply=1&form=Tablet&quantity=1&strength=150%20MG&productId=1f0fc273-dc79-373d-a42e-581400872a49',
      name: 'Fluconazole',
      type: 'Generic',
      isMnr: true,
      isGroup: true
    }
  }
};
