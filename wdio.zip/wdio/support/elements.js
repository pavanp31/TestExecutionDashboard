module.exports = {
  get mapboxContainer() {
    return $('.mapboxgl-canvas');
  },
  get mapboxZoomOutControl() {
    return $('.mapboxgl-ctrl-zoom-out');
  },
  get pharmacyCards() {
    return $$('[data-component="PharmacySearchContentItem"]');
  },
  get pharmacyCardLinks() {
    return $$('[data-component="PharmacyLink"]');
  },
  get pharmacyListView() {
    return $('[data-component="PharmacySearchResults"]');
  },
  get pharmacyMapView() {
    return $('[data-component="PharmacySearchMapView"]');
  },
  get pharmacyMapContainer() {
    return $('[data-component="PharmacySearchMapContainer"]');
  },
  get pharmacyNumberOfResults() {
    return $('[data-component="PharmacySearchNumberOfResults"]');
  },
  get pharmacyViewToggle() {
    return $('[data-component="PharmacyViewToggleButton"]');
  },
  get pharmacySearchThisArea() {
    return $('[data-component="PharmacySearchMapViewSearchThisArea"]');
  }
};
