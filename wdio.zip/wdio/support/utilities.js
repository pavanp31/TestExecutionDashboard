const axe = require('wdio-axe');
// const util = require('util');
const fs = require('fs');
const deepEqual = require('deep-equal');
const _ = require('lodash');
const {
  DEFAULT_PRIMARY_MEMBER,
  MNR_PRIMARY_MEMBER,
  FAKE_SESSION_URI,
  IMPLICIT_WAIT_MILLISECONDS,
  MNR_FAKE_SESSION_URI,
  MNR_GROUP_FAKE_RETIREE_SESSION_URI,
  MNR_PDP_FAKE_SESSION_URI,
  SMALL_WAIT_MILLISECONDS,
  EXPLICIT_WAIT_MILLISECONDS
} = require('./constants');

// Run a test for a specific theme only.
// Sets the base URL for the theme prior to running the test.
// If running on a developer laptop, will simply run describe().
const describeWithSingleTheme = (theme, name, fn) => {
  if (browser.config.baseUrl.includes('localhost')) {
    describe(name, fn);
  } else {
    describe(theme, () => {
      // Cache the original baseUrl prior to test execution.
      const baseUrl = browser.config.baseUrl;

      beforeAll(() => {
        // Before testing, set the configured baseUrl to the themed url.
        const themedUrl = browser.config.themeBaseUrls[theme](baseUrl);
        browser.config.baseUrl = themedUrl;
        browser.options.baseUrl = themedUrl;
      });

      afterAll(() => {
        // After testing, reset the configured baseUrl to the original (unthemed) baseUrl.
        browser.config.baseUrl = baseUrl;
        browser.options.baseUrl = baseUrl;
      });

      // Execute the test.
      describe(name, fn);
    });
  }
};

// utility file for custom wdio commands
module.exports = {
  // wait for element then click button associated with the locator
  waitForElementThenClick: locator => {
    locator.scrollIntoView({ block: 'center' });
    locator.waitForDisplayed();
    locator.click();
  },

  // creates a new object array by removing duplicate objects
  uniqueObjectArray: arr => {
    let uniqueArray = [];
    arr.forEach(item => {
      let unique = true;
      uniqueArray.forEach(item2 => {
        if (deepEqual(item, item2)) {
          unique = false;
        }
      });
      if (unique) {
        uniqueArray.push(item);
      }
    });
    return uniqueArray;
  },

  // uses axe accessibilty testing engine to extract accessibilty violations
  checkPageAccessibiltyViolations: (violations, minorViolations) => {
    const violationsList = [];

    // gets the current page accessibility violations
    const result = axe.getViolations();

    // remove duplicate violation descriptions
    result.violations = [...new Set(result.violations.map(JSON.stringify))].map(JSON.parse);

    // check the severity of the violation
    result.violations.forEach(violation => {
      if (violation.impact && violation.impact != 'minor') {
        violationsList.push(result);
        violations.push(result);
      } else if (violation.impact && violation.impact == 'minor') {
        minorViolations.push(result);
      }
    });

    // The accessibility violation checks scrolls to the bottom of the page. This
    // causes issues for the tests when they try to click on elements and they
    // are above or below "the fold". This will restore the view of the page
    // to the very top of the browser window after every set of checks.
    $('#topOfRxWebApp').scrollIntoView();

    // fail the test if violations higher than minor are found
    // ** commenting out hard test failures for accessibility checks until
    //  issues related to https://jira.rallyhealth.com/browse/DARE-2565
    // have been resolved **
    // expect(violationsList.length).toBe(
    //   0,
    //   'accessibility violation found:',
    //   util.inspect(violationsList, { depth: null })
    // );
  },

  // creates a json file with all unique accessibility violations
  createViolationsReport: (violations, reportname) => {
    let outputFolder = './wdio/output/e2e-accessibility-results';
    if (reportname.includes('smoke')) outputFolder = './wdio/output/smoke-test';
    const filteredReport = browser.uniqueObjectArray(violations);
    if (filteredReport.length > 0) {
      fs.writeFileSync(`${outputFolder}/${reportname}`, JSON.stringify(filteredReport, null, 2), 'utf-8');
    }
  },

  createA11yViolationReports: (majorViolations, minorViolations, reportPrefix) => {
    browser.createViolationsReport(majorViolations, `${reportPrefix}-accessibilty-violations-report.json`);
    browser.createViolationsReport(minorViolations, `${reportPrefix}-minor-accessibility-violations-report.json`);
  },

  withRetries: (fn, maxRuns) => {
    let runs = 0;
    let errors = [];
    let shouldStop = false;
    let shouldError = false;

    const stop = () => {
      shouldStop = true;
    };

    const stopWithError = () => {
      stop();
      shouldError = true;
    };

    while (!shouldStop) {
      try {
        if (runs >= maxRuns) {
          stopWithError();
        } else {
          fn(stop, runs);
        }
      } catch (err) {
        errors = [...errors, err];
      } finally {
        runs++;
      }
    }

    if (shouldError) {
      throw new Error(`Retried action failed due to following errors: ${errors.join('; ')}`);
    }
  },

  getFakeSsoUrl: (config = {}) => {
    let fakeSsoUrl;

    const { isMnr, isPdp, isGroup } = config;

    if (isMnr & isPdp) {
      fakeSsoUrl = MNR_PDP_FAKE_SESSION_URI;
    } else if (isMnr & !isPdp & !isGroup) {
      fakeSsoUrl = MNR_FAKE_SESSION_URI;
    } else if (isMnr & isGroup) {
      fakeSsoUrl = MNR_GROUP_FAKE_RETIREE_SESSION_URI;
    } else {
      fakeSsoUrl = FAKE_SESSION_URI;
    }

    return fakeSsoUrl;
  },

  waitForMedicineCabinetToBeLoaded: (config = {}) => {
    const { isMnr } = config;

    const MEDICINE_CABINET_LOAD_MAX_RUNS = 2;

    browser.withRetries(stop => {
      // Remove any cookies before initializing a new session.
      browser.deleteCookies();

      browser.url(browser.getFakeSsoUrl(config));
      $('[data-component="NavigationButtonsList"]').waitForDisplayed({
        timeout: SMALL_WAIT_MILLISECONDS
      });

      $('[data-component="MedicineCabinet"]').waitForDisplayed({
        timeout: EXPLICIT_WAIT_MILLISECONDS
      });
      $('[data-component="MemberDrugItem"]').waitForDisplayed({
        timeout: EXPLICIT_WAIT_MILLISECONDS
      });

      if (isMnr) {
        // mnr kitchensink member has no dependents, verify that their name is present in the dropdown
        const singleMemberSelect = $('[data-component="Dropdown"] option');
        singleMemberSelect.waitForDisplayed();

        browser.waitUntil(() => singleMemberSelect.getText() === MNR_PRIMARY_MEMBER);
      } else {
        const showMedicationsSelect = $('[data-component="Dropdown"]').$('select');
        showMedicationsSelect.waitForDisplayed();

        browser.waitUntil(() => showMedicationsSelect.$$('option')[0].getText() === DEFAULT_PRIMARY_MEMBER);
      }

      if ($$('[data-component="MemberDrugItem"]').length > 0) {
        stop();
      }
    }, MEDICINE_CABINET_LOAD_MAX_RUNS);
  },

  waitForHangTightLoaderToAppearAndDisappear: () => {
    try {
      // first checks if the hangTight modal exists
      $('[data-component="HangTight"]').waitForDisplayed({
        timeout: SMALL_WAIT_MILLISECONDS
      });

      // The reverse parameter set to true makes it wait for it to not be displayed.  Can include the `interval` parameter with 2000 to increase speed locally (does not work for jenkins runs)
      $('[data-component="HangTight"]').waitForDisplayed({
        timeout: IMPLICIT_WAIT_MILLISECONDS,
        reverse: true
      });
    } catch {
      console.log(
        'Catching error thrown from waiting for hangTight-loader to close.  Continuing test, if hangTight loader is still truly up, test will fail downstream.'
      );
      // There have been tests ran that show tests complete even after this command fails.  Ignore error here.
      // If it fails it will take default timeout.  If the hangTight modal really is still up, it will fail later in the actual test.
    }
  },

  // Get a reference to the card with the given drug name
  getMedicineCard: drugName => {
    $('[data-component="MemberDrugItem"]').waitForDisplayed();

    const cards = $$('[data-component="MedicineCabinetCard"]').filter(card => card.getText().includes(drugName));

    expect(cards.length).toEqual(1);

    // this is required to fix "element not clickable at point?" issue for advantage theme
    cards[0].scrollIntoView({ block: 'center' });
    return cards[0];
  },

  setPharmacyLocation: location => {
    const locationInput = $('[placeholder="Street Address, City & State, Zip Code"]');
    const topTypeheadComponent = $('[data-component="TypeaheadResultItem"]:first-child');
    const changeLocationButton = $('[data-component="ChangeLocationParagraphButton"]');
    const updateLocationButton = $('[data-component="ChangeLocationUpdateButton"]');

    // navigates to the pharmacy change location page
    browser.waitForElementThenClick(changeLocationButton);
    $('[id="LocationSelectorHeader"]').waitForDisplayed();

    // sets the location input box and validates
    locationInput.setValue(location);
    expect(locationInput.getValue()).toBe(location);

    // selects the topmost location in the typehead component
    topTypeheadComponent.waitForDisplayed();
    topTypeheadComponent.click();

    // selects the update location button
    browser.waitForElementThenClick(updateLocationButton);

    // wait for modal to close
    changeLocationButton.waitForDisplayed();

    // wait for results to appear
    $('[data-component="PharmacySearchContentItem"]').waitForDisplayed();
  },

  resetPharmacyLocation: () => {
    if (
      !$('[data-component="CurrentLocationParagraph"]')
        .getText()
        .toLowerCase()
        .includes('randolph')
    ) {
      browser.setPharmacyLocation('200 E Randolph');
    }
  },

  waitForChangeLocation: () => {
    $('[data-component="ChangeLocation"]').waitForDisplayed();
  },

  toggleDevDrawerFeatureFlag: featureFlag => {
    $('[data-component="DevDrawerButton"]').waitForDisplayed();

    // Needs to be clicked three times
    $('[data-component="DevDrawerButton"]').click();
    $('[data-component="DevDrawerButton"]').click();
    $('[data-component="DevDrawerButton"]').click();

    $('#rxModal').waitForDisplayed();

    const checkbox = $(`[data-component="DevDrawerFeatureFlag"]*=${featureFlag}`).$('[data-component="Checkbox"]');

    checkbox.scrollIntoView({ block: 'center' });

    expect(checkbox.isExisting()).toBeTruthy();

    checkbox.click();

    expect(checkbox.getAttribute('aria-checked')).toEqual('false');

    $('[data-component="DevDrawerApplyButton"]').click();
  },

  goToNextPage: () => {
    browser.waitForElementThenClick($('[data-component="PaginationNextControl"]'));
  },

  startNewPharmacySearch: () => {
    browser.url(FAKE_SESSION_URI);

    browser.waitForElementThenClick($('#PharmaciesButton'));

    browser.waitForPharmacyLocatorPageToBeLoaded();
  },

  startNewDrugSearch: (config = {}) => {
    browser.url(browser.getFakeSsoUrl(config));

    browser.waitForElementThenClick($('#DrugSearchButton'));

    $('[data-component="Typeahead"]').waitForDisplayed();
  },

  waitForPharmacyLocatorPageToBeLoaded: () => {
    $('[data-component="Typeahead"]').waitForDisplayed();
    $('[data-component="PharmacySearchResults"]').waitForDisplayed();
    $('[data-component="PharmacySearchResults"]').scrollIntoView();
  },

  waitForPharmacyDetailsPageToBeLoaded: () => {
    $('[data-component="PharmacyHeaderExpanded"]').waitForDisplayed();
  },

  goToPharmacyDetailsFromSearch: (index = 0) => {
    browser.waitForElementThenClick($$('[data-component="PharmacyLink"]')[index]);
  },

  getPharmacyNameFromSearch: (index = 0) => {
    return $$('[data-component="PharmacyName"]')
      [index].getText()
      .toUpperCase();
  },

  getPharmacyNameFromDetails: () => {
    return $('[data-component="PharmacyName"]')
      .getText()
      .toUpperCase();
  },

  getPharmacyQueryTypeIdentifierFromSearch: (index = 0) => {
    return $$('[data-component="PharmacyNumber"]')[index].getText();
  },

  navigateToDrugPrices: config => {
    const { url, name, type, isMnr, isPdp, isGroup } = config;

    browser.waitForMedicineCabinetToBeLoaded({ isMnr, isPdp, isGroup });
    browser.url(url);

    browser.waitForHangTightLoaderToAppearAndDisappear();

    $('[data-component="DrugName"]').waitForDisplayed();
    $(`//h1[contains(.,"${name}") and contains(.,"${type}")]`).waitForDisplayed();
  },

  nagivateToRefillsDirectly: () => {
    browser.url(browser.getFakeSsoUrl());
    browser.url('refills');

    $('[data-component="RefillsOrderSummary"]').waitForDisplayed();
  },

  doTypeaheadSearch: term => {
    $('[data-component="Typeahead"]').waitForDisplayed();

    $('[data-component="SearchBarInput"]').setValue(term);

    $('[data-component="TypeaheadResults"]').waitForDisplayed();
  },

  doTypeaheadSearchAndSubmit: term => {
    browser.doTypeaheadSearch(term);

    $('[data-component="SearchBarSubmitButton"]').click();

    $('[data-component="PharmacySearchResults"]').waitForDisplayed();
  },

  doTypeaheadSearchAndClickOnResult: (term, index = 0) => {
    browser.doTypeaheadSearch(term);

    browser.waitForElementThenClick($$('[data-component="TypeaheadResultItem"]')[index]);
  },

  selectTypeaheadAddOnOption: optionText => {
    browser.waitForElementThenClick($('[data-component="TypeaheadDropdownToggleButton"]'));
    browser.waitForElementThenClick($(`//button[contains(text(),"${optionText}")]`));
  },

  verifyBasicModalExists: (cta, title) => {
    browser.waitForElementThenClick($(`[data-component="${cta}"]`));
    $(`#ModalBasicHeader*=${title}`).waitForDisplayed();
    browser.waitForElementThenClick($('.close-button'));
  },

  clickBackButton: () => {
    const button = $('[data-component="BackButton"]');

    button.scrollIntoView();

    browser.waitForElementThenClick(button);
  },

  hasUHCTheme: () => $('.arcade-chrome-root').isExisting(),

  // iPhone X as it appears in Chrome browser responsive tools
  resizeScreenToMobileDevice: () => browser.setWindowSize(375, 812),

  resizeScreenToNonMobileDevice: () => browser.setWindowSize(1300, 1300),

  // Run a test for a specific theme only.
  // Sets the base URL for the theme prior to running the test.
  // If running on a developer laptop, will simply run describe().
  describeWithSingleTheme: describeWithSingleTheme,

  // Run a test across all themes.
  // Will set the base URL for the given theme before running.
  // If running on a developer laptop, will simply run describe().
  describeWithThemes: (name, fn) => {
    if (browser.config.baseUrl.includes('localhost')) {
      describe(name, fn);
    } else {
      Object.keys(browser.config.themeBaseUrls).forEach(theme => describeWithSingleTheme(theme, name, fn));
    }
  },

  // convert a base URL into a UHC url
  makeUhcUrl: baseUrl => {
    const parts = baseUrl.split('.');
    const domain = parts[0] + '-uhc.' + parts.slice(1).join('.');
    return _.trimEnd(domain, '/') + '/pharmacy-uhc/';
  },

  // convert a base URL into an Advantage url
  makeAdvantageUrl: baseUrl => baseUrl
};
