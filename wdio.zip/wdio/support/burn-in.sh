#!/bin/bash

if [[ $1=="advantage" ]]
then
  while yarn wdio --baseUrl https://rx.jolly-flower.rally-dev.com --spec $2; do :; done
else
  while yarn wdio --spec $2; do :; done
fi