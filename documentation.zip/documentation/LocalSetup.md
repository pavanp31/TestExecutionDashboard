# Local setup

## Proxied backend

If you want to run `rx-ui` locally without a local backend, you will need to start and configure `playproxy` to proxy UI requests to a remote backend.

### playproxy set up

Add the following to `/etc/hosts`:

```
127.0.0.1  connect.localhost
127.0.0.1  rx.localhost
127.0.0.1  arcade.localhost
127.0.0.1  api.arcade.localhost
127.0.0.1  coaching.localhost
127.0.0.1  mayo.localhost
127.0.0.1  who.localhost
```

Add the following to `/etc/careverge/playproxy.conf`:

```
proxy.includes.rules.rx.int.target="https://rx.jolly-flower.rally-dev.com"
```

### Running playproxy

```
$ docker run --rm -p 9001:9000 docker.werally.in/chopshop/playproxy
```

To start playproxy where everything points to an environment eg. jolly-flower

```
$ rx playproxy jolly-flower
```

## Installation

Install and update dependencies via the local install script:

```
$ ./install-local.sh
```

### Manual installation

If needed, you can manually run:

```
$ yarn install
```

## Running

### With the UHC theme

```
$ yarn start
```

### With the Advantage (Rally) theme

```
$ yarn start-rally
```

## Unit Testing

```
$ yarn test
```

## Linting

Rx uses [`husky`](https://github.com/typicode/husky) to manage `git` hooks and run linting before every commit.
Configured with [`.huskyrc.js`](/.huskyrc.js).

[`lint-staged`](https://github.com/okonet/lint-staged) is used to map file patterns to linter commands.
Configured with [`.lintstagedrc`](/.lintstagedrc).

Jenkins (CI) invokes `yarn lint` to run all defined linters.

Linters used:

- [`prettier`](https://prettier.io): format source code (JavaScript, TypeScript, JSON)
- [`htmlhint`](https://github.com/htmlhint/HTMLHint): HTML static analyzer

## Building the application

To build the production application:

```
$ yarn build
```

To build all the various themed production application versions:

```
$ yarn build-all
```

This script is also used to create docker images.
