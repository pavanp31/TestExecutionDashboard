# Accessibility

[TODO DARE-2995:](https://jira.rallyhealth.com/browse/DARE-2995) expand this documentation section.

## Truncating Content

[Shave](https://github.com/dollarshaveclub/shave#syntax) is used to truncate text in the specified element:

```javascript
shave(containerSelector, containerMaxHeight);
```
