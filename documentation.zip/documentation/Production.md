# Deploying to production

Simply pick your version and deploy it as a Neptune component to your favorite tenant using the [DeployComponent](https://ci.rally-dev.com/teams-deploys/job/deploys/job/DeployComponent/job/master/) job.

#### Behind the scenes

The application code is built with `yarn build` as a static artifact.
The artifact is copied into an [nginx](https://www.nginx.com/) docker image and published to [Artifactory](https://artifacts.werally.in/).

```
docker.werally.in/rx/rx-ui:latest
docker.werally.in/rx/rx-ui:<version>
```

When deployed on production, the docker container is started up with the deploy scripts in [`docker/default/deploy/`](/docker/default/deploy) to read configurations from the environment.
