# Styling

## Styling Gotchas

Some tips and tricks for working with `emotion`.

### Backticks and Styled from Emotion

When using `styled` from `emotion` you would typically do something like this:

```javascript
export const MyStyledComponent = styled('div')`
  width: 100%;
`;
```

And if you needed to extend the styles on a styled component you would do this:

```javascript
export const MyStyledComponent = styled('div')`
  width: 100%;
`;

export const MyExtensionOfMyStyledComponent = styled(MyStyledComponent)`
  width: 50%;
`;
```

But if you try to do this, it will throw a javascript error:

```javascript
export const MyExtensionOfMyStyledComponent = styled(MyStyledComponent);
```

Why? It's because the backticks after `styled()` are missing. They are always required.

## Styling Utilities

These are some helpful utilities that are located in `src/js/util/styles/index.tsx` that help with making our lives easier with regards to following proper HTML css styling.

### Applying a custom class to a Styled Component using withClass

Currently we are unable to get any packages installed that would be able to automatically apply custom css class names using the name of the styled component, so the `withClass` utility was created.

While it is not as a ideal as automatic css class names (still a work in progress), you can now assign css class names via wrapping the styled component with this utility.

Benefits to doing this include being able to globally target certain CSS classes in the `globals` theme files, and a more semantic approach to targeting components inside styled components without relying upon the outdated `data-component` approach. See the [E2E testing](E2E.md) documentation for more information on this.

#### Wrapping a styled component

Here are the scenarios that you will encounter in daily UI work when needing to apply the utility:

```javascript
import { withClass, withThemeStyles } from './util';

export const MyStyledComponent = withClass('some-custom-class')(styled('div')`
  background: red;
`);

export const MyExtensionOfOtherStyledComponent = withClass('some-custom-class')(styled(OtherStyledComponent)`
  height: 100px;
`);

export const MyStyledThemedComponent = withClass('some-custom-class')(
  withThemeStyles('components.MyStyledThemedComponent')(styled('div')`
    width: auto;
  `)
);
```

Note: do not include the period `.` in the custom class name.
