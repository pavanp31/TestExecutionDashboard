# E2E Testing

## WebDriverIO

Rx uses [WebdriverIO (WDIO)](https://webdriver.io/) for end-to-end (E2E) testing.
The WDIO configuration is defined in `wdio.conf.js`.

The suite is configured to run against local by default:

```
$ yarn wdio
```

But can also be run against (sub)tenants:

```
$ SUBTENANT=...
$ TENANT=...

# UHC theme
$ yarn wdio --baseUrl  https://rx-${SUBTENANT}-uhc.${TENANT}.rally-dev.com/pharmacy-uhc/

# Advantage (rally) theme
$ yarn wdio --baseUrl https://rx-${SUBTENANT}.${TENANT}.rally-dev.com
```

## Smoke testing

Smoke tests exercise the basic functionalities of Rx services.
The tests should never cover any user-specific behavior, e.g. asserting exact price of a drug.

### Running on Jenkins

Run the [rx-smoke-tests](https://ci.rally-dev.com/teams-rx/job/rx/job/Tests/job/rx-smoke-tests/) job on Jenkins.
This will smoke test integration using a test user of your choice, simply plug in the Rally Id.
The results of the smoke test are repoted using Allure, similar to End to End tests.

### Running locally

If you need to run the smoke tests against production or UAT, you will need to run them locally so you can input your production credentials.
If you want to smoke the integration between Arcade and Rx on integration, you will also need to run them locally.

Pick the appropriate invocation and run it.
You will need to log in using the appropriate environmental credentials and wait until the test completes.
No further user interaction after logging in and providing 2FA should be required.

Test results and screenshots will not be written to an output file due to sensitive material.

#### Named environments

```
$ yarn wdio-smoke --baseUrl https://member.int.uhc.com  # Run against integration.
$ yarn wdio-smoke --baseUrl https://member.uat.uhc.com  # Run against UAT.
$ yarn wdio-smoke --baseUrl https://member.uhc.com      # Run against production.
```

#### Tenants and subtenants

```
$ SUBTENANT=...
$ TENANT=...

# UHC theme
$ yarn wdio-smoke --baseUrl  https://rx-${SUBTENANT}-uhc.${TENANT}.rally-dev.com/pharmacy-uhc/

# Advantage (rally) theme
$ yarn wdio-smoke --baseUrl https://rx-${SUBTENANT}.${TENANT}.rally-dev.com
```

##### Using fakesso

If you want to run the smoke tests against an arbitrary environment that has fakesso enabled, you can specify any `baseUrl` that will result in a logged-in user landing on the RallyRx dashboard page.
For example:

```
$ SUBTENANT=...
$ TENANT=...

# UHC theme
$ yarn wdio-smoke --baseUrl  https://rx-${SUBTENANT}-uhc.${TENANT}.rally-dev.com/pharmacy-uhc/fakesso?hsid=fake-user-case-2

# Advantage (rally) theme
$ yarn wdio-smoke --baseUrl https://rx-${SUBTENANT}.${TENANT}.rally-dev.com/fakesso?hsid=fake-user-case-2
```

## Writing E2E and smoke tests

A common cause of unreliable tests against a single-page application is _timing_.
Even though we write our tests to run synchronously, the dynamic nature of a SPA can make reliable assertions more difficult.
This is further complicated by driving a modern browser in a resource-constrained environment, where things like
DOM changes/animations may take longer than expected.

An easy defense against timing issues is redundancy.
Don't assume things will sort themselves out after a fixed timeout.

```javascript
browser.pause(5000); // don't do this
```

> It is recommended to not use this command to wait for an element to show up.
> In order to avoid flaky test results it is better to use commands like `waitforExist` or other `waitFor*` commands.

The following two blocks have the same effect, but this version will fail intermittently due to timing issues:

```javascript
browser.url('/search');
searchBox.click();
browser.keys('some text');
```

This version is more resilient to timing issues, by blocking the test until `searchBox` element is focused:

```javascript
browser.url('/search');
browser.waitUntil(() => {
  searchBox.click(); // NOTE a single .click() call fails to focus the input ~5% of the time
  return searchBox.isFocused();
});
browser.keys('some text');
```

WebdriverIO has a built-in [retry mechanism](https://webdriver.io/docs/retry.html) _that we should avoid if possible_ lest we normalize unreliable tests.

Whenever you add a new E2E test, it's a good idea to "burn-in" the test to ensure reliability.
You can use this command to run a single spec repeatedly until failure:

```
$ yarn wdio-burn-in change-location.test.js
```

For Advantage theme:

```
$ yarn wdio-burn-in-advantage change-location.test.js
```

Or use this command to run the entire test suite repeatedly until it fails:

```
$ yarn wdio-burn-in
```

For Advantage theme:

```
$ yarn wdio-burn-in-advantage
```

### Removing data-component and using classes

At the beginning of writing our e2e tests in Cypress (now deprecated in favor of WDIO) we needed
a way to target the HTML elements. At the time we were unable to get any packages installed that
were able to automatically apply custom css class names using the name of the styled component, so
we started using the `data-component` attribute.

The usual role of the `data-` attribute in web development is to store information about the HTML element so that various plugins or other tools do not have to worry about a data storage set up like Redux. You can see these used extensively in frameworks such as Twitter Bootstrap (which uses jQuery), and other vanilla JS plugins. It has other uses, but this is usually the most common.

However, this is not what we really need in our situation.

To combat the use of `data-component` (which is now slowly being deprecated) in our React templates, we created the `withClass` utility. See the [Styling](Styling.md) documentation for more information on how to use it.

This way we can use semantic CSS class names and still achieve the same test targeting goals.

## Testing against themes

`describeWithSingleTheme` will execute a test suite only for a specific theme. This is useful for M&R tests which should only be executed against the UHC (Blue) theme.

```
const { describeWithSingleTheme } = require('../../support/utilities');

describeWithSingleTheme('uhc', 'Test Suite', () => {
  ...
});
```

`describeWithThemes` will execute a test suite against all known themes. If your test doesn't need to target one theme in particular, you should use this function instead of the standard `describe` function in almost all cases.

```
const { describeWithThemes } = require('../../support/utilities');

describeWithThemes('Test Suite', () => {
  ...
});
```

## Debugging tests

You can specify the environment variable `DEBUG=true` to help diagnose failing tests by running the tests sequentially and with more logging.

```
$ DEBUG=true yarn wdio
```

You may want to remove the `--headless` flag from `wdio.conf.js` to see the tests being executed in a browser on your desktop.

If things are still going poorly, you can use [`browser.debug()` within the test](https://webdriver.io/docs/debugging.html) to manually inspect browser state.

Test logs and output are written to `wdio/output`. The `output/*-browser.log` files and `output/screenshots` directory are a good place to start investigating a failing test.

```
wdio
└── output
   ├── junit-results
   │   ├── wdio-0-0-browser.log
   │   ├── wdio-0-0-junit-reporter.log
   │   ├── wdio-0-0-server.log
   │   └── ...
   └── screenshots
   ├── drug-pricing-retail-will-show-controls-1567613390979.png
   ├── home-page-will-show-localization-modal-1567613395037.png
   └── ...
```

Depending on how many tests exist and the degree of parallelism, output from many tests may be found in the same `wdio-N-N-*.log` files.
You can correlate test failures to these files by looking at the test output e.g.

```
[chrome #0-0] Spec: /Users/lucky.you/code/rx-ui/wdio/tests/change-location.test.js
[chrome #0-0] Running: chrome
[chrome #0-0][chrome #0-0] Drug Wizard: Change Location
[chrome #0-0] ✖ search input box will contain keyed input
[chrome #0-0][chrome #0-0] 1 failing (3.6s)
[chrome #0-0][chrome #0-0] 1) Drug Wizard: Change Location search input box will contain keyed input
[chrome #0-0] Expected '123 Test St' to be '123 Test St.'.
[chrome #0-0] Error: Expected '123 Test St' to be '123 Test St.'.
[chrome #0-0] at <Jasmine>
[chrome #0-0] at UserContext.it (/Users/taylor.wood/code/rx-ui/wdio/tests/change-location.test.js:22:34)
```

The `[chrome #0-0]` prefix indicates which runner/log to inspect i.e. `wdio-0-0-browser.log`.
