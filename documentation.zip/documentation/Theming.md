# Theming

New utilities were added in order to enable customizing a Styled Component for a specific theme, and for importing theme-specific icons into a React Component.

These new utilities are located in `src/js/util/theme/index.ts`, and they are `withThemeStyles` and `withThemeIcon`.

## Starting the app with a specific theme

Load the default UHC theme:

```
$ yarn start
```

Load the Advantage (rally) theme:

```
$ yarn start-rally
```

## Customizing styled components

### Adding custom stylesheets for themes

The best way to code the custom styles for a specific theme for a styled component would be to create a new styles file next to the currently existing one.

```
/src
  /js
    /components
      /someNewComponent
        styles.ts
        styles.rally.ts
```

Once the file is created, open the `src/js/themes/rally/theme.ts` file and add the following lines:

```javascript
// src/js/themes/rally/theme.ts
import * as SomeNewComponent from 'js/components/SomeNewComponet/styles.rally';

import { getStyles } from '../styles';
// ...
import styles from './styles';

const theme = {
  // ...
  styles: {
    ...styles,
    SomeNewComponet
  },
  getStyles
};
```

Once the custom stylesheet is set in the themes theme file you can then use the `getStyles` method on the `props` object.

```javascript
// src/js/components/someNewComponent/styles.ts

export const MyStyledParagraph = styled('p')`
  color: red;

  ${props => props.theme.getStyles(props, 'SomeNewComponent.MyStyledParagraph')}
`;
```

### Using `withThemeStyles` utility

In order to customize a Styled Component you want to use `withThemeStyles` by wrapping it around the original styles for the styled component.

The first argument is the dot-notated object structure within the theme file in `src/js/themes/{theme}/styles.js`.
The second argument is the original styles for the Styled Component.

If the first argument is a non-existent object structure, then `''` will be returned within `withThemeStyles`.

#### Wrapping a `styled` styled component

```javascript
export const MyStyledParagraph = withThemeStyles('ui.paragraphs.MyStyledParagraph')(styled('p')`
  color: red;
`);
```

#### Wrapping a `css` styled component

If the styled component was using the `css` method from emotion, then you would use `withThemeStyles` like so:

```javascript
const MyStyledParagraph = props =>
  css`
    ${withThemeStyles('ui.paragraphs.MyStyledParagraph')(`
  color: red;
`)}
  `;
```

## Importing theme-specific icons using `withThemeIcon`

Sometimes a theme might need a different icon.
For example, one theme might use a triangle as a down arrow, while another theme might use a chevron as a down arrow.

The only argument is the dot-notated object structure within the theme file in `src/js/themes/{theme}/icons.ts`.

### Using `withThemeIcon`

```javascript
...
render() {
  const Icon = withThemeIcon('ui.dropdown.toggle');

  return (
    <div>
      <Icon role="img" />
    </div>
  );
};
...
```
