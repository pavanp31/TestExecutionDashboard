// @flow

declare var driver: Object;
declare type WDSelector = string | () => mixed;
declare type WDElement = Object;
declare type WDAction = {
  action: 'moveTo' | 'release' | 'press' | 'tap' | 'wait',
  options?: WDActionOptions,
};
declare type WDActionOptions = {
  element?: string,
  x?: number,
  y?: number,
  count?: number,
};
declare function $(selector: WDSelector): WDElement;
declare function $$(selector: WDSelector): Array<WDElement>;
