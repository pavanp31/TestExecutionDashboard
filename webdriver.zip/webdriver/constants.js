// @flow

// The default wait is 16000ms, set in wdio.shared.conf.js
export const SHORT_WAIT = 2000;
export const MED_WAIT = 4000;
export const LONG_WAIT = 8000;
export const EXTRA_LONG_WAIT = 36000;
export const SUPER_LONG_WAIT = 60000;

export const SMALL_MARGIN = 20;
export const MED_MARGIN = 50;
export const LARGE_MARGIN = 120;

export const ScrollDirection = {
  UP: -1,
  DOWN: 1,
};

export const textSearchTerm = 'Fox';
