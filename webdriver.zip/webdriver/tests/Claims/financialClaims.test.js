// @flow
import NavDrawerScreen from '../../screenobjects/navDrawer.screen';
import ManageClaimsScreen from '../../screenobjects/claims/manageClaims.screen';
import FinancialClaimsScreen from '../../screenobjects/claims/financialClaims.screen';

import { signIn } from '../../interactions/signIn.actions';

describe('Financial Claims', () => {
  beforeAll(() => {
    driver.reset();
    signIn();
  });

  beforeEach(() => {
    NavDrawerScreen.openNavDrawer();
    NavDrawerScreen.dashboardLink.waitForEnabled();
    NavDrawerScreen.manageClaimsLink.click();
  });

  it('should display some claim summaries in the FSA HC tab', () => {
    ManageClaimsScreen.fsahcTab.waitForDisplayed();
    ManageClaimsScreen.fsahcTab.click();
    expect(FinancialClaimsScreen.fsahcClaimDetailsLinks.length).toBeGreaterThan(
      0,
    );
  });

  it('should display "no claims available" message in the HRA tab', () => {
    ManageClaimsScreen.hraTab.waitForDisplayed();
    ManageClaimsScreen.hraTab.click();
    ManageClaimsScreen.noClaimsAvailable.waitForDisplayed();
  });
});
