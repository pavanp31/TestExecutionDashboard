// @flow

import NavDrawerScreen from '../../screenobjects/navDrawer.screen';
import ManageClaimsScreen from '../../screenobjects/claims/manageClaims.screen';

import { signIn } from '../../interactions/signIn.actions';

describe('Manage Claims', () => {
  beforeAll(() => {
    driver.reset();
    signIn();
  });

  describe('Manage Claims Screen', () => {
    beforeEach(() => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.waitForEnabled();
      NavDrawerScreen.manageClaimsLink.click();
    });

    it('Should display the Claims header title', () => {
      expect(ManageClaimsScreen.screenHeader.waitForDisplayed()).toBe(true);
    });
  });
});
