// @flow

import NavDrawerScreen from '../../screenobjects/navDrawer.screen';
import ResultsListScreen from '../../screenobjects/resultsList.screen';
import ResultsMapScreen from '../../screenobjects/resultsMap.screen';
import VirtualVisitsWelcomeScreen from '../../screenobjects/virtualVisits/virtualVisitsWelcome.screen';

import AreaOfBodyScreen from '../../screenobjects/fpc/areaOfBody.screen';
import CareByConditionScreen from '../../screenobjects/fpc/careByCondition.screen';
import CostEstimatesScreen from '../../screenobjects/fpc/costEstimates.screen';
import FindMedicalCareScreen from '../../screenobjects/fpc/findMedicalCare.screen';
import FindUrgentCareScreen from '../../screenobjects/fpc/findUrgentCare.screen';
import FindMentalHealthCareScreen from '../../screenobjects/fpc/findMentalHealthCare.screen';
import FindPeopleScreen from '../../screenobjects/fpc/findPeople.screen';
import FindPlacesScreen from '../../screenobjects/fpc/findPlaces.screen';
import FindServicesAndTreatmentsScreen from '../../screenobjects/fpc/findServicesAndTreatments.screen';
import TypeOfConditionScreen from '../../screenobjects/fpc/typeOfCondition.screen';

import { signIn } from '../../interactions/signIn.actions';

describe('Guided Search', () => {
  beforeAll(() => {
    driver.reset();
    signIn();
  });

  describe('Find Medical Care', () => {
    beforeEach(() => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.waitForEnabled();
      NavDrawerScreen.medicalCareLink.click();
      NavDrawerScreen.medicalCareLink.waitForDisplayed(true);
    });

    it('should show the medical care category buttons', () => {
      FindMedicalCareScreen.findCareNearHeader.waitForDisplayed();
      expect(FindMedicalCareScreen.currentLocationButton.isEnabled()).toBe(
        true,
      );
      expect(FindMedicalCareScreen.categoriesHeader.isDisplayed()).toBe(true);
      expect(FindMedicalCareScreen.peopleButton.isEnabled()).toBe(true);
      expect(FindMedicalCareScreen.placesButton.isEnabled()).toBe(true);
      expect(
        FindMedicalCareScreen.servicesAndTreatmentsButton.isEnabled(),
      ).toBe(true);
      expect(FindMedicalCareScreen.careByConditionButton.isEnabled()).toBe(
        true,
      );
      expect(FindMedicalCareScreen.costEstimatesButton.isEnabled()).toBe(true);
    });

    describe('for People:', () => {
      beforeEach(() => {
        FindMedicalCareScreen.peopleButton.waitForEnabled();
        FindMedicalCareScreen.peopleButton.click();
        FindMedicalCareScreen.peopleButton.waitForDisplayed(true);
      });

      it('should show all People category buttons', () => {
        expect(FindPeopleScreen.primaryCareButton.isEnabled()).toBe(true);
        expect(FindPeopleScreen.specialityCareButton.isEnabled()).toBe(true);
        expect(FindPeopleScreen.medicalGroupsButton.isEnabled()).toBe(true);
        expect(FindPeopleScreen.virtualVisitsButton.isEnabled()).toBe(true);
      });

      it('Primary Care should link to Results List', () => {
        FindPeopleScreen.primaryCareButton.click();
        FindPeopleScreen.allPrimaryCarePhysicians.waitForDisplayed();
        FindPeopleScreen.allPrimaryCarePhysicians.click();
        FindPeopleScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Specialty Care should link to Results List', () => {
        FindPeopleScreen.specialityCareButton.click();
        FindPeopleScreen.getElementByText('Acupuncturist').click();
        FindPeopleScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Medical Groups should link to Results List', () => {
        FindPeopleScreen.medicalGroupsButton.click();
        FindPeopleScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Virtual Visits should link to Welcome to Virtual Visits', () => {
        FindPeopleScreen.virtualVisitsButton.click();
        expect(
          VirtualVisitsWelcomeScreen.getStartedButton.waitForEnabled(),
        ).toBe(true);
      });
    });

    describe('for Places:', () => {
      beforeEach(() => {
        FindMedicalCareScreen.placesButton.waitForEnabled();
        FindMedicalCareScreen.placesButton.click();
        FindMedicalCareScreen.placesButton.waitForDisplayed(true);
      });

      it('should show all Places category buttons', () => {
        expect(FindPlacesScreen.clinicsButton.isEnabled()).toBe(true);
        expect(FindPlacesScreen.hospitalsButton.isEnabled()).toBe(true);
        expect(FindPlacesScreen.specialtyCentersButton.isEnabled()).toBe(true);
        expect(FindPlacesScreen.labsAndImagingButton.isEnabled()).toBe(true);
        expect(FindPlacesScreen.medicalSuppliersButton.isEnabled()).toBe(true);
      });

      it('Primary Care Clinic should link to Results List', () => {
        FindPlacesScreen.clinicsButton.click();
        FindPlacesScreen.primaryCareClinic.waitForEnabled();
        FindPlacesScreen.primaryCareClinic.click();
        FindPlacesScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Convenience Clinic should link to Results List', () => {
        FindPlacesScreen.clinicsButton.click();
        FindPlacesScreen.convenienceClinic.waitForEnabled();
        FindPlacesScreen.convenienceClinic.click();
        FindPlacesScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Urgent Care Clinic should link to Results List', () => {
        FindPlacesScreen.clinicsButton.click();
        FindPlacesScreen.urgentCareClinic.waitForEnabled();
        FindPlacesScreen.urgentCareClinic.click();
        FindPlacesScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Virtual Visits Clinics should link to Welcome to Virtual Visits', () => {
        FindPlacesScreen.clinicsButton.click();
        FindPlacesScreen.virtualVisits.waitForEnabled();
        FindPlacesScreen.virtualVisits.click();
        expect(
          VirtualVisitsWelcomeScreen.getStartedButton.waitForEnabled(),
        ).toBe(true);
      });

      it('Hospitals should link to Results List', () => {
        FindPlacesScreen.hospitalsButton.click();
        FindPlacesScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Specialty Centers should link to Results List', () => {
        FindPlacesScreen.specialtyCentersButton.click();
        FindPlacesScreen.getElementByText(
          'Ambulatory Surgical Center',
        ).waitForEnabled();
        FindPlacesScreen.getElementByText('Ambulatory Surgical Center').click();
        FindPlacesScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Imaging Centers should link to Results List', () => {
        FindPlacesScreen.labsAndImagingButton.click();
        FindPlacesScreen.getElementByText('Imaging Centers').waitForEnabled();
        FindPlacesScreen.getElementByText('Imaging Centers').click();
        FindPlacesScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Lab Locations should link to Results List', () => {
        FindPlacesScreen.labsAndImagingButton.click();
        FindPlacesScreen.getElementByText('Lab Locations').waitForEnabled();
        FindPlacesScreen.getElementByText('Lab Locations').click();
        FindPlacesScreen.waitForLoading();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });
    });

    describe('for Services and Treatments:', () => {
      beforeEach(() => {
        FindMedicalCareScreen.placesButton.waitForEnabled();
        FindMedicalCareScreen.servicesAndTreatmentsButton.waitForEnabled();
        FindMedicalCareScreen.servicesAndTreatmentsButton.click();
        FindMedicalCareScreen.servicesAndTreatmentsButton.waitForDisplayed(
          true,
        );
      });

      it('should show all Services and Treatments buttons', () => {
        expect(
          FindServicesAndTreatmentsScreen.officeVisitsButton.isEnabled(),
        ).toBe(true);
        expect(FindServicesAndTreatmentsScreen.vaccinesButton.isEnabled()).toBe(
          true,
        );
        expect(
          FindServicesAndTreatmentsScreen.testsAndImagingButton.isEnabled(),
        ).toBe(true);
      });

      it('Office Visits should link to Results List', () => {
        FindServicesAndTreatmentsScreen.officeVisitsButton.click();
        FindServicesAndTreatmentsScreen.wellVisitButton.click();
        FindServicesAndTreatmentsScreen.getElementByText(
          'Primary Care Clinic',
        ).waitForEnabled();
        FindServicesAndTreatmentsScreen.getElementByText(
          'Primary Care Clinic',
        ).click();
        ResultsListScreen.filterButton.waitForDisplayed();
        expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
      });

      it('Vaccines should link to View Cost List', () => {
        FindServicesAndTreatmentsScreen.vaccinesButton.click();
        FindServicesAndTreatmentsScreen.adultVaccinesButton.waitForEnabled();
        FindServicesAndTreatmentsScreen.adultVaccinesButton.click();
        FindServicesAndTreatmentsScreen.chickenpoxVaccineButton.waitForEnabled();
        FindServicesAndTreatmentsScreen.chickenpoxVaccineButton.click();
        ResultsListScreen.viewCost.waitForEnabled();
        expect(ResultsListScreen.viewCost.isEnabled()).toBe(true);
      });
    });

    describe('for Care by Condition:', () => {
      beforeEach(() => {
        FindMedicalCareScreen.careByConditionButton.waitForEnabled();
        FindMedicalCareScreen.careByConditionButton.click();
      });

      it('should show all Care by Conditions buttons', () => {
        expect(
          CareByConditionScreen.whatTreatmentHeader.waitForDisplayed(),
        ).toBe(true);
        expect(CareByConditionScreen.areaOfBodyButton.isEnabled()).toBe(true);
        expect(CareByConditionScreen.typeOfConditionButton.isEnabled()).toBe(
          true,
        );
      });

      it('Area of Body buttons should lead to View Cost List', () => {
        CareByConditionScreen.areaOfBodyButton.click();
        AreaOfBodyScreen.areaOfBodyHeader.waitForDisplayed();
        AreaOfBodyScreen.bladderKidneyUrinaryButton.click();
        AreaOfBodyScreen.getElementByText(
          'Bacterial Culture - Urine Test',
        ).click();
        ResultsListScreen.viewCost.waitForEnabled();
        expect(ResultsListScreen.viewCost.isEnabled()).toBe(true);
      });

      it('Type of Condition buttons should lead to View Cost List', () => {
        CareByConditionScreen.typeOfConditionButton.click();
        TypeOfConditionScreen.typeOfConditionHeader.waitForDisplayed();
        TypeOfConditionScreen.allergiesButton.click();
        TypeOfConditionScreen.getElementByText('Allergic Rash').click();
        ResultsListScreen.viewCost.waitForEnabled();
        expect(ResultsListScreen.viewCost.isEnabled()).toBe(true);
      });
    });

    describe('for Cost Estimates:', () => {
      beforeEach(() => {
        FindMedicalCareScreen.costEstimatesButton.waitForEnabled();
        FindMedicalCareScreen.costEstimatesButton.click();
      });

      it('should show Cost Estimate category buttons', () => {
        expect(
          CostEstimatesScreen.costEstimatesHeader.waitForDisplayed() &&
            CostEstimatesScreen.allButton.isEnabled() &&
            CostEstimatesScreen.officeVisitsButton.isEnabled() &&
            CostEstimatesScreen.vaccinesButton.isEnabled() &&
            CostEstimatesScreen.testsAndImagingButton.isEnabled() &&
            CostEstimatesScreen.findByConditionButton.isDisplayed(),
        ).toBe(true);
      });
    });
  });

  describe('Find Urgent Care', () => {
    beforeEach(() => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.waitForEnabled();
      NavDrawerScreen.urgentCareLink.click();
    });

    it('should show the Urgent Care categories', () => {
      FindUrgentCareScreen.convenienceClinicButton.waitForEnabled();
      expect(FindUrgentCareScreen.convenienceClinicButton.isEnabled()).toBe(
        true,
      );
      expect(FindUrgentCareScreen.urgentCareClinicButton.isEnabled()).toBe(
        true,
      );
      expect(FindUrgentCareScreen.virtualVisitsButton.isEnabled()).toBe(true);
      expect(FindUrgentCareScreen.emergencyCallText.isDisplayed()).toBe(true);
    });

    it('Urgent Care Clinic button should link to Results Map', () => {
      FindUrgentCareScreen.convenienceClinicButton.click();
      ResultsMapScreen.filterButton.waitForDisplayed();
      expect(ResultsMapScreen.listButton.isEnabled()).toBe(true);
    });

    it('Convenience Clinic button should link to Results Map', () => {
      FindUrgentCareScreen.convenienceClinicButton.click();
      ResultsMapScreen.filterButton.waitForDisplayed();
      expect(ResultsMapScreen.listButton.isEnabled()).toBe(true);
    });
  });

  // Failing due to https://github.com/rgommezz/react-native-offline/issues/55
  describe('Find Mental Health Care', () => {
    it('is unavailable for your healthcare plan', () => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.waitForEnabled();
      NavDrawerScreen.mentalHealthCareLink.click();
      expect(
        FindMentalHealthCareScreen.careUnavailable.waitForDisplayed(),
      ).toBe(true);
    });
  });
});
