// @flow

import DashboardScreen from '../../screenobjects/dashboard.screen';
import TextSearchScreen from '../../screenobjects/fpc/textSearch.screen';
import ResultsListScreen from '../../screenobjects/resultsList.screen';
import TouchActions from '../../interactions/touch.actions';
import { signIn } from '../../interactions/signIn.actions';
import { textSearchTerm } from '../../constants';

describe('Text Search', () => {
  beforeEach(() => {
    signIn();
    if (driver.isAndroid) {
      DashboardScreen.androidTextSearchButton.click();
    } else {
      DashboardScreen.findMedicalCareButton.click();
    }
    DashboardScreen.textSearchField.waitForEnabled();
    // DashboardScreen.textSearchField.setValue(textSearchTerm);
    DashboardScreen.textSearchField.click();
    DashboardScreen.sendKeysToElement(
      textSearchTerm,
      DashboardScreen.textSearchField,
    );
    driver.hideKeyboard();
    TextSearchScreen.allResultsHeader.waitForDisplayed();
  });

  // C31652906
  it('should show results categories', () => {
    expect(TextSearchScreen.allResultsHeader.isDisplayed()).toBe(true);
    expect(TextSearchScreen.specialtiesHeader.isDisplayed()).toBe(true);
    expect(TextSearchScreen.keywordHeader.isDisplayed()).toBe(true);
    expect(TextSearchScreen.doctorsHeader.isDisplayed()).toBe(true);
    TouchActions.scrollToElement(TextSearchScreen.OONBanner);
    expect(TextSearchScreen.clinicsHeader.isDisplayed()).toBe(true);
    expect(TextSearchScreen.OONBanner.isDisplayed()).toBe(true);
  });

  // C31652908
  it('Show All Results should link to Results List', () => {
    TextSearchScreen.allResultsLink.waitForEnabled();
    TextSearchScreen.allResultsLink.click();
    ResultsListScreen.filterButton.waitForDisplayed();
    expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
  });

  // C39652910
  it('Search bar should show hint text', () => {
    if (driver.isAndroid) {
      DashboardScreen.textSearchField.clearValue();
      expect(DashboardScreen.textSearchField.getText()).toContain(
        'Search doctors, facilities,',
      );
    } else {
      DashboardScreen.headerCancelButton.click();
      expect(DashboardScreen.textSearchField.isDisplayed()).toBe(true);
    }
  });

  // C31652908
  it('Health Care Professionals should link to Doctor Details', () => {
    TextSearchScreen.doctorLink.waitForEnabled();
    TextSearchScreen.doctorLink.click();
    TextSearchScreen.getElementByText('Doctor Details').waitForDisplayed();
    expect(
      TextSearchScreen.getElementByText('Doctor Details').isDisplayed(),
    ).toBe(true);
  });

  it('Health Care Professionals can be saved with a flag icon', () => {
    TextSearchScreen.savedTabs[1].waitForEnabled();
    // TODO: The saved icon doesn't work with the local server,
    // so this only checks that the saved icon is clickable
  });

  // C31652908
  it('Clinics and Facilities should link to Facility Details', () => {
    TouchActions.scrollToElement(TextSearchScreen.clinicLink);
    TextSearchScreen.clinicLink.click();
    expect(
      TextSearchScreen.getElementByText('Facility Details').waitForDisplayed(),
    ).toBe(true);
  });

  // C31652908
  it('Specialties should link to Results List', () => {
    TextSearchScreen.specialtiesLink.waitForEnabled();
    TextSearchScreen.specialtiesLink.click();
    ResultsListScreen.filterButton.waitForDisplayed();
    expect(ResultsListScreen.mapButton.isEnabled()).toBe(true);
  });

  // C2448624 TODO: Not automatable with local server
  // it('should show a message for No Results', () => {});
});
