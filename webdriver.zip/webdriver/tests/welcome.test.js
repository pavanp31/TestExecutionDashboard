// @flow

import WelcomeScreen from '../screenobjects/welcome.screen';
import TouchActions from '../interactions/touch.actions';

describe('Welcome Screen', () => {
  beforeAll(() => {
    driver.reset();
  });

  beforeEach(() => {
    WelcomeScreen.waitForLoaded();
  });

  it('should show the logo', () => {
    expect(WelcomeScreen.welcomeLogo.isDisplayed()).toBe(true);
  });

  it('should show the title', () => {
    expect(WelcomeScreen.welcomeTitle.isDisplayed()).toBe(true);
  });

  it('should show the Sign In button', () => {
    expect(WelcomeScreen.signInBtn.isDisplayed()).toBe(true);
  });

  it('should show the Create Account button', () => {
    expect(WelcomeScreen.createAccountBtn.isDisplayed()).toBe(true);
  });

  it('should show the Call Us link', () => {
    expect(WelcomeScreen.questionsNotice.isDisplayed()).toBe(true);
    expect(WelcomeScreen.helpLink.isDisplayed()).toBe(true);
  });

  it('should show the support number when the link is clicked', () => {
    TouchActions.clickLowerLeft(WelcomeScreen.questionsNotice);
    // Call Us link not clickable in iOS sim
    if (driver.isAndroid) {
      WelcomeScreen.supportPhoneNo.waitForDisplayed();
      expect(WelcomeScreen.supportPhoneNo.getText()).toContain('877-844-4999');
      driver.launchApp();
    }
  });
});
