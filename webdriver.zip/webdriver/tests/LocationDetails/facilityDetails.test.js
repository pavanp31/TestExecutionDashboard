// @flow

import { ScrollDirection } from '../../constants';
import { signIn } from '../../interactions/signIn.actions';
import TouchActions from '../../interactions/touch.actions';
import DashboardScreen from '../../screenobjects/dashboard.screen';
import CallScreen from '../../screenobjects/externalScreens/call.screen';
import MapScreen from '../../screenobjects/externalScreens/map.screen';
import FacilityDetailsScreen from '../../screenobjects/fpc/facilityDetails.screen';
import FindMedicalCareScreen from '../../screenobjects/fpc/findMedicalCare.screen';
import FindPlacesScreen from '../../screenobjects/fpc/findPlaces.screen';

const hospitalName = 'Saint Francis Memorial Hospital';
const hospitalAddress1 = '900 Hyde St Ste 1201';
const hospitalAddress2 = 'San Francisco, CA 94109';

describe('Facility Details', () => {
  beforeEach(() => {
    signIn();

    if (FacilityDetailsScreen.overviewTab.isExisting()) {
      return;
    }

    DashboardScreen.findMedicalCareButton.waitForEnabled();
    DashboardScreen.findMedicalCareButton.click();
    FindMedicalCareScreen.placesButton.waitForEnabled();
    FindMedicalCareScreen.placesButton.click();
    FindPlacesScreen.hospitalsButton.waitForEnabled();
    FindPlacesScreen.hospitalsButton.click();

    // clicks specific test hospital
    const hospital = $(
      `~Facility, Northwestern Memorial Hospital, General Hospital`,
    );

    hospital.waitForEnabled();
    hospital.click();
  });

  // C31653121
  it('Verify whether the following tabs are present in "Facility Details" screen', () => {
    FacilityDetailsScreen.overviewTab.waitForEnabled();
    FacilityDetailsScreen.locationsTab.waitForEnabled();
    FacilityDetailsScreen.physicianDirectoryTab.waitForEnabled();
  });

  // C31653122
  it('Verify the UI and details present under "Facility - Overview" tab', () => {
    FacilityDetailsScreen.getElementByText(hospitalName).waitForExist();
    FacilityDetailsScreen.getElementByText(hospitalAddress1).waitForExist();
    FacilityDetailsScreen.getElementByText(hospitalAddress2).waitForExist();

    TouchActions.scrollToElement(
      FacilityDetailsScreen.saveButton,
      ScrollDirection.DOWN,
    );
    FacilityDetailsScreen.saveButton.waitForExist();
    FacilityDetailsScreen.shareButton.waitForExist();

    const wheelchairAccess = FacilityDetailsScreen.getElementByText(
      'Wheelchair Access',
    );
    TouchActions.scrollToElement(wheelchairAccess, ScrollDirection.DOWN);
    wheelchairAccess.waitForExist();
    FacilityDetailsScreen.getElementByText(
      'Provider Data Information',
    ).waitForExist();

    TouchActions.scrollToElement(
      FacilityDetailsScreen.getElementByText(hospitalName),
      ScrollDirection.UP,
    );
  });

  // C31653123
  // Android Only
  it('Verify that tapping on the phone number in the Overview screen starts the call', () => {
    FacilityDetailsScreen.telephoneLink.waitForEnabled();
    FacilityDetailsScreen.telephoneLink.click();
    FacilityDetailsScreen.telephoneLink.click();

    if (!driver.isAndroid) {
      return;
    }
    CallScreen.isOnScreen();
    CallScreen.goBack();
  });

  // C31653124
  it('Verify that Tapping on the full address/map snapshot/distance (mi) should open Google Maps/Apple Maps with pin location.', () => {
    const address = FacilityDetailsScreen.getElementByText(hospitalAddress1);
    address.waitForExist();
    address.click();

    // Map info modal here on first run
    try {
      MapScreen.continueButton.click();
    } catch (error) {
      // No info modal
    }

    MapScreen.checkAddress('900 Hyde St');
    MapScreen.goBack();
    driver.reset();
  });

  describe('Location', () => {
    beforeEach(() => {
      FacilityDetailsScreen.locationsTab.waitForEnabled();
      FacilityDetailsScreen.locationsTab.click();
    });

    // C31653126
    it('verify the details displayed under "Location" tab', () => {
      FacilityDetailsScreen.getElementByText('Out-of-Network').waitForExist();
      FacilityDetailsScreen.getElementByText(hospitalAddress1).waitForExist();
      FacilityDetailsScreen.getElementByText(hospitalAddress2).waitForExist();
    });
  });

  describe('Physician Directory', () => {
    beforeEach(() => {
      FacilityDetailsScreen.physicianDirectoryTab.waitForEnabled();
      FacilityDetailsScreen.physicianDirectoryTab.click();
    });

    it('Verify the details displayed under "Physician Directory" tab. ', () => {
      FacilityDetailsScreen.getElementByText('26 Physicians').waitForExist();
      const aPhysician = FacilityDetailsScreen.getElementByText(
        'Abdul Aziz Aadam MD',
      );
      const bPhysician = FacilityDetailsScreen.getElementByText(
        'Kelly E Bachta MD',
      );

      aPhysician.waitForExist();
      bPhysician.waitForExist();

      const aLocation = aPhysician.getLocation();
      const bLocation = bPhysician.getLocation();

      if (aLocation.y > bLocation.y) {
        throw new Error('B came before A, physicians should be alphabetized');
      }
    });
  });
});
