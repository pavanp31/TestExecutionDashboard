import { ScrollDirection, textSearchTerm } from '../../constants';
import { signIn } from '../../interactions/signIn.actions';
import TouchActions from '../../interactions/touch.actions';
import DashboardScreen from '../../screenobjects/dashboard.screen';
import NavDrawerScreen from '../../screenobjects/navDrawer.screen';
import CallScreen from '../../screenobjects/externalScreens/call.screen';
import MapScreen from '../../screenobjects/externalScreens/map.screen';
import FindMedicalCareScreen from '../../screenobjects/fpc/findMedicalCare.screen';
import FindPeopleScreen from '../../screenobjects/fpc/findPeople.screen';
import MedicalGroupsScreen from '../../screenobjects/fpc/medicalGroups.screen';
import TextSearchScreen from '../../screenobjects/fpc/textSearch.screen';
import ResultsListScreen from '../../screenobjects/resultsList.screen';

const address1 = '51 W 51st St';
const address2 = 'New York, NY 10019';

describe('Medical Groups', () => {
  beforeAll(() => {
    driver.reset();
    signIn();
  });

  describe('Details screen', () => {
    beforeAll(() => {
      DashboardScreen.findMedicalCareButton.waitForEnabled();
      DashboardScreen.findMedicalCareButton.click();
      FindMedicalCareScreen.peopleButton.waitForEnabled();
      FindMedicalCareScreen.peopleButton.click();
      FindPeopleScreen.medicalGroupsButton.waitForEnabled();
      FindPeopleScreen.medicalGroupsButton.click();

      const targetMedicalGroup = $(
        `~Medical Group, Presence St Mary & Elz Med Ct, Neonatology,Pediatrics,Family Practice`,
      );
      ResultsListScreen.mapButton.waitForDisplayed();
      targetMedicalGroup.click();
    });

    // C31653136
    it('Verify the tabs present under the "Medical Group Detail" screen.', () => {
      MedicalGroupsScreen.overviewTab.waitForDisplayed();
      MedicalGroupsScreen.locationsTab.waitForDisplayed();
      MedicalGroupsScreen.physicianDirectoryTab.waitForDisplayed();
    });

    // C31653137
    it('Verify the UI and details present under the "Medical Groups - Overview" tab', () => {
      MedicalGroupsScreen.getElementByText(
        'Columbia Dental Faculty Practice',
      ).waitForExist();
      MedicalGroupsScreen.getElementByText(address1).waitForExist();
      MedicalGroupsScreen.getElementByText(address2).waitForExist();
      MedicalGroupsScreen.getElementByText('+1 212-326-8520').waitForExist();
    });

    // C31653139
    // Android Only
    it('Verify that tapping on the phone number in the Overview screen starts the call', () => {
      if (!driver.isAndroid) {
        return;
      }

      MedicalGroupsScreen.telephoneLink.waitForDisplayed();
      MedicalGroupsScreen.telephoneLink.click();

      CallScreen.isOnScreen();
      CallScreen.goBack();
    });

    // C31653138
    it('Overview: Verify that Tapping on the full address/mapsnapshot/distance (mi) should open Google Maps/Apple Maps with pin location', () => {
      const address = MedicalGroupsScreen.getElementByText(address1);
      address.waitForExist();
      address.click();

      MapScreen.checkAddress(address1);
      MapScreen.goBack();
    });

    describe('Location', () => {
      beforeAll(() => {
        MedicalGroupsScreen.locationsTab.click();
        MedicalGroupsScreen.locationsTab.click();
      });

      // C31653142
      it('verify the details displayed under "Location" tab', () => {
        MedicalGroupsScreen.getElementByText(address1).waitForExist();
        MedicalGroupsScreen.getElementByText(address2).waitForExist();
      });

      // C31653138
      it('Verify that Tapping on the full address/mapsnapshot/distance (mi) should open Google Maps/Apple Maps with pin location.', () => {
        const address = driver.isAndroid
          ? MedicalGroupsScreen.getElementByText(address1)
          : $(
              `-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS '${address1}'`,
            );
        address.waitForExist();
        address.click();

        MapScreen.checkAddress(address1);
        MapScreen.goBack();
      });

      // C31653143
      // Android only
      it('Verify that tapping on Phone number starts the call', () => {
        if (!driver.isAndroid) {
          return;
        }

        MedicalGroupsScreen.telephoneLink.waitForDisplayed();
        MedicalGroupsScreen.telephoneLink.click();

        CallScreen.isOnScreen();
        CallScreen.goBack();
      });
    });
  });

  describe('Text Search', () => {
    beforeAll(() => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.click();
      if (driver.isAndroid) {
        DashboardScreen.androidTextSearchButton.click();
      } else {
        DashboardScreen.findMedicalCareButton.click();
      }
      DashboardScreen.textSearchField.waitForEnabled();
      // DashboardScreen.textSearchField.setValue(textSearchTerm);
      DashboardScreen.textSearchField.click();
      DashboardScreen.sendKeysToElement(
        textSearchTerm,
        DashboardScreen.textSearchField,
      );

      if (!driver.isAndroid) {
        driver.hideKeyboard();
      }
      TextSearchScreen.allResultsHeader.waitForDisplayed();
    });

    afterAll(() => {
      TouchActions.hardwareBack();
    });

    // C31653135
    it('Verify that "Medical Groups" are listed under the "Text Search" result screen', () => {
      const medicalGroups = TextSearchScreen.getElementByText(
        'Hercules Optometric Group',
      );
      TouchActions.scrollToElement(medicalGroups, ScrollDirection.DOWN);
      medicalGroups.waitForExist();
      TextSearchScreen.getElementByText('Medical Groups').waitForExist();
    });
  });
});
