// @flow

import DashboardScreen from '../../screenobjects/dashboard.screen';
import { signIn } from '../../interactions/signIn.actions';

describe('Login Flow', () => {
  beforeAll(() => {
    driver.reset(); // In case there's a saved username
  });

  // C31652775
  it('should log in successfully', () => {
    const username: string = process.env.BLUESTEEL_USR || 'test';
    const password: string = process.env.BLUESTEEL_PSW || 'test';
    const environment = 'Production';
    signIn(environment, username, password);

    // expect to see the dashboard
    expect(DashboardScreen.quickLinksHeader.waitForDisplayed()).toBe(true);
  });
});
