/* eslint-disable jasmine/no-disabled-tests */
// @flow

import NavDrawerScreen from '../screenobjects/navDrawer.screen';
import DashboardScreen from '../screenobjects/dashboard.screen';
import UrgentCareScreen from '../screenobjects/fpc/findUrgentCare.screen';
import MedialCareScreen from '../screenobjects/fpc/findMedicalCare.screen';
import MentalHealthScreen from '../screenobjects/fpc/findMentalHealthCare.screen';
import ClaimsScreen from '../screenobjects/claims.screen';
import SavedProviderScreen from '../screenobjects/savedProviders.screen';
import AccountBalanceScreen from '../screenobjects/accountBalances.screen';
import HealthChecklistScreen from '../screenobjects/healthChecklist.screen';
import ContactUsScreen from '../screenobjects/contactUs.screen';
import PlanDocumentScreen from '../screenobjects/planDocuments.screen';
import SettingsScreen from '../screenobjects/settings/accountSettings.screen';

import { signIn } from '../interactions/signIn.actions';

describe('Nav Drawer', () => {
  beforeAll(() => {
    driver.reset();
    signIn();
  });

  beforeEach(() => {
    NavDrawerScreen.openNavDrawer();
  });

  afterAll(() => {
    driver.reset();
  });

  it('Dashboard link should navigate to dashboard screen on click', () => {
    expect(NavDrawerScreen.dashboardLink.isDisplayed()).toBe(true);
    NavDrawerScreen.dashboardLink.click();
    expect(DashboardScreen.screenHeader.waitForDisplayed()).toBe(true);
  });

  it('Find Urgent Care link should navigate to find urgent screen on click', () => {
    expect(NavDrawerScreen.urgentCareLink.isDisplayed()).toBe(true);
    NavDrawerScreen.urgentCareLink.click();
    expect(UrgentCareScreen.screenHeader.waitForDisplayed()).toBe(true);
  });

  it('Find Medical Care link should navigate to find medical care screen on click', () => {
    expect(NavDrawerScreen.medicalCareLink.isDisplayed()).toBe(true);
    NavDrawerScreen.medicalCareLink.click();
    expect(MedialCareScreen.findCareNearHeader.waitForDisplayed()).toBe(true);
  });

  it('Find Mental Health Care link should navigate to find mental health care screen on click', () => {
    expect(NavDrawerScreen.mentalHealthCareLink.isDisplayed()).toBe(true);
    NavDrawerScreen.mentalHealthCareLink.click();
    expect(MentalHealthScreen.screenHeader.waitForDisplayed()).toBe(true);
  });

  it('Manage Claims link should navigate to manage claims screen on click', () => {
    expect(NavDrawerScreen.manageClaimsLink.isDisplayed()).toBe(true);
    NavDrawerScreen.manageClaimsLink.click();
    expect(ClaimsScreen.screenHeader.waitForDisplayed()).toBe(true);
  });

  it('Saved link should navigate to saved providers screen on click', () => {
    expect(NavDrawerScreen.savedLink.isDisplayed()).toBe(true);
    NavDrawerScreen.savedLink.click();
    expect(SavedProviderScreen.screenHeader.waitForDisplayed()).toBe(true);
  });

  it('Account Balances link should navigate to account balances screen on click', () => {
    expect(NavDrawerScreen.accountBalancesLink.isDisplayed()).toBe(true);
    NavDrawerScreen.accountBalancesLink.click();
    expect(AccountBalanceScreen.screenHeader.waitForDisplayed()).toBe(true);
  });

  it('Health Checklist link should navigate to health checklist screen on click', () => {
    expect(NavDrawerScreen.healthChecklistLink.isDisplayed()).toBe(true);
    NavDrawerScreen.healthChecklistLink.click();
    expect(HealthChecklistScreen.screenHeader.waitForDisplayed()).toBe(true);
  });

  it('Contact Us link should navigate to contact us screen on click', () => {
    expect(NavDrawerScreen.contactUsLink.isDisplayed()).toBe(true);
    NavDrawerScreen.contactUsLink.click();
    expect(ContactUsScreen.screenHeader.waitForDisplayed()).toBe(true);
  });
  // disable plan documents until c&s gets handled
  xit('Plan Documents link should navigate to plan documents screen on click', () => {
    expect(NavDrawerScreen.planDocumentsLink.isDisplayed()).toBe(true);
    NavDrawerScreen.planDocumentsLink.click();
    expect(PlanDocumentScreen.screenHeader.waitForDisplayed()).toBe(true);
  });

  it('Settings link should navigate to settings screen on click', () => {
    expect(NavDrawerScreen.settingsLink.isDisplayed()).toBe(true);
    NavDrawerScreen.settingsLink.click();
    expect(SettingsScreen.header.waitForDisplayed()).toBe(true);
  });
});
