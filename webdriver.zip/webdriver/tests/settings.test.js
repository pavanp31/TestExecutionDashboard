// @flow

import AccountSettingsScreen from '../screenobjects/settings/accountSettings.screen';
import HSIDSettingsScreen from '../screenobjects/settings/hsidSettings/hsidSettings.screen';
import AccountRecoverySettingsScreen from '../screenobjects/settings/hsidSettings/accountRecoverySettings.screen';
import DashboardScreen from '../screenobjects/dashboard.screen';
import WelcomeScreen from '../screenobjects/welcome.screen';
import { signIn, signOut } from '../interactions/signIn.actions';
import TouchActions from '../interactions/touch.actions';
import { navigateToSettings } from '../interactions/settings.actions';
import { ScrollDirection, EXTRA_LONG_WAIT } from '../constants';

describe('Settings Test Suite', () => {
  beforeAll(() => {
    driver.reset();
  });

  describe('Dev Drawer Link', () => {
    beforeEach(() => {
      signIn();
      DashboardScreen.quickLinksHeader.waitForEnabled();
    });

    // C31653574
    it('should navigate to the Account Settings screen', () => {
      navigateToSettings();
      expect(AccountSettingsScreen.header.waitForExist()).toBe(true);
    });
  });

  describe('Settings Screen', () => {
    beforeEach(() => {
      signIn();

      // If an external nav test fails, restart the app for other tests
      try {
        DashboardScreen.menuButton.waitForEnabled();
      } catch (error) {
        driver.reset();
      }

      navigateToSettings();
    });

    // C31653575
    // C31653609
    it('should display the correct sections', () => {
      AccountSettingsScreen.header.waitForEnabled();

      expect(AccountSettingsScreen.accountSectionHeader.waitForExist()).toBe(
        true,
      );
      expect(AccountSettingsScreen.offlineIdCardsLabel.waitForExist()).toBe(
        true,
      );
      expect(AccountSettingsScreen.aboutSectionHeader.waitForExist()).toBe(
        true,
      );
      expect(AccountSettingsScreen.legalSectionHeader.waitForExist()).toBe(
        true,
      );

      AccountSettingsScreen.scrollToAccessibilityStatementLink();
      expect(
        AccountSettingsScreen.accessibilitySectionHeader.waitForExist(),
      ).toBe(true);
      expect(AccountSettingsScreen.supportSectionHeader.waitForExist()).toBe(
        true,
      );
    });

    // C31653579
    it('should be able to navigate to the Accessibility Statement for Individuals with Disabilities page, and return to the app', () => {
      AccountSettingsScreen.header.waitForEnabled();
      AccountSettingsScreen.scrollToAccessibilityStatementLink();
      AccountSettingsScreen.accessibilityStatementLink.click();

      // Wait for the app to close, then wait for the browswer to launch
      AccountSettingsScreen.accessibilityStatementLink.waitForEnabled(
        EXTRA_LONG_WAIT,
        false,
      );
      AccountSettingsScreen.chromeURL.waitForEnabled(EXTRA_LONG_WAIT);

      if (driver.isAndroid) {
        expect(AccountSettingsScreen.chromeURL.getText()).toEqual(
          'https://www.uhc.com/legal/accessibility',
        );
        TouchActions.hardwareBack();
      } else {
        // browser/url bar behavior is super weird and flaky on iOS,
        // so we can't reliably check the url, just that the browser launched
        expect(AccountSettingsScreen.chromeURL.waitForExist()).toBe(true);
        TouchActions.breadcrumbBack();
      }

      expect(AccountSettingsScreen.header.waitForExist()).toBe(true);
    });

    // C31653585
    it('should let a user logout', () => {
      signOut();

      expect(WelcomeScreen.welcomeLogo.waitForEnabled()).toBe(true);
    });

    // C31653617
    it('should show the support number when the application support link is clicked', () => {
      AccountSettingsScreen.header.waitForEnabled();
      AccountSettingsScreen.scrollToApplicationSupportLink();
      AccountSettingsScreen.applicationSupportLink.waitForEnabled();

      // iOS simulator doesn't do anything when tapping the phone number
      if (driver.isAndroid) {
        AccountSettingsScreen.applicationSupportLink.click();
        expect(WelcomeScreen.supportPhoneNo.waitForDisplayed()).toBe(true);
        expect(WelcomeScreen.supportPhoneNo.getText()).toContain(
          '1 877-844-4999',
        );
        driver.launchApp();
      }

      // scroll back to the top
      TouchActions.scrollToTop(2);
    });

    // C31653618
    // C31653630
    it('should open the Legal links in a modal', () => {
      AccountSettingsScreen.header.waitForEnabled();
      TouchActions.scrollToElement(
        AccountSettingsScreen.disclaimersAndNoticesLink,
      );
      AccountSettingsScreen.disclaimersAndNoticesLink.waitForEnabled();
      AccountSettingsScreen.disclaimersAndNoticesLink.click();
      expect(
        AccountSettingsScreen.disclaimersAndNoticesModalContent.waitForDisplayed(
          EXTRA_LONG_WAIT,
        ),
      ).toBe(true);
      AccountSettingsScreen.closeButton.click();

      TouchActions.scrollToElement(AccountSettingsScreen.termsOfUseLink);
      AccountSettingsScreen.termsOfUseLink.click();
      expect(
        AccountSettingsScreen.termsOfUseModalContent.waitForDisplayed(
          EXTRA_LONG_WAIT,
        ),
      ).toBe(true);
      AccountSettingsScreen.closeButton.click();

      TouchActions.scrollToElement(AccountSettingsScreen.privacyPolicyLink);
      AccountSettingsScreen.privacyPolicyLink.waitForEnabled();
      AccountSettingsScreen.privacyPolicyLink.click();
      expect(
        AccountSettingsScreen.privacyPolicyModalContent.waitForDisplayed(
          EXTRA_LONG_WAIT,
        ),
      ).toBe(true);
      AccountSettingsScreen.closeButton.click();
    });
  });

  describe('HSID Settings', () => {
    beforeAll(() => {
      signIn();
      navigateToSettings();
      TouchActions.scrollToElement(
        AccountSettingsScreen.hsidSettingsLink,
        ScrollDirection.UP,
      );
      AccountSettingsScreen.hsidSettingsLink.click();

      // confirm identity workflow - C38983543
      HSIDSettingsScreen.header.waitForDisplayed();
      HSIDSettingsScreen.textMeButton.waitForEnabled();
      HSIDSettingsScreen.textMeButton.click();
      // HSIDSettingsScreen.confirmationCodeInput.setValue('test');
      HSIDSettingsScreen.sendKeysToElement(
        'test',
        HSIDSettingsScreen.confirmationCodeInput,
      );
      HSIDSettingsScreen.confirmationCodeSubmitButton.click();
    });

    // C31653589
    it('should navigate to the HSID Settings screen', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      expect(HSIDSettingsScreen.usernameLabel.waitForExist()).toBe(true);
      expect(HSIDSettingsScreen.passwordLabel.waitForExist()).toBe(true);
      expect(HSIDSettingsScreen.recoveryEmailLabel.waitForExist()).toBe(true);
      expect(
        HSIDSettingsScreen.accountRecoverySectionTitle.waitForExist(),
      ).toBe(true);
    });

    // C31653590
    // C31653605
    it('should be able to change the password', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      HSIDSettingsScreen.passwordEditLink.click();

      expect(HSIDSettingsScreen.updatePasswordHeader.waitForExist()).toBe(true);
      // HSIDSettingsScreen.currentPasswordField.setValue('Test2day');
      HSIDSettingsScreen.sendKeysToElement(
        'Test2day',
        HSIDSettingsScreen.currentPasswordField,
      );
      // HSIDSettingsScreen.newPasswordField.setValue('Test2day!');
      HSIDSettingsScreen.sendKeysToElement(
        'Test2day!',
        HSIDSettingsScreen.newPasswordField,
      );
      // HSIDSettingsScreen.repeatNewPasswordField.setValue('Test2day!');
      HSIDSettingsScreen.sendKeysToElement(
        'Test2day!',
        HSIDSettingsScreen.repeatNewPasswordField,
      );
      HSIDSettingsScreen.passwordSaveButton.click();

      expect(HSIDSettingsScreen.screenHeader.waitForDisplayed()).toBe(true);
    });

    // C31653591
    it('should display an error while changing the password if the new passwords do not match', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      HSIDSettingsScreen.passwordEditLink.click();

      expect(HSIDSettingsScreen.updatePasswordHeader.waitForExist()).toBe(true);
      // HSIDSettingsScreen.currentPasswordField.setValue('Test2day');
      HSIDSettingsScreen.sendKeysToElement(
        'Test2day',
        HSIDSettingsScreen.currentPasswordField,
      );
      // HSIDSettingsScreen.newPasswordField.setValue('Test1day!');
      HSIDSettingsScreen.sendKeysToElement(
        'Test1day!',
        HSIDSettingsScreen.newPasswordField,
      );
      // HSIDSettingsScreen.repeatNewPasswordField.setValue('Test2day!');
      HSIDSettingsScreen.sendKeysToElement(
        'Test2day!',
        HSIDSettingsScreen.repeatNewPasswordField,
      );
      HSIDSettingsScreen.passwordSaveButton.click();

      expect(
        HSIDSettingsScreen.passwordsMustMatchErrorMessage.waitForDisplayed(),
      ).toBe(true);
      HSIDSettingsScreen.backButton.click();
    });

    // C31653592
    it('should display an error while changing the password if the new password violates the password requirements', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      HSIDSettingsScreen.passwordEditLink.click();

      expect(HSIDSettingsScreen.updatePasswordHeader.waitForExist()).toBe(true);
      // HSIDSettingsScreen.currentPasswordField.setValue('Test2day');
      HSIDSettingsScreen.sendKeysToElement(
        'Test2day',
        HSIDSettingsScreen.currentPasswordField,
      );
      // HSIDSettingsScreen.newPasswordField.setValue('test');
      HSIDSettingsScreen.sendKeysToElement(
        'test',
        HSIDSettingsScreen.newPasswordField,
      );

      expect(
        HSIDSettingsScreen.passwordRulesViolationErrorMessage.waitForDisplayed(),
      ).toBe(true);
      HSIDSettingsScreen.backButton.click();
    });

    // C31653593
    // C31653594
    it('should be able to change the recovery email', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      HSIDSettingsScreen.recoveryEmailEditLink.click();

      expect(HSIDSettingsScreen.updateRecoveryEmailHeader.waitForExist()).toBe(
        true,
      );
      // HSIDSettingsScreen.recoveryEmailField.setValue('test@example.com');
      HSIDSettingsScreen.sendKeysToElement(
        'test@example.com',
        HSIDSettingsScreen.recoveryEmailField,
      );
      HSIDSettingsScreen.recoveryEmailSaveButton.click();

      expect(HSIDSettingsScreen.screenHeader.waitForDisplayed()).toBe(true);
      expect(HSIDSettingsScreen.unconfirmedEmailLabel.waitForDisplayed()).toBe(
        true,
      );
    });

    // C31653596
    it('should navigate to the Account Recovery screen', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      HSIDSettingsScreen.accountRecoveryEditLink.click();

      expect(
        AccountRecoverySettingsScreen.screenHeader.waitForDisplayed(),
      ).toBe(true);
      expect(AccountRecoverySettingsScreen.subHeader.waitForDisplayed()).toBe(
        true,
      );
      expect(
        AccountRecoverySettingsScreen.recoveryMethodDropdown.waitForDisplayed(),
      ).toBe(true);

      HSIDSettingsScreen.backButton.click();
    });

    // C31653623
    it('should display an error message after entering an invalid recovery phone number', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      HSIDSettingsScreen.accountRecoveryEditLink.click();
      AccountRecoverySettingsScreen.recoveryMethodDropdown.waitForDisplayed();

      // clearValue() and setValue('') don't seem to work for this field,
      // so we're manually typing a backspace (unicode \uE003) character instead
      // AccountRecoverySettingsScreen.recoveryPhoneField.setValue('\uE003'); // backspace
      AccountRecoverySettingsScreen.sendKeysToElement(
        '\uE003',
        AccountRecoverySettingsScreen.recoveryPhoneField,
      );
      AccountRecoverySettingsScreen.saveButton.click();

      expect(
        AccountRecoverySettingsScreen.invalidPhoneNumberMessage.waitForDisplayed(),
      ).toBe(true);

      HSIDSettingsScreen.backButton.click();
    });

    // C31653603
    it('should be able to select "Security Questions" as the recovery method', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      HSIDSettingsScreen.accountRecoveryEditLink.click();
      AccountRecoverySettingsScreen.recoveryMethodDropdown.waitForDisplayed();

      expect(
        AccountRecoverySettingsScreen.recoveryMethodDropdown.getText(),
      ).toBe('Text Me');

      AccountRecoverySettingsScreen.recoveryMethodDropdown.click();
      AccountRecoverySettingsScreen.recoveryMethodSecurityQuestionsOption.click();

      expect(
        AccountRecoverySettingsScreen.recoveryMethodDropdown.getText(),
      ).toBe('Security Questions');
      expect(
        AccountRecoverySettingsScreen.question1Heading.waitForDisplayed(),
      ).toBe(true);

      HSIDSettingsScreen.backButton.click();
    });

    // C31653604
    it('should display an error message when all security question answers are left blank', () => {
      expect(HSIDSettingsScreen.screenHeader.waitForExist()).toBe(true);
      HSIDSettingsScreen.accountRecoveryEditLink.click();
      AccountRecoverySettingsScreen.recoveryMethodDropdown.waitForDisplayed();

      AccountRecoverySettingsScreen.recoveryMethodDropdown.click();
      AccountRecoverySettingsScreen.recoveryMethodSecurityQuestionsOption.click();

      expect(
        AccountRecoverySettingsScreen.question1Heading.waitForDisplayed(),
      ).toBe(true);
      TouchActions.scrollToElement(AccountRecoverySettingsScreen.saveButton);
      AccountRecoverySettingsScreen.saveButton.click();

      expect(
        AccountRecoverySettingsScreen.pleaseSelectAQuestionErrors.length,
      ).toBe(3);

      AccountRecoverySettingsScreen.selectSecurityQuestions();
      TouchActions.scrollToElement(AccountRecoverySettingsScreen.saveButton);
      AccountRecoverySettingsScreen.saveButton.click();

      expect(
        AccountRecoverySettingsScreen.pleaseSelectAQuestionErrors.length,
      ).toBe(0);
      expect(
        AccountRecoverySettingsScreen.answersCannotBeBlankErrors.length,
      ).toBe(3);

      HSIDSettingsScreen.backButton.click();
    });
  });
});
