// @flow

import WelcomeScreen from '../screenobjects/welcome.screen';
import SignInScreen from '../screenobjects/signIn.screen';
import ChoosePlanScreen from '../screenobjects/registration/choosePlan.screen';
import DevDrawerScreen from '../screenobjects/devDrawer.screen';
import RegisterCameraScreen from '../screenobjects/registration/registerCamera.screen';
import PersonalInfoScreen from '../screenobjects/registration/personalInfo.screen';
import CreateAccountScreen from '../screenobjects/registration/createAccount.screen';
import ConfirmIdentityScreen from '../screenobjects/registration/confirmIdentity.screen';
import SecurityQuestionsScreen from '../screenobjects/registration/securityQuestions.screen';

import TouchActions from '../interactions/touch.actions';
import { signOut } from '../interactions/signIn.actions';
import { ScrollDirection } from '../constants';

const ENV_NAME = 'Local';

describe('Create Account:', () => {
  beforeAll(() => {
    driver.reset();
    signOut();
    WelcomeScreen.waitForLoaded();
    WelcomeScreen.openDevDrawer();
    DevDrawerScreen.switchEnvironment(ENV_NAME);
  });

  beforeEach(() => {
    WelcomeScreen.waitForLoaded();
    WelcomeScreen.createAccountBtn.waitForEnabled();
    WelcomeScreen.createAccountBtn.click();
    ChoosePlanScreen.choosePlanHeader.waitForDisplayed();
  });

  describe('Choose Medical Plan:', () => {
    // C29447122
    it('E&I continues to camera registration screen', () => {
      ChoosePlanScreen.EnIButton.click();
      ChoosePlanScreen.continueButton.click();
      expect(RegisterCameraScreen.useCameraButton.waitForEnabled()).toBe(true);
    });

    it('M&R continues to plan selection screen', () => {
      ChoosePlanScreen.MnRButton.click();
      ChoosePlanScreen.continueButton.click();
      expect(ChoosePlanScreen.goBackButton.waitForEnabled()).toBe(true);
      ChoosePlanScreen.registerMedicareButton.click();
      expect(RegisterCameraScreen.useCameraButton.waitForEnabled()).toBe(true);
    });

    it('C&S continues to camera registration screen', () => {
      ChoosePlanScreen.CnSButton.click();
      ChoosePlanScreen.continueButton.click();
      expect(RegisterCameraScreen.useCameraButton.waitForEnabled()).toBe(true);
    });

    it('Sign in now links to Sign In screen', () => {
      TouchActions.scrollToElement(ChoosePlanScreen.signInNow);
      ChoosePlanScreen.signInNow.click();
      expect(SignInScreen.signInButton.waitForEnabled()).toBe(true);
    });

    it('Call Us link opens the phone app', () => {
      TouchActions.scrollToElement(ChoosePlanScreen.callUs);
      TouchActions.clickLowerLeft(ChoosePlanScreen.callUs);

      // Android will open phone app and needs to be relaunched, iOS runs on sim can't open the phone
      if (driver.isAndroid) {
        expect(WelcomeScreen.supportPhoneNo.waitForDisplayed()).toBe(true);
        expect(WelcomeScreen.supportPhoneNo.getText()).toContain(
          '877-844-4999',
        );
        driver.launchApp();
        WelcomeScreen.waitForLoaded();
        WelcomeScreen.openDevDrawer();
        DevDrawerScreen.switchEnvironment(ENV_NAME);
        WelcomeScreen.waitForLoaded();
      }
    });
  });

  describe('Register with Camera:', () => {
    beforeEach(() => {
      ChoosePlanScreen.EnIButton.click();
      ChoosePlanScreen.continueButton.click();
      RegisterCameraScreen.useCameraHeader.waitForDisplayed();
    });

    // C29447196
    it('shows all visual elements', () => {
      expect(RegisterCameraScreen.useCameraHeader.isDisplayed()).toBe(true);
      expect(RegisterCameraScreen.useCameraDesc.isDisplayed()).toBe(true);
      expect(RegisterCameraScreen.useCameraButton.isDisplayed()).toBe(true);
      expect(RegisterCameraScreen.registerManuallyLink.isDisplayed()).toBe(
        true,
      );
    });

    // C29447171
    // C29447178
    it('Use camera button opens barcode scanner', () => {
      RegisterCameraScreen.useCameraButton.click();
      // Use camera permission modal
      if (RegisterCameraScreen.okButton.isDisplayed()) {
        RegisterCameraScreen.okButton.click();
      }
      expect(RegisterCameraScreen.placeBarcodeDesc.waitForDisplayed()).toBe(
        true,
      );
      expect(RegisterCameraScreen.registerManuallyButton.isDisplayed()).toBe(
        true,
      );
      RegisterCameraScreen.closeButton.click();
    });

    // C29447125
    it('Register Manually button links to account creation form', () => {
      RegisterCameraScreen.useCameraButton.click();
      RegisterCameraScreen.registerManuallyButton.waitForEnabled();
      RegisterCameraScreen.registerManuallyButton.click();
      expect(PersonalInfoScreen.firstNameField.waitForDisplayed()).toBe(true);
    });

    /** Tests fails due to bug
    // C29447126
    it('Cancelling takes the user back to the Welcome screen', () => {
      RegisterCameraScreen.useCameraButton.click();
      RegisterCameraScreen.closeButton.click();
      RegisterCameraScreen.headerCancelButton.click();
      expect(WelcomeScreen.welcomeLogo.waitForDisplayed()).toBe(true);
    }); */
  });

  describe('Register Manually:', () => {
    beforeEach(() => {
      ChoosePlanScreen.EnIButton.click();
      ChoosePlanScreen.continueButton.click();
      RegisterCameraScreen.registerManuallyLink.click();
    });

    afterEach(() => {
      // Go back to the start of the create account workflow
      if (CreateAccountScreen.headerCancelButton.isDisplayed()) {
        CreateAccountScreen.headerCancelButton.click();
      } else if (PersonalInfoScreen.closeButton.isDisplayed()) {
        PersonalInfoScreen.closeButton.click();
      }
    });

    it('Personal Info screen shows all visual elements', () => {
      PersonalInfoScreen.personalInfoHeader.waitForEnabled();
      expect(PersonalInfoScreen.personalInfoHeader.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.personalInfoDesc.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.HSIDInfoButton.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.optionalFieldsDesc.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.firstNameField.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.lastNameField.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.chooseDate.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.idCardDesc.isDisplayed()).toBe(true);
      TouchActions.scrollToElement(PersonalInfoScreen.notSureHSID);
      expect(PersonalInfoScreen.yesRadioButton.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.noRadioButton.isDisplayed()).toBe(true);
      expect(PersonalInfoScreen.notSureHSID.isDisplayed()).toBe(true);
    });

    // C29447128
    it('HSID link opens info modal', () => {
      PersonalInfoScreen.personalInfoHeader.waitForEnabled();
      PersonalInfoScreen.HSIDInfoButton.click();
      expect(PersonalInfoScreen.infoModal.waitForDisplayed()).toBe(true);
      PersonalInfoScreen.closeButton.click();
    });

    // C29447134
    it('Error messages for required fields and radio button', () => {
      PersonalInfoScreen.personalInfoHeader.waitForEnabled();
      TouchActions.scrollToElement(PersonalInfoScreen.continueButton);
      PersonalInfoScreen.continueButton.click();
      TouchActions.scrollToElement(
        PersonalInfoScreen.personalInfoHeader,
        ScrollDirection.UP,
      );
      PersonalInfoScreen.requiredError.waitForDisplayed();
      expect(PersonalInfoScreen.requiredErrors.length).toBe(3);
      TouchActions.scrollToElement(PersonalInfoScreen.continueButton);
      expect(PersonalInfoScreen.memberIDError.isDisplayed()).toBe(true);

      PersonalInfoScreen.noRadioButton.click();
      PersonalInfoScreen.continueButton.click();
      expect(PersonalInfoScreen.SSNError.waitForDisplayed()).toBe(true);
      expect(PersonalInfoScreen.zipCodeError.isDisplayed()).toBe(true);
    });

    // C29447174
    it('with member ID card', () => {
      PersonalInfoScreen.sendKeysToElement(
        'test',
        PersonalInfoScreen.firstNameField,
      );
      PersonalInfoScreen.sendKeysToElement(
        'test',
        PersonalInfoScreen.lastNameField,
      );
      driver.hideKeyboard();
      PersonalInfoScreen.chooseDate.click();
      PersonalInfoScreen.doneButton.waitForEnabled();
      PersonalInfoScreen.doneButton.click();
      PersonalInfoScreen.yesRadioButton.click();
      TouchActions.scrollToElement(PersonalInfoScreen.groupNumberField);
      PersonalInfoScreen.memberIDField.waitForDisplayed();
      PersonalInfoScreen.sendKeysToElement(
        '12345',
        PersonalInfoScreen.memberIDField,
      );
      if (driver.isAndroid) {
        // iOS can't hide the keyboard if it's a numpad
        driver.hideKeyboard();
        TouchActions.scrollToElement(PersonalInfoScreen.continueButton);
      } else {
        PersonalInfoScreen.yesRadioButton.touchAction([
          'tap',
          {
            action: 'wait',
            ms: 500,
          },
        ]);
      }

      PersonalInfoScreen.sendKeysToElement(
        '12345',
        PersonalInfoScreen.groupNumberField,
      );
      driver.hideKeyboard();
      PersonalInfoScreen.continueButton.click();
      expect(CreateAccountScreen.hsidDesc.waitForDisplayed()).toBe(true);
      CreateAccountScreen.backButton.click();
    });

    // C29447137
    // C29447136
    it('with SSN', () => {
      PersonalInfoScreen.firstNameField.waitForEnabled();
      PersonalInfoScreen.sendKeysToElement(
        'test',
        PersonalInfoScreen.firstNameField,
      );
      PersonalInfoScreen.sendKeysToElement(
        'test',
        PersonalInfoScreen.lastNameField,
      );
      driver.hideKeyboard();
      PersonalInfoScreen.chooseDate.click();
      PersonalInfoScreen.doneButton.click();
      TouchActions.scrollToElement(PersonalInfoScreen.noRadioButton);
      PersonalInfoScreen.noRadioButton.click();
      TouchActions.scrollToElement(PersonalInfoScreen.SSNField);

      // PersonalInfoScreen.SSNField.setValue('123456');
      PersonalInfoScreen.sendKeysToElement(
        '123456',
        PersonalInfoScreen.SSNField,
      );
      if (driver.isAndroid) {
        // iOS can't hide the keyboard if it's a numpad
        driver.hideKeyboard();
        TouchActions.scrollToElement(PersonalInfoScreen.continueButton);
      } else {
        PersonalInfoScreen.noRadioButton.click();
      }

      PersonalInfoScreen.sendKeysToElement(
        '12345',
        PersonalInfoScreen.zipCodeField,
      );
      driver.hideKeyboard();

      PersonalInfoScreen.continueButton.click();
      expect(CreateAccountScreen.hsidDesc.waitForDisplayed()).toBe(true);
      CreateAccountScreen.backButton.click();
    });

    // TODO: Fix for Android
    describe('Create Account screen:', () => {
      beforeEach(() => {
        PersonalInfoScreen.registerWithCard();
        CreateAccountScreen.requiredFieldsText.waitForDisplayed();
      });

      afterEach(() => {
        if (CreateAccountScreen.headerCancelButton.isDisplayed()) {
          CreateAccountScreen.headerCancelButton.click();
        }
        if (CreateAccountScreen.backButton.isDisplayed()) {
          CreateAccountScreen.backButton.click();
        }
      });

      // C29447130
      it('shows all info text and email info link', () => {
        expect(CreateAccountScreen.createAccountHeader.isDisplayed()).toBe(
          true,
        );
        expect(CreateAccountScreen.hsidDesc.isDisplayed()).toBe(true);
        expect(CreateAccountScreen.requiredFieldsText.isDisplayed()).toBe(true);
        TouchActions.scrollToElement(CreateAccountScreen.whyEmailLink);
        CreateAccountScreen.whyEmailLink.click();
        expect(CreateAccountScreen.whyEmailText.waitForDisplayed()).toBe(true);
        TouchActions.hardwareBack();
      });

      // C29447140
      // C29447166
      it('Error messages for required fields and Terms of Service', () => {
        TouchActions.scrollToElement(CreateAccountScreen.continueButton);
        CreateAccountScreen.continueButton.click();
        expect(CreateAccountScreen.tosError.waitForEnabled()).toBe(true);

        TouchActions.scrollToElement(
          CreateAccountScreen.requiredFieldsText,
          ScrollDirection.UP,
        );

        expect(CreateAccountScreen.emailError.waitForEnabled()).toBe(true);
        expect(CreateAccountScreen.passwordError.waitForEnabled()).toBe(true);
        expect(CreateAccountScreen.usernameError.waitForEnabled()).toBe(true);
      });

      it('Validation error messages', () => {
        // CreateAccountScreen.usernameField.setValue('Test');
        CreateAccountScreen.usernameField.waitForEnabled();
        CreateAccountScreen.sendKeysToElement(
          'Test',
          CreateAccountScreen.usernameField,
        );
        driver.hideKeyboard();
        expect(CreateAccountScreen.usernamePatternError.waitForEnabled()).toBe(
          true,
        );
        // CreateAccountScreen.usernameField.setValue('Testname');
        CreateAccountScreen.sendKeysToElement(
          'Testname',
          CreateAccountScreen.usernamePatternError,
        );
        // CreateAccountScreen.passwordField.setValue('test');
        CreateAccountScreen.sendKeysToElement(
          'test',
          CreateAccountScreen.passwordField,
        );
        driver.hideKeyboard();
        expect(
          CreateAccountScreen.passwordPatternError.waitForDisplayed(),
        ).toBe(true);
      });

      // CC29447131
      // C29447132
      it('Emails and passwords must match', () => {
        TouchActions.scrollToElement(CreateAccountScreen.passwordField);
        // CreateAccountScreen.passwordField.setValue('Test1234');
        CreateAccountScreen.sendKeysToElement(
          'Test1234',
          CreateAccountScreen.passwordField,
        );
        driver.hideKeyboard();
        TouchActions.scrollToElement(CreateAccountScreen.confirmPasswordField);
        // CreateAccountScreen.confirmPasswordField.setValue('Test');
        CreateAccountScreen.sendKeysToElement(
          'Test',
          CreateAccountScreen.confirmPasswordField,
        );
        driver.hideKeyboard();
        expect(CreateAccountScreen.passwordMatchError.waitForDisplayed()).toBe(
          true,
        );
        // CreateAccountScreen.confirmPasswordField.setValue('Test1234');
        CreateAccountScreen.sendKeysToElement(
          'Test1234',
          CreateAccountScreen.passwordMatchError,
        );
        driver.hideKeyboard();
        expect(CreateAccountScreen.passwordMatchError.isDisplayed()).toBe(
          false,
        );
        TouchActions.scrollToElement(CreateAccountScreen.emailField);
        // CreateAccountScreen.emailField.setValue('Test@test.com');
        CreateAccountScreen.sendKeysToElement(
          'Test@test.com',
          CreateAccountScreen.emailField,
        );
        driver.hideKeyboard();
        TouchActions.scrollToElement(CreateAccountScreen.confirmEmailField);
        // CreateAccountScreen.confirmEmailField.setValue('Test');
        CreateAccountScreen.sendKeysToElement(
          'Test',
          CreateAccountScreen.confirmEmailField,
        );
        driver.hideKeyboard();
        expect(CreateAccountScreen.emailMatchError.waitForDisplayed()).toBe(
          true,
        );
        // CreateAccountScreen.confirmEmailField.setValue('Test@test.com');
        CreateAccountScreen.sendKeysToElement(
          '@test.com',
          CreateAccountScreen.emailMatchError,
        );
        driver.hideKeyboard();
        expect(CreateAccountScreen.emailMatchError.isDisplayed()).toBe(false);
      });

      it('Text Me for password recovery', () => {
        CreateAccountScreen.createTestAccount();
        CreateAccountScreen.recoveryMethodDropdown.click();
        CreateAccountScreen.textMeSelection.click();
        // CreateAccountScreen.phoneNumberField.setValue('3216549870');
        CreateAccountScreen.sendKeysToElement(
          '3216549870',
          CreateAccountScreen.phoneNumberField,
        );
        driver.hideKeyboard();
        CreateAccountScreen.continueButton.click();
        expect(
          ConfirmIdentityScreen.confirmIdentityHeader.waitForDisplayed(),
        ).toBe(true);
        expect(
          ConfirmIdentityScreen.completeRegistrationDesc.isDisplayed(),
        ).toBe(true);
        expect(ConfirmIdentityScreen.emailMeButton.isDisplayed()).toBe(true);
        expect(ConfirmIdentityScreen.textMeButton.isDisplayed()).toBe(true);
        expect(ConfirmIdentityScreen.dataRatesText.isDisplayed()).toBe(true);
        ConfirmIdentityScreen.textMeButton.click();
        expect(ConfirmIdentityScreen.textConfirmation.waitForDisplayed()).toBe(
          true,
        );
        TouchActions.hardwareBack();
      });

      // C29447139
      // C29447141
      // C29447155
      // C29447198
      it('Security Questions for password recovery', () => {
        const clickMargin = driver.isAndroid ? 80 : 50;
        CreateAccountScreen.createTestAccount();
        TouchActions.scrollToElement(CreateAccountScreen.continueButton);
        CreateAccountScreen.continueButton.click();
        SecurityQuestionsScreen.securityQuestionsHeader.waitForDisplayed();
        TouchActions.clickBelow(
          SecurityQuestionsScreen.questionOne,
          clickMargin,
        );
        SecurityQuestionsScreen.sportTeam.click();
        // SecurityQuestionsScreen.answerOne.setValue('test1');
        SecurityQuestionsScreen.sendKeysToElement(
          'test1',
          SecurityQuestionsScreen.answerOne,
        );
        driver.hideKeyboard();
        SecurityQuestionsScreen.questionOne.click();
        TouchActions.scrollToElement(SecurityQuestionsScreen.answerTwo);
        TouchActions.clickBelow(
          SecurityQuestionsScreen.questionTwo,
          clickMargin,
        );
        SecurityQuestionsScreen.favoriteColor.click();
        // SecurityQuestionsScreen.answerTwo.setValue('test2');
        SecurityQuestionsScreen.answerTwo.waitForEnabled();
        SecurityQuestionsScreen.sendKeysToElement(
          'test2',
          SecurityQuestionsScreen.answerTwo,
        );
        driver.hideKeyboard();
        SecurityQuestionsScreen.questionTwo.click();
        TouchActions.scrollToElement(SecurityQuestionsScreen.answerThree);
        TouchActions.clickBelow(
          SecurityQuestionsScreen.questionThree,
          clickMargin,
        );
        SecurityQuestionsScreen.firstPhone.click();
        // SecurityQuestionsScreen.answerThree.setValue('test3');
        SecurityQuestionsScreen.answerThree.waitForEnabled();
        SecurityQuestionsScreen.sendKeysToElement(
          'test3',
          SecurityQuestionsScreen.answerThree,
        );
        driver.hideKeyboard();
        SecurityQuestionsScreen.questionThree.click();
        SecurityQuestionsScreen.continueButton.click();
        expect(
          SecurityQuestionsScreen.getElementByText(
            'Thank you!',
          ).waitForDisplayed(),
        ).toBe(true);
      });
    });
  });
});
