// @flow

import AccountSettingsScreen from '../screenobjects/settings/accountSettings.screen';
import ClaimsScreen from '../screenobjects/claims.screen';
import DashboardScreen from '../screenobjects/dashboard.screen';
import GuidedSearchScreen from '../screenobjects/guidedSearch.screen';
import MemberIdCardScreen from '../screenobjects/memberIdCard.screen';
import NavDrawerScreen from '../screenobjects/navDrawer.screen';
import SavedProvidersScreen from '../screenobjects/savedProviders.screen';
import TouchActions from '../interactions/touch.actions';
import { signIn } from '../interactions/signIn.actions';
import { ScrollDirection } from '../constants';

describe('Dashboard', () => {
  beforeAll(() => {
    driver.reset();
  });

  beforeEach(() => {
    signIn();
  });

  // C31652776
  describe('visual elements', () => {
    afterAll(() => {
      // scroll back to the top
      TouchActions.scrollToElement(
        DashboardScreen.quickLinksHeader,
        ScrollDirection.UP,
      );
    });

    // TODO: this is somewhat fragile; on Android it relies on the tests being run in the order they're listed
    // so that we don't scroll too far. The better (but slower) solution would probably be to scroll back
    // to the top after each test rather than after all of them

    it('should display the Quick Links section', () => {
      TouchActions.scrollToElement(DashboardScreen.quickLinksHeader);
      expect(DashboardScreen.quickLinksHeader.waitForExist()).toBe(true);
    });

    it('should display the Saved section', () => {
      TouchActions.scrollToElement(DashboardScreen.savedHeader);
      expect(DashboardScreen.savedHeader.waitForExist()).toBe(true);
    });

    it('should display the ID Card section', () => {
      TouchActions.scrollToElement(DashboardScreen.idCardHeader);
      expect(DashboardScreen.idCardHeader.waitForExist()).toBe(true);
    });

    it('should display the Account section', () => {
      TouchActions.scrollToElement(DashboardScreen.accountHeader);
      expect(DashboardScreen.accountHeader.waitForExist()).toBe(true);
    });

    it('should display the Claims section', () => {
      TouchActions.scrollToElement(DashboardScreen.claimsHeader);
      expect(DashboardScreen.claimsHeader.waitForExist()).toBe(true);
    });

    it('should display the Health Checklist section', () => {
      TouchActions.scrollToElement(DashboardScreen.healthChecklistHeader);
      expect(DashboardScreen.healthChecklistHeader.waitForExist()).toBe(true);
    });

    it('should display the Contact Us section', () => {
      TouchActions.scrollToElement(DashboardScreen.contactUsHeader);
      expect(DashboardScreen.contactUsHeader.waitForExist()).toBe(true);
    });
  });

  // C31652779
  // C31652823
  describe('Quick Links', () => {
    afterEach(() => {
      GuidedSearchScreen.goBack();
    });

    it('should navigate to the "Find Urgent Care" screen when tapping the "Find Urgent Care" link', () => {
      DashboardScreen.findUrgentCareQuickLink.waitForDisplayed();
      DashboardScreen.findUrgentCareQuickLink.click();
      expect(GuidedSearchScreen.kindOfCareHeader.waitForDisplayed()).toBe(true);
    });

    it('should navigate to the "Find Medical Care" screen when tapping the "Find Medical Care" link', () => {
      DashboardScreen.findMedicalCareQuickLink.waitForDisplayed();
      DashboardScreen.findMedicalCareQuickLink.click();
      expect(GuidedSearchScreen.findCareNearHeader.waitForDisplayed()).toBe(
        true,
      );
    });

    it('should navigate to the "Find Mental Health Care" screen when tapping the "Find Mental Health Care" link', () => {
      DashboardScreen.findMentalHealthCareQuickLink.waitForDisplayed();
      DashboardScreen.findMentalHealthCareQuickLink.click();
      expect(GuidedSearchScreen.careUnavailable.waitForDisplayed()).toBe(true);
    });

    it('should navigate to the "Claims" screen when tapping the "Manage Claims" link', () => {
      DashboardScreen.manageClaimsQuickLink.waitForDisplayed();
      DashboardScreen.manageClaimsQuickLink.click();
      expect(ClaimsScreen.screenHeader.waitForDisplayed()).toBe(true);
    });
  });

  describe('Saved section', () => {
    // C31652781
    it('should navigate to the Saved Providers screen when tapping the "See All" link', () => {
      TouchActions.scrollToElement(DashboardScreen.savedSeeAllLink);
      DashboardScreen.savedSeeAllLink.waitForDisplayed();
      DashboardScreen.savedSeeAllLink.click();

      // not sure why but without this little pause, iOS doesn't always find the header (shrug)
      driver.pause(500);
      expect(SavedProvidersScreen.screenHeader.waitForDisplayed()).toBe(true);
      SavedProvidersScreen.goBack();
    });
  });

  describe('Member ID Card section', () => {
    // C31652784
    it('should open the full-screen ID card when the card image is tapped', () => {
      TouchActions.scrollToElement(DashboardScreen.memberIdCard);
      DashboardScreen.memberIdCard.click();

      expect(MemberIdCardScreen.screenHeader.waitForDisplayed()).toBe(true);
      expect(MemberIdCardScreen.headerCancelButton.waitForDisplayed()).toBe(
        true,
      );
      MemberIdCardScreen.headerCancelButton.click();
      MemberIdCardScreen.headerCancelButton.waitForDisplayed(undefined, true); // wait for this modal to close before continuing
    });

    // C31652787
    // C31652789
    it('should show an explanation modal when tapping the "Send ID Card" button', () => {
      TouchActions.scrollToElement(DashboardScreen.sendIdCardButton);
      DashboardScreen.sendIdCardButton.click();

      expect(MemberIdCardScreen.sendIdCardModalHeader.waitForEnabled()).toBe(
        true,
      );
      MemberIdCardScreen.sendIdCardModalNoThanksButton.waitForEnabled();
      MemberIdCardScreen.sendIdCardModalNoThanksButton.click();
    });
  });

  describe('Navigation', () => {
    // C38749563
    it('should scroll to the top of the page when navigating to the dashboard from another screen', () => {
      // navigate to a different screen
      DashboardScreen.menuButton.click();
      NavDrawerScreen.settingsLink.waitForDisplayed();
      NavDrawerScreen.settingsLink.click();
      AccountSettingsScreen.header.waitForDisplayed();

      // navigate back to dashboard
      AccountSettingsScreen.menuButton.click();
      NavDrawerScreen.dashboardLink.waitForDisplayed();
      NavDrawerScreen.dashboardLink.click();

      // expect the quick links at the top of the screen to be visible
      expect(DashboardScreen.quickLinksHeader.waitForDisplayed()).toBe(true);
    });
  });
});
