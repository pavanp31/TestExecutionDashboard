// @flow

import WelcomeScreen from '../screenobjects/welcome.screen';
import SignInScreen from '../screenobjects/signIn.screen';
import DashboardScreen from '../screenobjects/dashboard.screen';
import { signIn } from '../interactions/signIn.actions';

describe('Login Flow', () => {
  beforeAll(() => {
    driver.reset(); // In case there's a saved username
  });

  describe('visual elements', () => {
    beforeEach(() => {
      WelcomeScreen.waitForLoaded();
      WelcomeScreen.signInBtn.click();
      SignInScreen.hsidNotice.waitForDisplayed();
    });

    afterEach(() => {
      SignInScreen.headerCancelButton.click();
      WelcomeScreen.welcomeLogo.waitForDisplayed();
    });

    it('should show the login screen', () => {
      expect(SignInScreen.hsidNotice.waitForDisplayed()).toBe(true);
      expect(SignInScreen.usernameField.isEnabled()).toBe(true);
      expect(SignInScreen.passwordField.isEnabled()).toBe(true);
      expect(SignInScreen.tosCheckbox.isEnabled()).toBe(true);
      expect(SignInScreen.signInButton.isEnabled()).toBe(true);
      expect(SignInScreen.createAccountLink.isEnabled()).toBe(true);
    });

    it('should show an error when trying to login without entering both username and password', () => {
      SignInScreen.signInButton.click();
      expect(SignInScreen.requiredErrors.length).toBe(2);
    });

    it('should show an error when trying to log in without entering a password', () => {
      SignInScreen.sendKeysToElement('test', SignInScreen.usernameField);
      driver.hideKeyboard();
      SignInScreen.signInButton.click();
      expect(SignInScreen.requiredErrors.length).toBe(1);
    });

    it('should show an error when trying to log in without entering a username', () => {
      SignInScreen.sendKeysToElement('test', SignInScreen.passwordField);
      driver.hideKeyboard();
      SignInScreen.signInButton.click();
      expect(SignInScreen.requiredErrors.length).toBe(1);
    });

    it('should show an error when trying to log in without accepting the terms of service', () => {
      expect(SignInScreen.tosError.isDisplayed()).toBe(false);

      // SignInScreen.usernameField.setValue('test');
      // SignInScreen.passwordField.setValue('test');
      SignInScreen.sendKeysToElement('test', SignInScreen.usernameField);
      SignInScreen.sendKeysToElement('test', SignInScreen.passwordField);
      driver.hideKeyboard();
      SignInScreen.signInButton.click();

      expect(SignInScreen.tosError.waitForDisplayed()).toBe(true);
    });
  });

  // C31652775
  it('should log in successfully', () => {
    signIn();

    // expect to see the dashboard
    expect(DashboardScreen.quickLinksHeader.waitForDisplayed()).toBe(true);
  });
});
