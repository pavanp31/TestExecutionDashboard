// @flow

import DashboardScreen from '../../screenobjects/dashboard.screen';
import NavDrawerScreen from '../../screenobjects/navDrawer.screen';
import ResultsListScreen from '../../screenobjects/resultsList.screen';
import FindMedicalCareScreen from '../../screenobjects/fpc/findMedicalCare.screen';
import FindPeopleScreen from '../../screenobjects/fpc/findPeople.screen';
import DoctorDetailsScreen from '../../screenobjects/providerDetails/doctorDetails/doctorDetails.screen';
import OverviewTab from '../../screenobjects/providerDetails/doctorDetails/overviewTab.screen';
import ServicesAndCostsTab from '../../screenobjects/providerDetails/doctorDetails/servicesAndCostsTab.screen';
import LocationsTab from '../../screenobjects/providerDetails/doctorDetails/locationsTab.screen';
import IncorrectInformationModalScreen from '../../screenobjects/providerDetails/incorrectInformationModal.screen';
import MedicalGroupDetailsScreen from '../../screenobjects/providerDetails/medicalGroupDetails.screen';
import ExplanationOfCostsModalScreen from '../../screenobjects/providerDetails/explanationOfCostsModal.screen';
import ServiceDetailsScreen from '../../screenobjects/providerDetails/serviceDetails.screen';
import FullCostSummaryScreen from '../../screenobjects/providerDetails/fullCostSummary.screen';

import { signIn } from '../../interactions/signIn.actions';
import TouchActions from '../../interactions/touch.actions';

describe('Doctor Details', () => {
  function navigateToDoctorDetailsScreen() {
    DashboardScreen.findMedicalCareButton.waitForEnabled();
    DashboardScreen.findMedicalCareButton.click();
    FindMedicalCareScreen.peopleButton.waitForEnabled();
    FindMedicalCareScreen.peopleButton.click();
    FindPeopleScreen.whoYouLookingForHeader.waitForDisplayed();
    FindPeopleScreen.primaryCareButton.click();
    FindPeopleScreen.getElementByText(
      'All Primary Care Physicians',
    ).waitForDisplayed();
    FindPeopleScreen.getElementByText('All Primary Care Physicians').click();

    ResultsListScreen.filterButton.waitForDisplayed();
    ResultsListScreen.firstProviderResult.waitForDisplayed();
    TouchActions.clickUpperLeft(ResultsListScreen.firstProviderResult);
    OverviewTab.phoneLink.waitForDisplayed();
  }

  beforeAll(() => {
    driver.reset();
    signIn();
  });

  describe('Common elements', () => {
    beforeAll(() => {
      navigateToDoctorDetailsScreen();
    });

    afterAll(() => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.click();
    });

    // C31653014
    it('should navigate to the doctor details page when tapping a doctor in the results list', () => {
      expect(DoctorDetailsScreen.providerName.waitForDisplayed()).toBe(true);
      expect(DoctorDetailsScreen.specialties.waitForDisplayed()).toBe(true);
      expect(DoctorDetailsScreen.reviews.waitForDisplayed()).toBe(true);
    });

    // C31653027
    // C31653029
    it(`should display the 'Report Incorrect Information' form when the link is clicked`, () => {
      expect(
        DoctorDetailsScreen.incorrectInformationLink.waitForDisplayed(),
      ).toBe(true);
      DoctorDetailsScreen.incorrectInformationLink.click();

      expect(IncorrectInformationModalScreen.header.waitForDisplayed()).toBe(
        true,
      );
      IncorrectInformationModalScreen.nameCheckbox.waitForEnabled();
      IncorrectInformationModalScreen.nameCheckbox.click();
      TouchActions.scrollToElement(IncorrectInformationModalScreen.sendButton);
      IncorrectInformationModalScreen.sendButton.click();

      expect(
        IncorrectInformationModalScreen.successModal.waitForDisplayed(),
      ).toBe(true);

      IncorrectInformationModalScreen.closeButton.click();
    });
  });

  describe('Overview tab', () => {
    beforeAll(() => {
      navigateToDoctorDetailsScreen();
    });

    afterAll(() => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.click();
    });

    // C31653018
    it('should copy the address to the clipboard when long-pressing it', async () => {
      TouchActions.scrollToElement(OverviewTab.addressLink);
      const address = OverviewTab.addressLink.getText();
      TouchActions.longPress(OverviewTab.addressLink);

      const cb = await driver.getClipboard();
      const addressInClipboard = Buffer.from(cb, 'base64').toString();

      expect(addressInClipboard).toEqual(address);
    });

    // C31653020
    it('should try to call the provider when the phone number is pressed', () => {
      TouchActions.scrollToElement(OverviewTab.phoneLink);
      OverviewTab.phoneLink.click();

      if (driver.isAndroid) {
        expect(OverviewTab.phoneDialer.waitForDisplayed()).toBe(true);
        TouchActions.hardwareBack();
      } else {
        // Call links aren't doing anything in sims
        // DoctorDetailsScreen.okButton.click();
      }
    });

    // C31653024
    it(`should show the 'Accepting Patients Status' modal when tapping the status link`, () => {
      TouchActions.scrollToElement(OverviewTab.acceptingPatientsLink);
      OverviewTab.acceptingPatientsLink.click();
      expect(OverviewTab.acceptingPatientsModalContent.waitForDisplayed()).toBe(
        true,
      );
      expect(DoctorDetailsScreen.closeButton.waitForDisplayed()).toBe(true);
      DoctorDetailsScreen.closeButton.click();
    });

    // C31653036
    it('should display the Accessibility section', () => {
      TouchActions.scrollToElement(OverviewTab.accessibilityOptions);
      expect(OverviewTab.accessibilityOptions.waitForDisplayed()).toBe(true);

      expect(OverviewTab.accessibilityOptionLink.waitForDisplayed()).toBe(true);
      OverviewTab.accessibilityOptionLink.click();

      expect(
        OverviewTab.accessibilityOptionModalContent.waitForDisplayed(),
      ).toBe(true);
      expect(DoctorDetailsScreen.closeButton.waitForDisplayed()).toBe(true);
      DoctorDetailsScreen.closeButton.click();
    });

    // C31653035
    it(`should display the 'Provider Data Information' link`, () => {
      TouchActions.scrollToElement(OverviewTab.providerDataInformationLink);
      expect(OverviewTab.providerDataInformationLink.waitForEnabled()).toBe(
        true,
      );
      OverviewTab.providerDataInformationLink.click();

      expect(OverviewTab.providerDataInformationModal.waitForDisplayed()).toBe(
        true,
      );
      expect(DoctorDetailsScreen.closeButton.waitForDisplayed()).toBe(true);
      DoctorDetailsScreen.closeButton.click();
    });

    // C39175556
    it(`should display the 'Provider Group' section`, () => {
      TouchActions.scrollToElement(OverviewTab.providerGroupSection);
      TouchActions.scrollToElement(OverviewTab.providerGroupLink);
      OverviewTab.providerGroupLink.click();

      expect(MedicalGroupDetailsScreen.header.waitForDisplayed()).toBe(true);
      MedicalGroupDetailsScreen.backButton.click();
    });

    // C40571509
    it(`should display the 'Specialties' section`, () => {
      TouchActions.scrollToElement(OverviewTab.specialtiesSection);
      TouchActions.scrollToElement(OverviewTab.specialtiesLink);
      OverviewTab.specialtiesLink.click();

      expect(OverviewTab.specialtiesModal.waitForDisplayed()).toBe(true);
      DoctorDetailsScreen.closeButton.click();
    });
  });

  describe('Services & Costs tab', () => {
    beforeAll(() => {
      navigateToDoctorDetailsScreen();
      DoctorDetailsScreen.servicesAndCostsTab.waitForEnabled();
      const location = DoctorDetailsScreen.servicesAndCostsTab.getLocation();
      TouchActions.clickAtCoordinates(location.x + 30, location.y);
      ServicesAndCostsTab.servicesSearchBox.waitForDisplayed();
    });

    afterAll(() => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.click();
    });

    // C31653037
    // C31653045
    it('should display the services & costs list', () => {
      expect(ServicesAndCostsTab.servicesSearchBox.isExisting()).toBe(true);
      expect(
        ServicesAndCostsTab.servicesSearchBoxPlaceholderText.isExisting(),
      ).toBe(true);
      expect(ServicesAndCostsTab.explanationOfCosts.isExisting()).toBe(true);

      // TODO: these assertions are commented out because for whatever reason, it takes webdriver a very long time to find it here,
      // and most of the time the test will timeout and fail. Other tests are finding and clicking this link though so there is still coverage
      // expect(ServicesAndCostsTab.serviceDetailLink.isExisting()).toBe(true);
      // expect(ServicesAndCostsTab.serviceDetailLink.getText()).toInclude(
      //   'Estimated Total Cost',
      // );
    });

    // C31653040
    // C31653041
    it('should filter the services list if the user types in the search box', () => {
      expect(ServicesAndCostsTab.matchingServicesText.isExisting()).toBe(false);
      // ServicesAndCostsTab.servicesSearchBox.setValue('Chickenpox');
      ServicesAndCostsTab.sendKeysToElement(
        'Chickenpox',
        ServicesAndCostsTab.servicesSearchBox,
      );
      expect(ServicesAndCostsTab.matchingServicesText.waitForExist()).toBe(
        true,
      );
      // ServicesAndCostsTab.servicesSearchBox.clearValue();
      driver.hideKeyboard();
    });

    // C31653042
    it('should hide the keyboard when the user taps on a service after searching', () => {
      // ServicesAndCostsTab.servicesSearchBox.setValue('Chickenpox');
      ServicesAndCostsTab.sendKeysToElement(
        'Chickenpox',
        ServicesAndCostsTab.servicesSearchBox,
      );
      expect(driver.isKeyboardShown()).toBe(true);
      ServicesAndCostsTab.serviceDetailLink.click();
      driver.pause(500);
      expect(driver.isKeyboardShown()).toBe(false);

      ServiceDetailsScreen.backButton.waitForDisplayed();
      ServiceDetailsScreen.backButton.click();
    });

    // // C31653043
    it(`should remove the service list filter when the search box is cleared`, () => {
      // ServicesAndCostsTab.servicesSearchBox.setValue('Chickenpox');
      ServicesAndCostsTab.sendKeysToElement(
        'Chickenpox',
        ServicesAndCostsTab.servicesSearchBox,
      );
      expect(ServicesAndCostsTab.matchingServicesText.waitForExist()).toBe(
        true,
      );

      // ServicesAndCostsTab.servicesSearchBox.clearValue();
      ServicesAndCostsTab.sendKeysToElement(
        '',
        ServicesAndCostsTab.servicesSearchBox,
      );
      driver.pause(500);
      driver.hideKeyboard();

      expect(ServicesAndCostsTab.matchingServicesText.isExisting()).toBe(false);
    });

    // // C31653044
    it(`should display a 'No Matching Services' message if there are no services that match the search test`, () => {
      // ServicesAndCostsTab.servicesSearchBox.setValue('razzmatazz');
      ServicesAndCostsTab.sendKeysToElement(
        'razzmatazz',
        ServicesAndCostsTab.servicesSearchBox,
      );
      expect(ServicesAndCostsTab.noMatchingServicesText.waitForExist()).toBe(
        true,
      );

      // ServicesAndCostsTab.servicesSearchBox.clearValue();
      ServicesAndCostsTab.sendKeysToElement(
        '',
        ServicesAndCostsTab.servicesSearchBox,
      );
      driver.hideKeyboard();
    });

    // C31653046
    it(`should display the 'Explanation of Costs' modal when the link is tapped`, () => {
      ServicesAndCostsTab.explanationOfCosts.click();

      expect(ExplanationOfCostsModalScreen.header.waitForExist()).toBe(true);
      expect(ExplanationOfCostsModalScreen.averageCost.waitForExist()).toBe(
        true,
      );
      expect(
        ExplanationOfCostsModalScreen.estimatedTotalCost.waitForExist(),
      ).toBe(true);
      expect(ExplanationOfCostsModalScreen.insurancePays.waitForExist()).toBe(
        true,
      );
      expect(
        ExplanationOfCostsModalScreen.estimatedOutOfPocketCost.waitForExist(),
      ).toBe(true);
      expect(
        ExplanationOfCostsModalScreen.amountAppliedToDeductible.waitForExist(),
      ).toBe(true);
      expect(ExplanationOfCostsModalScreen.copay.waitForExist()).toBe(true);
      expect(ExplanationOfCostsModalScreen.coinsurance.waitForExist()).toBe(
        true,
      );

      ExplanationOfCostsModalScreen.closeButton.click();
    });

    // C31653060
    it(`should navigate to the Full Cost Summary screen when clicking through to see a service estimate`, () => {
      ServicesAndCostsTab.serviceDetailLink.click();
      expect(ServiceDetailsScreen.header.waitForDisplayed()).toBe(true);
      ServiceDetailsScreen.viewFullEstimateButton.click();
      expect(FullCostSummaryScreen.header.waitForDisplayed()).toBe(true);

      FullCostSummaryScreen.backButton.click();
      ServiceDetailsScreen.backButton.waitForDisplayed();
      ServiceDetailsScreen.backButton.click();
    });
  });

  describe('Locations tab', () => {
    beforeAll(() => {
      navigateToDoctorDetailsScreen();
      DoctorDetailsScreen.locationsTab.waitForEnabled();
      const location = DoctorDetailsScreen.locationsTab.getLocation();
      TouchActions.clickAtCoordinates(location.x + 30, location.y);
      LocationsTab.locationHeader.waitForDisplayed();
    });

    afterAll(() => {
      NavDrawerScreen.openNavDrawer();
      NavDrawerScreen.dashboardLink.click();
    });

    // C31653093
    it('should display the address and copy to the clipboard when tapped & held', async () => {
      TouchActions.scrollToElement(LocationsTab.addressLink);
      const address = LocationsTab.addressLink.getText();
      TouchActions.longPress(LocationsTab.addressLink);

      const cb = await driver.getClipboard();
      const addressInClipboard = Buffer.from(cb, 'base64').toString();

      expect(addressInClipboard).toEqual(address);
    });

    // C31653107
    it(`should display the provider's medical group affiliations`, () => {
      expect(LocationsTab.medicalGroupsHeader.waitForExist()).toBe(true);
    });

    // C31653109
    // C31653110
    it(`should display the 'Accepting Patients Status' modal when tapping the status link`, () => {
      TouchActions.scrollToElement(LocationsTab.acceptingPatientsLink);
      LocationsTab.acceptingPatientsLink.click();
      expect(
        LocationsTab.acceptingPatientsModalContent.waitForDisplayed(),
      ).toBe(true);
      expect(DoctorDetailsScreen.closeButton.waitForDisplayed()).toBe(true);
      DoctorDetailsScreen.closeButton.click();
    });
  });
});
