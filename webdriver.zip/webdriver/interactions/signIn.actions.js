// @flow

import AccountSettingsScreen from '../screenobjects/settings/accountSettings.screen';
import DashboardScreen from '../screenobjects/dashboard.screen';
import DevDrawerScreen from '../screenobjects/devDrawer.screen';
import NavDrawerScreen from '../screenobjects/navDrawer.screen';
import SetLocationModalScreen from '../screenobjects/setLocationModal.screen';
import SignInScreen from '../screenobjects/signIn.screen';
import WelcomeScreen from '../screenobjects/welcome.screen';
import { SHORT_WAIT } from '../constants';

/**
 If not already on the Dashboard or Set Location screen, log in and set location
 */
export function signIn(
  env: string = 'Local',
  userName: string = 'test',
  password: string = 'test',
  superLongWait: boolean = false,
) {
  // Already logged in on Dashboard screen
  if (NavDrawerScreen.menuButton.isDisplayed()) {
    return;
  }

  // Check if already on Set Location screen, otherwise log in
  if (!SetLocationModalScreen.useCurrentLocationButton.isDisplayed()) {
    try {
      WelcomeScreen.waitForLoaded();
    } catch (error) {
      driver.reset();
      WelcomeScreen.waitForLoaded();
    }
    WelcomeScreen.openDevDrawer();
    DevDrawerScreen.switchEnvironment(env);
    WelcomeScreen.signInBtn.waitForEnabled();
    WelcomeScreen.signInBtn.click();
    SignInScreen.defaultLogIn(userName, password, superLongWait);
  }

  // Set Location
  SetLocationModalScreen.defaultLocation();

  // Close the NPS modal if it appears
  try {
    DashboardScreen.npsModalTitle.waitForDisplayed(SHORT_WAIT);
    DashboardScreen.closeButton.waitForDisplayed();
    DashboardScreen.closeButton.click();
  } catch (IGNORE) {
    // no NPS modal, no problem
  }
  NavDrawerScreen.menuButton.waitForDisplayed();
}

/**
 If not already on the Welcome screen or Splash screen, log out
 */
export function signOut() {
  if (
    !(
      WelcomeScreen.welcomeLogo.isDisplayed() ||
      WelcomeScreen.splashScreenLogo.isDisplayed()
    )
  ) {
    NavDrawerScreen.openNavDrawer();
    NavDrawerScreen.settingsLink.waitForDisplayed();
    NavDrawerScreen.settingsLink.click();

    AccountSettingsScreen.header.waitForDisplayed();
    AccountSettingsScreen.scrollToLogoutLink();
    AccountSettingsScreen.logOutLink.click();
    // iOS auto accepts alerts
    if (driver.isAndroid) {
      AccountSettingsScreen.yesButton.click();
    }
    WelcomeScreen.waitForLoaded();
  }
}
