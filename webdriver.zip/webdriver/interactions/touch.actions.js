// @flow

import { SMALL_MARGIN, ScrollDirection } from '../constants';

export default class TouchActions {
  /**
   * Swipe from coordinates (from) to the new coordinates (to). The given coordinates are in pixels, and should be in the format { x: number, y: number }.
   */
  static swipe(from: WDActionOptions, to: WDActionOptions) {
    driver.touchPerform([
      {
        action: 'press',
        options: from,
      },
      {
        action: 'wait',
        options: { ms: 1000 },
      },
      {
        action: 'moveTo',
        options: to,
      },
      {
        action: 'release',
      },
    ]);
    driver.pause(1000);
  }

  /**
   * Clicks the corners of an element
   */
  static clickLowerLeft(element: WDElement) {
    const height = element.getSize('height') - SMALL_MARGIN;
    const x = element.getLocation('x');
    const y = element.getLocation('y') + height;
    TouchActions.clickAtCoordinates(x, y);
  }

  static clickLowerRight(element: WDElement) {
    const height = element.getSize('height') - SMALL_MARGIN;
    const width = element.getSize('width') - SMALL_MARGIN;
    const x = element.getLocation('x') + width;
    const y = element.getLocation('y') + height;
    TouchActions.clickAtCoordinates(x, y);
  }

  static clickUpperLeft(element: WDElement) {
    const x = element.getLocation('x');
    const y = element.getLocation('y');
    TouchActions.clickAtCoordinates(x, y);
  }

  /**
   * Clicks next to an element, for interactions with elements that can't be selected
   */
  static clickAbove(element: WDElement, distance: number = SMALL_MARGIN) {
    element.waitForEnabled();
    const x = element.getLocation('x');
    const y = element.getLocation('y') - distance;
    TouchActions.clickAtCoordinates(x, y);
  }

  static clickBelow(element: WDElement, distance: number = SMALL_MARGIN) {
    element.waitForEnabled();
    const x = element.getLocation('x');
    const y = element.getLocation('y') + distance;
    TouchActions.clickAtCoordinates(x, y);
  }

  static clickBelowRight(element: WDElement, distance: number = SMALL_MARGIN) {
    element.waitForEnabled();
    const x =
      element.getLocation('x') + element.getSize('width') - SMALL_MARGIN;
    const y = element.getLocation('y') + element.getSize('height') + distance;
    TouchActions.clickAtCoordinates(x, y);
  }

  /**
   * Taps the screen at the provided (x, y) coordinates
   */
  static clickAtCoordinates(x: number, y: number) {
    driver.touchPerform([
      {
        action: 'press',
        options: { x, y },
      },
      {
        action: 'release',
      },
    ]);
  }

  /**
   * Long press
   * note: there is a built in `element.touchAction('longPress')` method, but it seems pretty flaky,
   * often just tapping on the element rather than tapping and holding. This way is more reliable
   */
  static longPress(element: WDElement, milliseconds: number = 1000) {
    driver.touchPerform([
      {
        action: 'press',
        options: {
          x: element.getLocation('x'),
          y: element.getLocation('y'),
        },
      },
      {
        action: 'wait',
        options: { ms: milliseconds },
      },
      {
        action: 'release',
      },
    ]);
  }

  /* Use the OS level back button (as opposed to the app navigation back button) */
  static hardwareBack() {
    if (driver.isAndroid) {
      driver.pressKeyCode(4);
    } else {
      const screenSize = driver.getWindowRect();
      TouchActions.swipe(
        { x: 1, y: screenSize.height / 2 },
        { x: screenSize.width - 10, y: screenSize.height / 2 },
      );
    }
  }

  static scrollToElement(
    element: WDElement,
    scrollDirection: $Values<typeof ScrollDirection> = ScrollDirection.DOWN,
    maxSwipes: number = 4,
  ) {
    const screenSize = driver.getWindowRect();
    const scrollDown = scrollDirection === ScrollDirection.DOWN;
    const swipeStart = {
      x: screenSize.width / 2,
      y: screenSize.height * (scrollDown ? 0.75 : 0.25),
    };
    const swipeEnd = {
      x: screenSize.width / 2,
      y: screenSize.height * (scrollDown ? 0.25 : 0.75),
    };
    let counter = 0;
    while (!element.isDisplayed()) {
      TouchActions.swipe(swipeStart, swipeEnd);
      if (counter >= maxSwipes) {
        throw new Error(
          `We've scrolled a lot and didn't find element with selector '${
            element.selector
          }', I don't think it's here`,
        );
      }
      counter += 1;
    }
  }

  static scrollToTop(maxSwipes: number = 10) {
    const screenSize = driver.getWindowRect();
    const swipeStart = {
      x: screenSize.width / 2,
      y: screenSize.height * 0.25,
    };
    const swipeEnd = {
      x: screenSize.width / 2,
      y: screenSize.height * 0.75,
    };
    let counter = 0;
    while (counter < maxSwipes) {
      TouchActions.swipe(swipeStart, swipeEnd);
      counter += 1;
    }
  }

  /**
   * Breadcrumb (iOS only)
   * tap the breadcrumb link at the top left of the screen.
   * Useful when trying to get back to the UHC app after a link launches another app
   */
  static breadcrumbBack() {
    if (driver.isAndroid) {
      return;
    }
    driver.touchPerform([{ action: 'press', options: { x: 10, y: 10 } }]);
  }
}
