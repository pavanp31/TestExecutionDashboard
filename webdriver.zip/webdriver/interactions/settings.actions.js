// @flow
import AccountSettingsScreen from '../screenobjects/settings/accountSettings.screen';
import NavDrawerScreen from '../screenobjects/navDrawer.screen';

export function navigateToSettings() {
  NavDrawerScreen.openNavDrawer();
  NavDrawerScreen.settingsLink.waitForDisplayed();
  NavDrawerScreen.settingsLink.click();
  AccountSettingsScreen.header.waitForDisplayed();
}
