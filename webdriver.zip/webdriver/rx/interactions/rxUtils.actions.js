// @flow

// common rx actions file used across all rx components
import RxUtilsScreen from '../screenobjects/rxUtils.screen';

export function changeCurrentLocation() {
  const currentLocation = RxUtilsScreen.locationLink.getText();

  RxUtilsScreen.selectlocationLink();

  const updatedLocation = RxUtilsScreen.setLocation(currentLocation);

  return updatedLocation;
}
