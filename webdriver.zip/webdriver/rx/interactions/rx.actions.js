// @flow
import NavDrawerScreen from '../../screenobjects/navDrawer.screen';
import RxDashboardScreen from '../screenobjects/rxDashboard.screen';
import PharmacySearchScreen from '../screenobjects/pharmacySearch.screen';
import DrugSearchScreen from '../screenobjects/drugSearch.screen';
import DrugWizardScreen from '../screenobjects/drugWizard.screen';
import RxMedCabScreen from '../screenobjects/rxMedCab.screen';
import DrugPricingScreen from '../screenobjects/drugPricing.screen';
import { SUPER_LONG_WAIT, ScrollDirection } from '../../constants';
import TouchActions from '../../interactions/touch.actions';
import {
  partialAmoxicillinDrugName,
  fullAmoxicillinDrugName,
  fullAmoxicillinDrugNameWithType,
} from '../rxConstants';

export function navigateToCurrentMedicationsPage() {
  NavDrawerScreen.openNavDrawer();

  NavDrawerScreen.pharmaciesAndPrescriptionsLink.waitForEnabled();
  NavDrawerScreen.pharmaciesAndPrescriptionsLink.click();

  RxDashboardScreen.currentMedicationsButton.waitForEnabled();
  RxDashboardScreen.currentMedicationsButton.click();
}
export function navigateToPharmacyLocatorPage() {
  NavDrawerScreen.openNavDrawer();

  NavDrawerScreen.pharmaciesAndPrescriptionsLink.waitForEnabled();
  NavDrawerScreen.pharmaciesAndPrescriptionsLink.click();

  RxDashboardScreen.pharmacyLocatorLink.waitForEnabled();
  RxDashboardScreen.pharmacyLocatorLink.click();
}

export function inputPharmacySearchData(type: string, data: string) {
  PharmacySearchScreen.inputPharmacySearchData(type, data);
}

export function selectAllPharmacySearchResults(input: string) {
  PharmacySearchScreen.selectAllPharmacySearchResults(input);
}

export function selectPharmacySearchType(
  androidValue: string,
  iosValue: string,
) {
  PharmacySearchScreen.selectPharmacySearchType(androidValue, iosValue);
}

export function clickOnChangeLocation(type: string) {
  PharmacySearchScreen.clickOnChangeLocation(type);
}

export function enterNewLocationZipCode(data: string) {
  PharmacySearchScreen.enterNewLocationZipCode(data);
}

export function clickOnItemsDisplayedWithTypeheadSearch(data: string) {
  PharmacySearchScreen.getSearchResultListWithTypehead(data).click();
}

// drug search actions
export function navigateToDrugSearchPage() {
  NavDrawerScreen.openNavDrawer();

  NavDrawerScreen.pharmaciesAndPrescriptionsLink.waitForEnabled();
  NavDrawerScreen.pharmaciesAndPrescriptionsLink.click();

  RxDashboardScreen.findAndPriceMedicationsLink.waitForEnabled();
  RxDashboardScreen.findAndPriceMedicationsLink.click();
}

export function inputDrugSearchData(data: string) {
  DrugSearchScreen.inputDrugSearchData(data);
}

export function selectTopSuggestionDrugByName(name: string) {
  DrugSearchScreen.topSuggestionHeader.waitForDisplayed();
  DrugSearchScreen.selectDrugByName(name);
}

export function selectShowAllResultsForByInputTextLink(input: string) {
  DrugSearchScreen.showAllResultsForHeader.waitForDisplayed();
  DrugSearchScreen.selectDrugByName(input);
}

export function selectBrandDrugFromAllResultsList(name: string) {
  DrugSearchScreen.selectDrugByName(name);
}

// drug wizard actions
export function selectDrugWizardFormAndStrengthThenCalculate(
  form: string,
  strength: string,
) {
  selectDrugFormOnWizardPage(form);
  selectDrugStrengthOnWizardPage(strength);
  calculateDrug();
}

export function selectDrugTotalQuantity(
  selection: string,
  customValue: string,
) {
  TouchActions.scrollToElement(DrugWizardScreen.calculateCostButton);

  DrugWizardScreen.totalQuantityDropdown.waitForEnabled();
  DrugWizardScreen.totalQuantityDropdown.click();

  DrugWizardScreen.selectDrugWizardValueFromSelector(selection);

  DrugWizardScreen.enterCustomValue('quantity', customValue);
}

export function selectDrugDaysSupply(selection: string, customValue: string) {
  TouchActions.scrollToElement(DrugWizardScreen.calculateCostButton);

  DrugWizardScreen.daysSupplyDropdown.waitForEnabled();
  DrugWizardScreen.daysSupplyDropdown.click();

  DrugWizardScreen.selectDrugWizardValueFromSelector(selection);

  DrugWizardScreen.enterCustomValue('days', customValue);
}

export function changeCurrentMember(members: { from: string, to: string }) {
  DrugWizardScreen.memberSelectionLink(members.from).waitForDisplayed();
  DrugWizardScreen.memberSelectionLink(members.from).click();

  DrugWizardScreen.selectDrugWizardValueFromSelector(members.to);
}

export function selectDrugFormOnWizardPage(form: string) {
  DrugWizardScreen.formDropdown.waitForDisplayed();
  DrugWizardScreen.formDropdown.click();

  DrugWizardScreen.selectDrugWizardValueFromSelector(form);
}

export function selectDrugStrengthOnWizardPage(strength: string) {
  DrugWizardScreen.strengthDropdown.waitForDisplayed();
  DrugWizardScreen.strengthDropdown.click();

  DrugWizardScreen.selectDrugWizardValueFromSelector(strength, true);
}

export function calculateDrug() {
  TouchActions.scrollToElement(DrugWizardScreen.calculateCostButton);

  DrugWizardScreen.calculateCostButton.waitForDisplayed();
  DrugWizardScreen.calculateCostButton.click();

  DrugWizardScreen.drugPricingPageHeader.waitForDisplayed(SUPER_LONG_WAIT);
}

export function clickMoreOrLessButtonWithAlertPresent() {
  DrugWizardScreen.moreOrLessButton.waitForDisplayed();
  DrugWizardScreen.moreOrLessButton.click();
}

// Drug Pricing Actions
export function navigateToDrugPricingPage() {
  NavDrawerScreen.openNavDrawer();

  NavDrawerScreen.pharmaciesAndPrescriptionsLink.waitForEnabled();
  NavDrawerScreen.pharmaciesAndPrescriptionsLink.click();

  RxDashboardScreen.findAndPriceMedicationsLink.waitForEnabled();
  RxDashboardScreen.findAndPriceMedicationsLink.click();

  inputDrugSearchData(partialAmoxicillinDrugName);

  selectTopSuggestionDrugByName(fullAmoxicillinDrugName);

  DrugSearchScreen.drugNameInWizardSettingsHeader(
    fullAmoxicillinDrugNameWithType,
  );

  calculateDrug();
}

export function refineSearchResultsBySortType(sortType: string) {
  TouchActions.scrollToElement(
    DrugPricingScreen.refineResultsButton,
    ScrollDirection.UP,
    10,
  );

  DrugPricingScreen.refineResultsButton.waitForEnabled();
  DrugPricingScreen.refineResultsButton.click();

  DrugPricingScreen.refineSearchHeader.waitForEnabled();

  DrugPricingScreen.sortByRadioButton(sortType).waitForEnabled();
  DrugPricingScreen.sortByRadioButton(sortType).click();

  TouchActions.scrollToElement(DrugPricingScreen.applyButton);

  DrugPricingScreen.applyButton.waitForEnabled();
  DrugPricingScreen.applyButton.click();

  DrugPricingScreen.medicationInfoAndPricingHeader.waitForEnabled();
}

export function refineSearchResultsByUpdatingMedicationDetails(
  form: string,
  strength: string,
) {
  DrugPricingScreen.refineResultsButton.waitForEnabled();
  DrugPricingScreen.refineResultsButton.click();

  DrugPricingScreen.refineSearchHeader.waitForEnabled();

  selectDrugFormOnPricingFilterPage(form);
  selectDrugStrengthOnPricingFilterPage(strength);

  TouchActions.scrollToElement(DrugPricingScreen.applyButton);

  DrugPricingScreen.applyButton.waitForEnabled();
  DrugPricingScreen.applyButton.click();

  DrugPricingScreen.medicationInfoAndPricingHeader.waitForEnabled();
}

export function selectDrugFormOnPricingFilterPage(form: string) {
  DrugPricingScreen.formDropdown.waitForDisplayed();
  DrugPricingScreen.formDropdown.click();

  DrugWizardScreen.selectDrugWizardValueFromSelector(form);
}

export function selectDrugStrengthOnPricingFilterPage(strength: string) {
  DrugPricingScreen.strengthDropdown.waitForDisplayed();
  DrugPricingScreen.strengthDropdown.click();

  DrugWizardScreen.selectDrugWizardValueFromSelector(strength, true);
}

export function clickMoreOrLessButton() {
  DrugPricingScreen.moreOrLessButton.waitForDisplayed();
  DrugPricingScreen.moreOrLessButton.click();
}

// Med Cab actions
export function changeMedicineCabinetMember(
  currentMember: string,
  newMember: string,
) {
  RxMedCabScreen.selectMemberFromShowMedicationsForFilter(
    currentMember,
    newMember,
  );

  RxMedCabScreen.applyFiltersButton.waitForEnabled();
  RxMedCabScreen.applyFiltersButton.click();

  RxMedCabScreen.navigatesToMedCabAfterApplyingMemberFilter(newMember);
}

export function navigateToDrugPricingPageFromMedCab() {
  RxMedCabScreen.getPricingLink.waitForDisplayed(SUPER_LONG_WAIT);
  RxMedCabScreen.getPricingLink.click();

  RxMedCabScreen.medicationAndPricingHeader.waitForDisplayed(SUPER_LONG_WAIT);
}

export function scrollDownToLoadNextPageData(
  numberOfSwipes: number,
  scrollDirection: $Values<typeof ScrollDirection> = ScrollDirection.DOWN,
) {
  const screenSize = driver.getWindowRect();

  const scrollDown = scrollDirection === ScrollDirection.DOWN;

  const swipeStart = {
    x: screenSize.width / 2,
    y: screenSize.height * (scrollDown ? 0.75 : 0.25),
  };

  const swipeEnd = {
    x: screenSize.width / 2,
    y: screenSize.height * (scrollDown ? 0.3 : 0.75),
  };

  let counter = 0;
  while (counter < numberOfSwipes) {
    TouchActions.swipe(swipeStart, swipeEnd);
    if (counter >= numberOfSwipes) {
      break;
    }
    counter += 1;
  }
}
