// @flow

// login constants
export const environment = 'Development';
export const username = 'BOWDEN.CHAVARRIA.BPE';
export const password = 'Test2day';

// member constatnts
export const primaryMember = 'Member KitchenSink';
export const authorizedMember = 'Authorized KitchenSink';

// pharmacy search constants
export const npi = '1598787202';
export const stateLicense = '054013330';

// drug search constants
export const partialAmoxicillinDrugName = 'amox';
export const fullAmoxicillinDrugName = 'Amoxicillin';
export const fullAmoxicillinDrugNameWithType = 'Amoxicillin (Generic)';

export const partialCarisoprodolDrugName = 'caris';

export const fullCarimuneDrugNameWithType = 'Carimune NF (Brand)';

export const fullClariSprayDrugNameWithType = 'ClariSpray (Branded Generic)';
