import { signIn } from '../../../interactions/signIn.actions';
import {
  environment,
  username,
  password,
  npi,
  stateLicense,
} from '../../rxConstants';
import PharmacySearchScreen from '../../screenobjects/pharmacySearch.screen';
import {
  navigateToPharmacyLocatorPage,
  inputPharmacySearchData,
  selectAllPharmacySearchResults,
  selectPharmacySearchType,
  clickOnChangeLocation,
  enterNewLocationZipCode,
  clickOnItemsDisplayedWithTypeheadSearch,
  scrollDownToLoadNextPageData,
} from '../../interactions/rx.actions';

const validateSearchResult = ('Verify search result',
() => {
  const getItemCount = PharmacySearchScreen.pharmacyResultsHeader;

  const getCount = getItemCount.getText().split(' ')[0];

  return parseInt(getCount, 10) > 0;
});

const validatePaginationForPharmacySearch = () => {
  // Collect all the pharmacy data loaded at a time
  const pharmacyCountBeforeScroll = PharmacySearchScreen.getPharmacyList()
    .length;

  // Scroll down until we find the last item in current page
  scrollDownToLoadNextPageData(Math.floor(pharmacyCountBeforeScroll / 2));

  // Get item count after performing scroll down operation
  const pharmacyListAfterScroll = PharmacySearchScreen.getPharmacyList().length;

  // Item count after scroll should be greater than total item loaded before scroll
  return pharmacyListAfterScroll > pharmacyCountBeforeScroll;
};

describe('Pharmacy Locator', () => {
  beforeAll(() => {
    driver.reset();
    signIn(environment, username, password, true);
  });

  beforeEach(() => {
    navigateToPharmacyLocatorPage();
  });

  describe('Location', () => {
    it('will navigate and validate the results page by Location', () => {
      selectPharmacySearchType('Location', 'location');

      expect(validateSearchResult()).toBe(true);

      expect(validatePaginationForPharmacySearch()).toBe(true);
    });
  });

  describe('Pharmacy Name', () => {
    it('will navigate and validate the results page by Pharmacy Name', () => {
      selectPharmacySearchType('Pharmacy Name', 'pharmacyName');

      inputPharmacySearchData('pharmacy name', 'cvs');

      selectAllPharmacySearchResults('cvs');

      expect(validateSearchResult()).toBe(true);

      expect(validatePaginationForPharmacySearch()).toBe(true);
    });
  });

  describe('NPI', () => {
    it('will navigate and validate the results page by NPI', () => {
      selectPharmacySearchType('National Provider Identifier', 'npi');

      inputPharmacySearchData('national provider identifier', npi);

      selectAllPharmacySearchResults(npi);

      expect(validateSearchResult()).toBe(true);
    });
  });

  describe('State License', () => {
    it('will navigate and validate the results page by State License', () => {
      selectPharmacySearchType('State License Number', 'stateLicense');

      inputPharmacySearchData('state license number', stateLicense);

      selectAllPharmacySearchResults(stateLicense);

      expect(validateSearchResult()).toBe(true);
    });
  });

  describe('Change Location', () => {
    it('will validate pharmacy search with invalid location change', () => {
      const defaultSetLocation = 'chicago';
      const newZipCode = '60606';

      // Perform pharmacy search with default set location
      selectPharmacySearchType('Location', 'location');

      // Verify Pharmacy data should be displayed
      expect(validateSearchResult()).toBe(true);

      // change the default set location
      clickOnChangeLocation(defaultSetLocation);

      // Enter text in search box instead of zip code
      enterNewLocationZipCode('ABC');

      // Set new zip code (60601 -> 60606) and perform search
      enterNewLocationZipCode(newZipCode);
      clickOnItemsDisplayedWithTypeheadSearch(newZipCode);

      // Validate pharmacy data should be displayed for new location
      expect(validateSearchResult()).toBe(true);
    });
  });
});
