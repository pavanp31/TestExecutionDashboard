import { signIn } from '../../interactions/signIn.actions';
import {
  environment,
  username,
  password,
  primaryMember,
  authorizedMember,
} from '../rxConstants';
import { SUPER_LONG_WAIT } from '../../constants';
import RxMedCab from '../screenobjects/rxMedCab.screen';

import {
  navigateToCurrentMedicationsPage,
  changeMedicineCabinetMember,
  navigateToDrugPricingPageFromMedCab,
} from '../interactions/rx.actions';

const validateMemberOnPricingPage = member => {
  const currentMember = RxMedCab.showPricesForMemberButton(member);

  return currentMember.waitForEnabled(SUPER_LONG_WAIT);
};

describe('Medicine Cabinet', () => {
  beforeAll(() => {
    driver.reset();
    signIn(environment, username, password, true);
  });

  beforeEach(() => {
    navigateToCurrentMedicationsPage();
  });

  describe('Change Member type', () => {
    it('will validate non-current member medication cabinet data persistence', () => {
      changeMedicineCabinetMember(primaryMember, authorizedMember);

      navigateToDrugPricingPageFromMedCab(authorizedMember);

      expect(validateMemberOnPricingPage(authorizedMember)).toBe(true);
    });
  });
});
