// @flow
module.exports = {
  get Item() {
    return 'item';
  },
  get price() {
    return 'prices';
  },
};
