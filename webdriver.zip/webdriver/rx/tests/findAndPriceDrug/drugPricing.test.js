import { signIn } from '../../../interactions/signIn.actions';
import { ScrollDirection } from '../../../constants';
import { environment, username, password } from '../../rxConstants';
import {
  navigateToDrugPricingPage,
  refineSearchResultsBySortType,
  refineSearchResultsByUpdatingMedicationDetails,
  clickMoreOrLessButton,
} from '../../interactions/rx.actions';
import TouchActions from '../../../interactions/touch.actions';
import DrugPricingScreen from '../../screenobjects/drugPricing.screen';
import DrugWizardScreen from '../../screenobjects/drugWizard.screen';
import elements from "../SampleProp";

const validateFilteredBySortOption = (sortBy = 'price', lowToHigh = true) => {
  const retailOptionElement =
    sortBy === 'price'
      ? DrugPricingScreen.retailOptionPrice
      : DrugPricingScreen.distanceLink;

  TouchActions.scrollToElement(
    retailOptionElement(1),
    ScrollDirection.DOWN,
    10,
  );

  const getRetailOptionValue = (index, splitIndex = 0) =>
    sortBy === 'price'
      ? retailOptionElement(index)
          .getText()
          .split('$')[1]
      : retailOptionElement(index)
          .getText()
          .split(' ')[splitIndex];

  const firstRetailOptionValue = driver.isAndroid
    ? getRetailOptionValue(1)
    : getRetailOptionValue(1, 1);

  TouchActions.scrollToElement(
    retailOptionElement(4),
    ScrollDirection.DOWN,
    10,
  );
  const lastRetailOptionValue = driver.isAndroid
    ? getRetailOptionValue(4)
    : getRetailOptionValue(4, 1);

  return lowToHigh
    ? parseInt(firstRetailOptionValue, 10) <=
        parseInt(lastRetailOptionValue, 10)
    : parseInt(firstRetailOptionValue, 10) >=
        parseInt(lastRetailOptionValue, 10);
};

const waitForDrugWizardSettingsOnPricingPage = () => {
  clickMoreOrLessButton();

  const formSetting = DrugWizardScreen.drugInfoDisplayedOnPricingPage('Tablet');

  const strengthSetting = DrugWizardScreen.drugInfoDisplayedOnPricingPage(
    '875 MG',
  );

  return formSetting.waitForEnabled() && strengthSetting.waitForEnabled();
};

describe('Drug Pricing - Refine Search', () => {
  beforeAll(() => {
    driver.reset();
    signIn(environment, username, password, true);

    navigateToDrugPricingPage();
  });

  describe('Sort by filters', () => {
    it('will validate default price filter from low to high', () => {
      expect(validateFilteredBySortOption('price', true)).toBe(true);
       
    });

    it('will validate price filter from high to low', () => {
      refineSearchResultsBySortType('Price: High to Low');
      expect(validateFilteredBySortOption('price', false)).toBe(true);
    });

    it('will validate distance filter from nearest to furthest', () => {
      refineSearchResultsBySortType('Distance');
      expect(validateFilteredBySortOption('distance', true)).toBe(true);
    });
  });

  describe('Medication Details', () => {
    beforeEach(() => {
      TouchActions.scrollToTop();
    });

    it('will validate updated medication details for form and strngth', () => {
      refineSearchResultsByUpdatingMedicationDetails('Tablet', '875 MG');
      expect(waitForDrugWizardSettingsOnPricingPage()).toBe(true);
    });
  });
});
