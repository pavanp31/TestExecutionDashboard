import { signIn } from '../../../interactions/signIn.actions';
import {
  environment,
  username,
  password,
  primaryMember,
  authorizedMember,
  partialAmoxicillinDrugName,
  fullAmoxicillinDrugName,
  fullAmoxicillinDrugNameWithType,
} from '../../rxConstants';
import DrugSearchScreen from '../../screenobjects/drugSearch.screen';
import DrugWizardScreen from '../../screenobjects/drugWizard.screen';
import RxUtilsScreen from '../../screenobjects/rxUtils.screen';
import { changeCurrentLocation } from '../../interactions/rxUtils.actions';
import {
  navigateToDrugSearchPage,
  inputDrugSearchData,
  selectTopSuggestionDrugByName,
  changeCurrentMember,
  selectDrugWizardFormAndStrengthThenCalculate,
  clickMoreOrLessButtonWithAlertPresent,
  selectDrugTotalQuantity,
  selectDrugDaysSupply,
} from '../../interactions/rx.actions';

const waitForLocationChangeOnWizardPage = () => {
  const location = changeCurrentLocation();
  const currentLocation = location === '94107' ? 'San Francisco' : 'Chicago';

  DrugWizardScreen.drugWizardPageHeader.waitForDisplayed();

  return RxUtilsScreen.locationLink.getText().includes(currentLocation);
};

const waitForDrugWizardSettingsOnPricingPage = () => {
  clickMoreOrLessButtonWithAlertPresent();

  const formSetting = DrugWizardScreen.drugInfoDisplayedOnPricingPage('Tablet');

  const strengthSetting = DrugWizardScreen.drugInfoDisplayedOnPricingPage(
    '500 MG',
  );

  return formSetting.waitForEnabled() && strengthSetting.waitForEnabled();
};

const waitForCustomValueError = customValueType =>
  DrugWizardScreen.customValueError(customValueType).waitForDisplayed();

const waitForNoCustomValueError = customValueType =>
  DrugWizardScreen.customValueError(customValueType).isExisting();

describe('Drug Wizard', () => {
  beforeAll(() => {
    driver.reset();
    signIn(environment, username, password, true);

    navigateToDrugSearchPage();

    inputDrugSearchData(partialAmoxicillinDrugName);

    selectTopSuggestionDrugByName(fullAmoxicillinDrugName);

    DrugSearchScreen.drugNameInWizardSettingsHeader(
      fullAmoxicillinDrugNameWithType,
    );
  });

  describe('Change Location', () => {
    it('will validate location change', () => {
      expect(waitForLocationChangeOnWizardPage()).toBe(true);
    });
  });

  describe('Change user', () => {
    it('will validate changing user type', () => {
      changeCurrentMember({
        from: primaryMember,
        to: authorizedMember,
      });
      expect(
        DrugWizardScreen.memberSelectionLink(
          authorizedMember,
        ).waitForDisplayed(),
      ).toBe(true);
    });
  });

  describe('calculate cost and info', () => {
    it('will validate form and strength values on pricing page after setting in drug wizard', () => {
      selectDrugWizardFormAndStrengthThenCalculate('Tablet', '500 MG');
      expect(waitForDrugWizardSettingsOnPricingPage()).toBe(true);
    });
  });

  describe('calculate custom values', () => {
    beforeAll(() => {
      navigateToDrugSearchPage();

      inputDrugSearchData(partialAmoxicillinDrugName);

      selectTopSuggestionDrugByName(fullAmoxicillinDrugName);

      DrugSearchScreen.drugNameInWizardSettingsHeader(
        fullAmoxicillinDrugNameWithType,
      );
    });

    it('will validate error after setting incorrect custom values', () => {
      selectDrugTotalQuantity('Enter a Custom Quantity', '10000');

      expect(waitForCustomValueError('Total Quantity')).toBe(true);

      selectDrugDaysSupply('Enter a Custom Day Supply', '0');

      expect(waitForCustomValueError('Days Supply')).toBe(true);
    });

    it('will validate error display is removed after setting valid custom values', () => {
      selectDrugTotalQuantity('Enter a Custom Quantity', '50');

      expect(waitForNoCustomValueError('Total Quantity')).toBe(false);

      selectDrugDaysSupply('Enter a Custom Day Supply', '30');

      expect(waitForNoCustomValueError('Days Supply')).toBe(false);
    });
  });
});
