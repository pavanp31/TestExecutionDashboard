import { signIn } from '../../../interactions/signIn.actions';
import {
  environment,
  username,
  password,
  partialAmoxicillinDrugName,
  fullAmoxicillinDrugName,
  fullAmoxicillinDrugNameWithType,
  partialCarisoprodolDrugName,
  fullCarimuneDrugNameWithType,
  fullClariSprayDrugNameWithType,
} from '../../rxConstants';
import DrugSearchScreen from '../../screenobjects/drugSearch.screen';
import {
  navigateToDrugSearchPage,
  inputDrugSearchData,
  selectTopSuggestionDrugByName,
  selectShowAllResultsForByInputTextLink,
  selectBrandDrugFromAllResultsList,
} from '../../interactions/rx.actions';

const validateDrugOnWizardPage = drug => {
  const drugInPageHeader = DrugSearchScreen.drugNameInWizardPageHeader(drug);

  const drugInSettingHeader = DrugSearchScreen.drugNameInWizardSettingsHeader(
    drug,
  );

  return (
    drugInPageHeader.waitForEnabled() && drugInSettingHeader.waitForEnabled()
  );
};

const validateSearchResult = text => {
  const getSearchText = DrugSearchScreen.textInAllResultsListHeader(text);

  getSearchText.waitForDisplayed();

  const getItemCount = DrugSearchScreen.drugResultsHeader;

  const getCount = getItemCount.getText().split(' ')[0];

  return parseInt(getCount, 10) > 0;
};

describe('Drug Search', () => {
  beforeAll(() => {
    driver.reset();
    signIn(environment, username, password, true);
  });

  beforeEach(() => {
    navigateToDrugSearchPage();
  });

  describe('Top Suggestions', () => {
    it('will validate top suggestion selection', () => {
      inputDrugSearchData(partialAmoxicillinDrugName);

      selectTopSuggestionDrugByName(fullAmoxicillinDrugName);

      expect(validateDrugOnWizardPage(fullAmoxicillinDrugNameWithType)).toBe(
        true,
      );
    });
  });

  describe('Show All Results For', () => {
    beforeEach(() => {
      inputDrugSearchData(partialCarisoprodolDrugName);

      selectShowAllResultsForByInputTextLink(partialCarisoprodolDrugName);
    });

    it('will validate Brand drug selection from all matching result list', () => {
      expect(validateSearchResult(partialCarisoprodolDrugName)).toBe(true);

      selectBrandDrugFromAllResultsList(fullCarimuneDrugNameWithType);

      expect(validateDrugOnWizardPage(fullCarimuneDrugNameWithType)).toBe(true);
    });

    it('will validate Branded generic drug selection from all matching result list', () => {
      expect(validateSearchResult(partialCarisoprodolDrugName)).toBe(true);

      selectBrandDrugFromAllResultsList(fullClariSprayDrugNameWithType);

      expect(validateDrugOnWizardPage(fullClariSprayDrugNameWithType)).toBe(
        true,
      );
    });
  });
});
