// @flow

import AppScreen from '../../screenobjects/app.screen';

class DrugPricingScreen extends AppScreen {
  get refineResultsButton() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.widget.Button").description("Refine Results")',
        )
      : $('~RefinePricingSearchAndSort');
  }

  get refineSearchHeader() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").text("Refine Search")',
        )
      : $('(//XCUIElementTypeOther[@name="Refine Search"])[3]');
  }

  get applyButton() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.widget.Button").description("Apply")',
        )
      : $('~filter-modal-filter-apply');
  }

  get medicationInfoAndPricingHeader() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").description("Medication Info & Pricing")',
        )
      : $('(//XCUIElementTypeOther[@name="Medication Info & Pricing"])[2]');
  }

  get formDropdown() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().descriptionContains("dropdown list for Form").childSelector(new UiSelector().className("android.widget.Button"))',
        )
      : $(
          '(//XCUIElementTypeButton[@name[contains(.,"dropdown list for Form")]])[last()]',
        );
  }

  get strengthDropdown() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().descriptionContains("dropdown list for Strength").childSelector(new UiSelector().className("android.widget.Button"))',
        )
      : $(
          '(//XCUIElementTypeButton[@name[contains(.,"dropdown list for Strength")]])[last()]',
        );
  }

  get moreOrLessButton() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.Button").text("More")`,
        )
      : $('~moreOrLessButton');
  }

  distanceLink(instance: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.ViewGroup").index(${instance}).childSelector(new UiSelector().textContains("miles away"))`,
        )
      : $(
          `(//XCUIElementTypeLink[@name[contains(.,"miles away")]])[${instance}]`,
        );
  }

  retailOptionPrice(instance: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.ViewGroup").index(${instance}).childSelector(new UiSelector().textContains("You Pay"))`,
        )
      : $(
          `(//XCUIElementTypeScrollView)[last()]/XCUIElementTypeOther[@name[contains(.,"Retail Option")]]/XCUIElementTypeOther[@name[contains(.,"Retail Option")]][${instance}]/XCUIElementTypeOther[@name[contains(.,"Retail Option")]]/XCUIElementTypeOther[@name[contains(.,"You Pay")]]`,
        );
  }

  sortByRadioButton(sortType: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.RadioButton").descriptionContains("${sortType}")`,
        )
      : $(`~${sortType}`);
  }
}

export default new DrugPricingScreen();
