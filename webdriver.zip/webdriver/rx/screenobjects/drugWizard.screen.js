// @flow

import AppScreen from '../../screenobjects/app.screen';

class DrugWizardScreen extends AppScreen {
  get drugWizardPageHeader() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").textContains("Calculate costs and view information")',
        )
      : $(
          '(//XCUIElementTypeOther[@name[contains(.,"Calculate costs and view information")]])[last()]',
        );
  }

  get pickerWheel() {
    return $(
      '//XCUIElementTypePicker[@name="picker"]/XCUIElementTypePickerWheel',
    );
  }

  get doneButton() {
    return $('~doneButton');
  }

  get formDropdown() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().descriptionContains("dropdown list for Form").childSelector(new UiSelector().className("android.widget.Button"))',
        )
      : $(
          '(//XCUIElementTypeButton[@name[contains(.,"dropdown list for Form")]])[last()]',
        );
  }

  get strengthDropdown() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().descriptionContains("dropdown list for Strength").childSelector(new UiSelector().className("android.widget.Button"))',
        )
      : $(
          '(//XCUIElementTypeButton[@name[contains(.,"dropdown list for Strength")]])[last()]',
        );
  }

  get totalQuantityDropdown() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().descriptionContains("dropdown list for Total Quantity").childSelector(new UiSelector().className("android.widget.Button"))',
        )
      : $(
          '(//XCUIElementTypeButton[@name[contains(.,"dropdown list for Total Quantity")]])[last()]',
        );
  }

  get daysSupplyDropdown() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().descriptionContains("dropdown list for Days Supply").childSelector(new UiSelector().className("android.widget.Button"))',
        )
      : $(
          '(//XCUIElementTypeButton[@name[contains(.,"dropdown list for Days Supply")]])[last()]',
        );
  }

  get calculateCostButton() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.widget.Button").descriptionContains("Calculate Cost and View Info")',
        )
      : $('~CalculateButton');
  }

  get drugPricingPageHeader() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").text("Medication Info & Pricing")',
        )
      : $(
          '(//XCUIElementTypeOther[@name="Medication Info & Pricing"])[last()]',
        );
  }

  get moreOrLessButton() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.Button").text("More").instance(1)`,
        )
      : $('~moreOrLessButton');
  }

  get customQuantityHeader() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").text("Custom Total Quantity")',
        )
      : $('~Enter a quantity');
  }

  get customDaysHeader() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").text("Custom Day Supply")`,
        )
      : $('~Enter number of days');
  }

  get customValueOkButton() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.widget.Button").description("OK")',
        )
      : $('~OK');
  }

  get customInputField() {
    return $(
      'android=new UiSelector().className("android.widget.EditText").index(0)',
    );
  }

  memberSelectionLink(member: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("${member}")`,
        )
      : $(`~double tap to open picker, ${member}`);
  }

  modalSettingButton(value: string) {
    return $(
      `android=new UiSelector().className("android.widget.Button").description("${value}")`,
    );
  }

  customValueError(type: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.Button").descriptionContains("Error: Value between 1-9999 required.. dropdown list for ${type}")`,
        )
      : $(
          `(//XCUIElementTypeOther[@name[contains(.,"Error: Value between 1-9999 required.. dropdown list for ${type}")]])[last()]`,
        );
  }

  drugInfoDisplayedOnPricingPage(value: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").text("${value}")`,
        )
      : $(`(//XCUIElementTypeOther[@name="${value}"])[last()]`);
  }

  enterCustomValue(type: string, value: string) {
    if (type === 'quantity') {
      this.customQuantityHeader.waitForDisplayed();
    } else {
      this.customDaysHeader.waitForDisplayed();
    }

    if (driver.isAndroid) {
      this.sendKeysToElement(value, this.customInputField);

      this.customValueOkButton.waitForEnabled();
      this.customValueOkButton.touchAction(['tap', 'tap']);
    } else {
      driver.sendKeys([...value]);

      this.customValueOkButton.waitForEnabled();
      this.customValueOkButton.click();
    }
  }

  selectDrugWizardValueFromSelector(
    value: string,
    clickSectionAbove: boolean = false,
  ) {
    if (driver.isAndroid) {
      this.modalSettingButton(value).waitForDisplayed();
      this.modalSettingButton(value).click();
    } else {
      this.pickerWheel.waitForEnabled();

      this.selectFromPickerWheel(value, this.pickerWheel, clickSectionAbove);

      this.doneButton.waitForEnabled();
      this.doneButton.click();
    }
  }
}

export default new DrugWizardScreen();
