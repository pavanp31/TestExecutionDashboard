// @flow

import AppScreen from '../../screenobjects/app.screen';

class DrugSearchScreen extends AppScreen {
  get _drugSearchTypehead() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.EditText").textContains("Search medications by name")`,
        )
      : $(
          '(//XCUIElementTypeOther[@name[contains(.,"Search medications by name")]])[last()]',
        );
  }

  get topSuggestionHeader() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").text("Top Suggestions")',
        )
      : $('~Top Suggestions');
  }

  get showAllResultsForHeader() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").text("Show All Results For")',
        )
      : $('~Show All Results For');
  }

  get drugResultsHeader() {
    const drugResultHeader = driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").textContains("Result")',
        )
      : $('(//XCUIElementTypeOther[@name[contains(.,"Result")]])[last()]');

    drugResultHeader.waitForEnabled(20000);

    return drugResultHeader;
  }

  inputDrugSearchData(text: string) {
    this._drugSearchTypehead.waitForEnabled();

    this._drugSearchTypehead.touchAction(['tap']);

    driver.sendKeys([...text]);
    driver.pause(250);

    driver.hideKeyboard();
  }

  selectDrugByName(name: string) {
    const drugName = driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("${name}")`,
        )
      : $(`//XCUIElementTypeLink[@label[contains(.,"${name}")]]`);

    drugName.waitForEnabled();

    drugName.click();
  }

  drugNameInWizardPageHeader(name: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("Calculate costs and view information for ${name}")`,
        )
      : $(
          `(//XCUIElementTypeOther[@name="Calculate costs and view information for ${name} near:"])[2]`,
        );
  }

  drugNameInWizardSettingsHeader(name: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").text("${name}")`,
        )
      : $(`~${name}`);
  }

  textInAllResultsListHeader(input: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("${input}")`,
        )
      : $(`~'${input}'`);
  }
}

export default new DrugSearchScreen();
