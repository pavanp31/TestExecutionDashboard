// @flow

import AppScreen from '../../screenobjects/app.screen';

class RxMedCabScreen extends AppScreen {
  _showMedicationsForFilter(currentMember: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").descriptionContains("Showing current medications for ${currentMember}")`,
        )
      : $(
          `~Showing current medications for ${currentMember}. Tap here to filter results.`,
        );
  }

  _selectMemberTypeRadioButton(member: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.RadioButton").description("${member}")`,
        )
      : $(`~${member}`);
  }

  _medicationCabinetListHeader(member: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("${member}")`,
        )
      : $(
          `(//XCUIElementTypeOther[@name[contains(.,"${member}'s Medications")]])`,
        );
  }

  get applyFiltersButton() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.Button").description("Apply")`,
        )
      : $('~filter-modal-filter-apply');
  }

  get getPricingLink() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").text("Get Pricing").instance(0)',
        )
      : $('(//XCUIElementTypeLink[@name="getPricing"])[1]');
  }

  get medicationAndPricingHeader() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").text("Medication Info & Pricing")',
        )
      : $('(//XCUIElementTypeOther[@name="Medication Info & Pricing"])[2]');
  }

  showPricesForMemberButton(member: string) {
    const iosValue = `${member}`.split(' ')[0];
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.Button").descriptionContains("${member}")`,
        )
      : $(
          `//XCUIElementTypeButton[@name="double tap to open picker, ${iosValue}"]`,
        );
  }

  selectMemberFromShowMedicationsForFilter(member: string, newMember: string) {
    const currentMember = this._showMedicationsForFilter(member);
    const selectMemberRadioButton = this._selectMemberTypeRadioButton(
      newMember,
    );

    currentMember.waitForEnabled();
    currentMember.click();

    selectMemberRadioButton.waitForEnabled();
    selectMemberRadioButton.click();
  }

  navigatesToMedCabAfterApplyingMemberFilter(member: string) {
    const currentMember = this._showMedicationsForFilter(member);
    const currentMemberHeader = this._medicationCabinetListHeader(member);

    currentMember.waitForDisplayed();

    currentMemberHeader.waitForDisplayed();
  }
}

export default new RxMedCabScreen();
