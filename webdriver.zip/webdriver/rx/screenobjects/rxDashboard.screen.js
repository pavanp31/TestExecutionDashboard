// @flow

import AppScreen from '../../screenobjects/app.screen';

class RxDashboardScreen extends AppScreen {
  get pharmacyLocatorLink() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.TextView").textContains("Pharmacy Locator")`,
        )
      : $(`~dashboard-link-1`);
  }

  get findAndPriceMedicationsLink() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.TextView").textContains("Find & Price a Medication")`,
        )
      : $(`~dashboard-link-0`);
  }

  get currentMedicationsButton() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.Button").description("Current Medications tab")`,
        )
      : $(`~Current Medications tab`);
  }
}

export default new RxDashboardScreen();
