// @flow

import AppScreen from '../../screenobjects/app.screen';
import { EXTRA_LONG_WAIT } from '../../constants';

// screenobjects for common rx components
class RxUtilsScreen extends AppScreen {
  get locationLink() {
    return driver.isAndroid
      ? $(
          'android=new UiSelector().className("android.view.View").index(1).childSelector(new UiSelector().className("android.view.View").index(1))',
        )
      : $('//XCUIElementTypeLink');
  }

  get locationSearchField() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().descriptionStartsWith("search").childSelector(new UiSelector().className("android.widget.EditText"))`,
        )
      : $(`~search-box`);
  }

  selectlocationLink() {
    this.locationLink.waitForDisplayed(EXTRA_LONG_WAIT);

    this.locationLink.click();
  }

  setLocation(location: string) {
    const updatedLocation = location.includes('Chicago') ? '94107' : '60601';

    this.locationSearchField.waitForEnabled();

    this.sendKeysToElement(`${updatedLocation}`, this.locationSearchField);

    driver.hideKeyboard();

    const locationResultLink = driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("${updatedLocation}")`,
        )
      : $(`(//XCUIElementTypeLink[@name[contains(.,"${updatedLocation}")]])`);

    locationResultLink.waitForDisplayed(EXTRA_LONG_WAIT);

    locationResultLink.click();

    return updatedLocation;
  }
}

export default new RxUtilsScreen();
