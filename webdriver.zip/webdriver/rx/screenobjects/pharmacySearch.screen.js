// @flow

import AppScreen from '../../screenobjects/app.screen';

class PharmacySearchScreen extends AppScreen {
  _allPharmacyResultsLink(input: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").text("${input}")`,
        )
      : $('~show-all-results-for');
  }

  _pharmacySearchInput(input: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.EditText").textContains("Search by ${input.toLowerCase()}")`,
        )
      : $('(//XCUIElementTypeOther[@name[contains(.,"Search by")]])[last()]');
  }

  _changeLocation(input: string) {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("${input.toLowerCase()}")`,
        )
      : $('~location-header');
  }

  _locationEditTextBox() {
    const locationEditTextBox = driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.EditText")`)
      : $('-ios predicate string: name CONTAINS "search-box"');

    locationEditTextBox.waitForEnabled();
    return locationEditTextBox;
  }

  get pharmacyResultsHeader() {
    const pharmacyResultHeader = driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("Result")`,
        )
      : $(`~number-of-results-text`);

    pharmacyResultHeader.waitForEnabled(20000);

    return pharmacyResultHeader;
  }

  selectPharmacySearchType(androidValue: string, iosValue: string) {
    const searchType = driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").text("${androidValue}")`,
        )
      : $(`~pharmacy-search-${iosValue}`);

    searchType.waitForEnabled();

    searchType.click();
  }

  selectAllPharmacySearchResults(input: string) {
    const pharmacyResultsLink = this._allPharmacyResultsLink(input);

    pharmacyResultsLink.waitForEnabled();

    pharmacyResultsLink.click();

    if (driver.isAndroid) {
      pharmacyResultsLink.click();
    }
  }

  inputPharmacySearchData(type: string, data: string) {
    const pharmacySearchTypehead = this._pharmacySearchInput(type);

    pharmacySearchTypehead.waitForEnabled();

    pharmacySearchTypehead.touchAction(['tap']);

    this.sendKeysToElement(data, pharmacySearchTypehead);

    driver.hideKeyboard();
  }

  clickOnChangeLocation(query: string) {
    const changeLocation = this._changeLocation(query);

    changeLocation.waitForEnabled();

    changeLocation.click();
  }

  enterNewLocationZipCode(input: string) {
    let locationText = this._locationEditTextBox();

    locationText.clearValue();

    locationText.touchAction(['tap']);

    locationText = this._locationEditTextBox();
    this.sendKeysToElement(input, locationText);

    driver.hideKeyboard();
  }

  getSearchResultListWithTypehead(text: string) {
    const searchResultListItem = driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").textContains("${text}")`,
        )
      : $(`//XCUIElementTypeLink[@name[contains(.,'${text}')]]`);

    searchResultListItem.waitForEnabled(1000);

    return searchResultListItem;
  }

  getPharmacyList() {
    const pharmacyList = driver.isAndroid
      ? $$(
          '//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup',
        )
      : $$(
          '//XCUIElementTypeOther[@name="Pharmacies"]/following-sibling::XCUIElementTypeOther//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther',
        );
    return pharmacyList;
  }
}

export default new PharmacySearchScreen();
