// // @flow

// const { config } = require('./wdio.shared.conf');

// // ============
// // Specs
// // ============
// config.specs = ['./tests/**/*.test.js'];

// // ============
// // Capabilities
// // ============
// // For all capabilities please check
// // http://appium.io/docs/en/writing-running-appium/caps/#general-capabilities
// config.capabilities = [
//   {
//     platformName: 'iOS',
//     maxInstances: 1,
//     'appium:deviceName': 'iPhone 11',
//     'appium:platformVersion': '13.3',
//     'appium:automationName': 'XCUITest',
//     'appium:bundleId': 'com.uhg.arcade.debug',
//     'appium:noReset': false,
//     'appium:locationServicesAuthorized': true,
//     'appium:newCommandTimeout': 240,
//     'appium:autoAcceptAlerts': false,
//   },
// ];

// exports.config = config;
// @flow

const merge = require('deepmerge');
const { config } = require('./wdio.shared.conf');

// ============
// Specs
// ============
config.specs = ['./tests/**/*.test.js'];

// ============
// Appium Capabilities
// ============
// For all capabilities please check
// http://appium.io/docs/en/writing-running-appium/caps/#general-capabilities
config.capabilities = [
  {
    // deviceName: 'Android Emulator',
    // platformName: 'Android',
    // platformVersion: '8.0',
    // app: 'sauce-storage:app-release.apk',
    // appiumVersion: '1.16.0',
    // maxInstances: 1,
    // 'appium:automationName': 'UiAutomator2',
    // 'appium:appActivity': 'com.mobile.uhc.SplashActivity',
    // 'appium:appWaitActivity': 'com.mobile.uhc.MainActivity',
    // 'appium:noReset': false,
    // 'appium:autoGrantPermissions': true,
    // 'appium:newCommandTimeout': 240,
    // deviceName: 'iPhone',
    // udid: '9baae427cc83233291d6f442c531abb5890f7d06',
    // platformName: 'iOS',
    // automationName: 'XCUITest',
    // useSimpleBuildTest: true,
    // platformVersion: '11.2',
    // bundleId: 'com.apple.Preferences'

    deviceName: 'iPhone',
    udid: '9baae427cc83233291d6f442c531abb5890f7d06',
    platformName: 'iOS',
    automationName: 'XCUITest',
    useSimpleBuildTest: true,
    platformVersion: '11.2',
    bundleId: 'com.apple.Preferences',
  },
];

// ============
// Headspin Config https://webdriver.io/docs/appium-service.html
// ============
config.services = [
  ['appium'],
  // {
  //   deviceName: 'iPhone',
  //   udid: '9baae427cc83233291d6f442c531abb5890f7d06',
  //   platformName: 'iOS',
  //   automationName: 'XCUITest',
  //   useSimpleBuildTest: true,
  //   platformVersion: '11.2',
  //   bundleId: 'com.apple.Preferences',
  // },
];
 //config.baseUrl =
//   // 'https://us-nyc.headspin.io:7004/v0/eeb2f2de21cb4061be3a0b7c2fdbfeaf/wd/hub';
  // 'https://us-nyc.headspin.io:7004/v0/eeb2f2de21cb4061be3a0b7c2fdbfeaf/wd/hub';

// Change local port to Sauce port
//delete config.port;

// Sauce Credentials
exports.config = //config;
merge(config, {
  // These should be defined locally in .zshrc or .bashrc, or exported to PATH
  user: 'pavan.patel',
  key: 'eeb2f2de21cb4061be3a0b7c2fdbfeaf',
});
