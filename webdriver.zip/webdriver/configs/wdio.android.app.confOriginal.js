// @flow

// eslint-disable-next-line import/no-nodejs-modules
const { config } = require('./wdio.shared.conf');

// ============
// Specs
// ============
config.specs = ['./tests/**/*.test.js'];

// ============
// Capabilities
// ============
// For all capabilities please check
// http://appium.io/docs/en/writing-running-appium/caps/#general-capabilities
config.capabilities = [
  {
    platformName: 'Android',
    maxInstances: 1,
    'appium:deviceName': 'Android Emulator',
    'appium:automationName': 'UiAutomator2',
    'appium:appActivity': 'com.mobile.uhc.SplashActivity',
    'appium:appWaitActivity': 'com.mobile.uhc.MainActivity',
    'appium:appPackage': 'com.mobile.uhc.debug',
    'appium:noReset': false,
    'appium:autoGrantPermissions': true,
    'appium:newCommandTimeout': 240,
  },
];

exports.config = config;
