// @flow

import AppScreen from './app.screen';

class AccountBalancesScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Account Balances');
  }
}

export default new AccountBalancesScreen();
