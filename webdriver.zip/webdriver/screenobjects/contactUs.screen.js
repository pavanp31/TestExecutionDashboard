// @flow

import AppScreen from './app.screen';

class ContactUsScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Contact Us');
  }
}

export default new ContactUsScreen();
