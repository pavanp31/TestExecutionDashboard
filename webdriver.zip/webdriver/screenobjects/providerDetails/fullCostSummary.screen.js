// @flow

import AppScreen from '../app.screen';

class FullCostSummaryScreen extends AppScreen {
  get header() {
    return super._screenHeader('Full Cost Summary');
  }
}

export default new FullCostSummaryScreen();
