// @flow

import AppScreen from '../app.screen';

class ServiceDetailsScreen extends AppScreen {
  get header() {
    return super._screenHeader('Service Details');
  }

  get viewFullEstimateButton() {
    return $(`~View Full Estimate`);
  }
}

export default new ServiceDetailsScreen();
