// @flow

import AppScreen from '../app.screen';

class ExplanationOfCostsModalScreen extends AppScreen {
  get header() {
    return $(`~Explanation of Costs`);
  }

  get averageCost() {
    return this.sectionHeading(`Average Cost`);
  }

  get estimatedTotalCost() {
    return this.sectionHeading(`Estimated Total Cost`);
  }

  get insurancePays() {
    return this.sectionHeading(`Insurance Pays`);
  }

  get estimatedOutOfPocketCost() {
    return this.sectionHeading(`Estimated Out-of-Pocket Cost`);
  }

  get amountAppliedToDeductible() {
    return this.sectionHeading(`Amount Applied to Deductible`);
  }

  get copay() {
    return this.sectionHeading(`Copay`);
  }

  get coinsurance() {
    return this.sectionHeading(`Coinsurance`);
  }

  sectionHeading(text: string) {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("${text}")`)
      : $(`-ios predicate string: name == '${text}' || label == '${text}'`);
  }
}

export default new ExplanationOfCostsModalScreen();
