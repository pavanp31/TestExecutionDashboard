// @flow

import AppScreen from '../app.screen';

class MedicalGroupDetailsScreen extends AppScreen {
  get header() {
    return $(`~Medical Group Details`);
  }
}

export default new MedicalGroupDetailsScreen();
