// @flow

import AppScreen from '../app.screen';

class IncorrectInformationModalScreen extends AppScreen {
  get header() {
    return $(`~Report Incorrect Information`);
  }

  get nameCheckbox() {
    return $(`~Name`);
  }

  get sendButton() {
    return $(`~Send`);
  }

  get successModal() {
    return driver.isAndroid ? super.getElementByText('Thanks for sending!') : $(`~Thanks for sending!`);
  }
}

export default new IncorrectInformationModalScreen();
