// @flow

import { DoctorDetailsScreenClass } from './doctorDetails.screen';

class LocationsTabScreen extends DoctorDetailsScreenClass {
  get locationHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textMatches("Location \\d of \\d+")`)
      : $(`-ios predicate string: name MATCHES "Location \\\\d of \\\\d+"`);
  }

  get addressLink() {
    return $(`~address.link`);
  }

  get medicalGroupsHeader() {
    return $(`~Medical Groups`);
  }

  get acceptingPatientsLink() {
    return $(`~acceptingPatients.link`);
  }

  get acceptingPatientsModalContent() {
    return this.elementBySubstring(`We recommend you contact the doctor`);
  }
}

export default new LocationsTabScreen();
