// @flow

import AppScreen from '../../app.screen';

export class DoctorDetailsScreenClass extends AppScreen {
  get providerName() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Igor Kletsman MD")`) : $(`~provider-title`);
  }

  get specialties() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").text("Osteopathic Manipulative Medicine, Internal Medicine")`,
        )
      : $(`~provider-title-specialties`);
  }

  get reviews() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains(" Reviews")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label ENDSWITH 'Reviews'`);
  }

  get incorrectInformationLink() {
    return driver.isAndroid ? super.getElementByText('Send Feedback') : $(`~Send Feedback`);
  }

  get servicesAndCostsTab() {
    return $(`~Services & Costs tab`);
  }

  get locationsTab() {
    return $(`~Locations tab`);
  }

  elementBySubstring(substring: string) {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("${substring}")`)
      : $(`-ios predicate string: name CONTAINS '${substring}' || label CONTAINS '${substring}'`);
  }
}

export default new DoctorDetailsScreenClass();
