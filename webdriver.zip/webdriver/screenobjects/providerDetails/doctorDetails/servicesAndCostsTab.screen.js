// @flow

import { DoctorDetailsScreenClass } from './doctorDetails.screen';

class ServicesAndCostsTabScreen extends DoctorDetailsScreenClass {
  get servicesSearchBox() {
    return $(`~search-box`);
  }

  get servicesSearchBoxPlaceholderText() {
    return $(`~search`);
  }

  get explanationOfCosts() {
    return $(`~services.explanationLink`);
  }

  get serviceDetailLink() {
    return $(`~serviceDetailLink`);
  }

  get matchingServicesText() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textMatches("\\d+ Matching Services")`)
      : $(`-ios predicate string: name ENDSWITH "Matching Services"`);
    // : $(`-ios predicate string: name MATCHES "\\\\d+ Matching Services"`);
  }
  get noMatchingServicesText() {
    return driver.isAndroid
      ? $(`~No Matching Services`)
      : $(`-ios predicate string: name ENDSWITH "No Matching Services"`);
  }
}

export default new ServicesAndCostsTabScreen();
