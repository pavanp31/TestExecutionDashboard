// @flow

import { DoctorDetailsScreenClass } from './doctorDetails.screen';

class OverviewTabScreen extends DoctorDetailsScreenClass {
  get addressLink() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.view.View").descriptionContains("press longer to copy the address to the clipboard")`,
        )
      : $(`~address.link`);
  }

  get phoneLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").descriptionStartsWith("phone number:")`)
      : $(`~phone.link`);
  }

  get phoneDialer() {
    return driver.isAndroid
      ? $(`android=new UiSelector().resourceIdMatches("com(\.google)?\.android\.dialer:id/digits")`) // eslint-disable-line no-useless-escape
      : $(
          `-ios predicate string: type == "XCUIElementTypeStaticText" AND label CONTAINS "We were unable to initiate a phone call for you"`,
        );
  }

  get acceptingPatientsLink() {
    return $(`~acceptingPatients.link`);
  }

  get acceptingPatientsModalContent() {
    return this.elementBySubstring(`We recommend you contact the doctor`);
  }

  get accessibilityOptions() {
    return driver.isAndroid
      ? $(`~Accessibility`)
      : $(`-ios predicate string: type == "XCUIElementTypeOther" AND label == "Accessibility"`);
  }

  get accessibilityOptionLink() {
    return $(`~Exterior Building`);
  }

  get accessibilityOptionModalContent() {
    return this.elementBySubstring(`An accessible exterior building has a clear path to enter and exit the building`);
  }

  get providerDataInformationLink() {
    return $(`~providerDataInfo.link`);
  }

  get providerDataInformationModal() {
    return $(`~Provider Data Information close`);
  }

  get providerGroupSection() {
    return $(`~Provider Group`);
  }

  get providerGroupLink() {
    return $(`~UPPER EAST SIDE MEDICAL`);
  }

  get specialtiesSection() {
    return $(`~Specialties`);
  }

  get specialtiesLink() {
    return $(`~Osteopathic Manipulative Medicine`);
  }

  get specialtiesModal() {
    return this.elementBySubstring('A system of medical practice based on a theory');
  }
}

export default new OverviewTabScreen();
