// @flow

import AppScreen from './app.screen';

class HealthChecklistScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Health Checklist');
  }
}

export default new HealthChecklistScreen();
