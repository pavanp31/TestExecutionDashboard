// @flow

import AppScreen from './app.screen';

class PlanDocumentsScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Plan Documents');
  }
}

export default new PlanDocumentsScreen();
