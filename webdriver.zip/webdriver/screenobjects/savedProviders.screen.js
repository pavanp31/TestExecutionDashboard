// @flow

import AppScreen from './app.screen';
import TouchActions from '../interactions/touch.actions';

class SavedProvidersScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Saved');
  }

  // Android shows the menu button on this screen
  // while iOS shows the back button
  goBack() {
    return driver.isAndroid ? TouchActions.hardwareBack() : this.backButton.click();
  }
}

export default new SavedProvidersScreen();
