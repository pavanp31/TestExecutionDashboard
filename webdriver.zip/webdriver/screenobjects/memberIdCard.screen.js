// @flow

import AppScreen from './app.screen';

class MemberIdCardScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('ID Card');
  }

  get sendIdCardModalHeader() {
    return super._screenHeader('Send ID Card');
  }

  get sendIdCardModalNoThanksButton() {
    return driver.isAndroid ? super.getElementByText('NO, THANKS. TAKE ME BACK.') : $(`~No, thanks. Take me back.`);
  }
}

export default new MemberIdCardScreen();
