// @flow

import AppScreen from '../app.screen';

class VirtualVisitsWelcomeScreen extends AppScreen {
  get retryButton() {
    return this.getElementByText('Retry');
  }

  get getStartedButton() {
    return $(`~Get Started`);
  }

  get viewAllProvidersButton() {
    return $(`~View All Providers`);
  }
}

export default new VirtualVisitsWelcomeScreen();
