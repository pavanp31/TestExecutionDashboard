// @flow

import AppScreen from './app.screen';
import TouchActions from '../interactions/touch.actions';
import { SHORT_WAIT } from '../constants';

class NavDrawerScreen extends AppScreen {
  get dashboardLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Dashboard")`) : $(`~Dashboard`);
  }

  get urgentCareLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Find Urgent Care")`) : $(`~Find Urgent Care`);
  }

  get medicalCareLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Find Medical Care")`) : $(`~Find Medical Care`);
  }

  get mentalHealthCareLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("Find Mental Health Care")`)
      : $(`~Find Mental Health Care`);
  }
  get pharmaciesAndPrescriptionsLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("Pharmacies & Prescriptions")`)
      : $(`~Pharmacies & Prescriptions`);
  }
  get manageClaimsLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Manage and Pay Claims")`) : $(`~Manage and Pay Claims`);
  }

  get healthRecordLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Health Record")`) : $(`~Health Record`);
  }

  get savedLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Saved")`) : $(`~Saved`);
  }

  get accountBalancesLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Account Balances")`) : $(`~Account Balances`);
  }

  get healthChecklistLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Health Checklist")`) : $(`~Health Checklist`);
  }

  get contactUsLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Contact Us")`) : $(`~Contact Us`);
  }

  get planDocumentsLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Plan Documents")`) : $(`~Plan Documents`);
  }

  get settingsLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Settings")`) : $(`~Settings`);
  }

  get closeNavDrawer() {
    return $(`~close`);
  }

  openNavDrawer() {
    if (driver.isAndroid) {
      this.menuButton.waitForEnabled();
      this.menuButton.click();
    } else {
      // a workaround for the inaccessible menu button on some iOS screens
      try {
        this.menuButton.waitForEnabled(SHORT_WAIT);
        this.menuButton.click();
      } catch (error) {
        TouchActions.clickLowerRight(this.actionBar);
      }
    }
    this.dashboardLink.waitForDisplayed();
  }
}

export default new NavDrawerScreen();
