// @flow

import AppScreen from './app.screen';
import { EXTRA_LONG_WAIT } from '../constants';

class SetLocationModalScreen extends AppScreen {
  get header() {
    return super._screenHeader('Set Location');
  }

  get useCurrentLocationButton() {
    return driver.isAndroid ? $(`~Use Current Location`) : $(`~currentLocation`);
  }

  get setLocationManuallyButton() {
    return driver.isAndroid ? $(`~Set Location Manually Instead`) : $(`~manualLocation`);
  }

  get locationSearchField() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().descriptionStartsWith("search").childSelector(new UiSelector().className("android.widget.EditText"))`,
        )
      : $(`~search-box`);
  }

  get locationResultLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("Chicago, IL 60601")`)
      : $(`-ios predicate string: name == 'Chicago, IL 60601'`);
  }

  /**
   * Set the location manually to the test default (Chicago)
   */
  defaultLocation() {
    this.setLocationManuallyButton.waitForDisplayed(EXTRA_LONG_WAIT);
    this.setLocationManuallyButton.click();
    this.locationSearchField.waitForEnabled();
    // this.locationSearchField.setValue('60601');
    this.sendKeysToElement('60601', this.locationSearchField);
    driver.hideKeyboard();
    this.locationResultLink.waitForDisplayed();
    this.locationResultLink.click();
  }

  /**
   * Use current location. This has some trouble with emulators.
   */
  useCurrentLocation() {
    this.useCurrentLocationButton.click();
    if (driver.isIOS) {
      try {
        this.allowButton.click();
      } catch (IGNORE) {
        // No "Allow UHC Mobile to use your location?" prompt? No problem!
      }
    }
  }
}

export default new SetLocationModalScreen();
