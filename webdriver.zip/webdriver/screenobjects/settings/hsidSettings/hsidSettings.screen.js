// @flow

import AppScreen from '../../app.screen';

class HSIDSettingsScreen extends AppScreen {
  get header() {
    return this.getElementByText('HealthSafe ID™ Settings');
  }

  // Confirm Identity flow
  get confirmIdentityHeader() {
    return driver.isAndroid ? this.getElementByText('Confirm Identity') : $(`~Confirm Identity`);
  }

  get textMeButton() {
    return driver.isAndroid ? this.getElementByText('Text Me*') : $(`~Text Me*`);
  }

  get confirmationCodeInput() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.EditText")`)
      : $(`~Confirmation Code`);
  }

  get confirmationCodeSubmitButton() {
    return driver.isAndroid ? this.getElementByText('CONTINUE') : $('~submit-code');
  }
  // end Confirm Identity flow

  get screenHeader() {
    return super._screenHeader('Sign in and security settings');
  }

  get usernameLabel() {
    return driver.isAndroid ? this.getElementByText('Username') : $(`~Username`);
  }

  get passwordLabel() {
    return driver.isAndroid ? this.getElementByText('Password') : $(`~Password`);
  }

  get passwordEditLink() {
    return $$(`~Edit`)[0];
  }

  get recoveryEmailLabel() {
    return driver.isAndroid ? this.getElementByText('Recovery Email') : $(`~Recovery Email`);
  }

  get recoveryEmailEditLink() {
    return $$(`~Edit`)[1];
  }

  get accountRecoverySectionTitle() {
    return driver.isAndroid ? this.getElementByText('Account Recovery') : $(`~Account Recovery`);
  }

  get updatePasswordHeader() {
    return driver.isAndroid ? this.getElementByText('Update Password') : $(`~Update Password`);
  }

  get currentPasswordField() {
    return driver.isAndroid ? this.getElementByText('Current Password') : $(`~Current Password`);
  }

  get newPasswordField() {
    return driver.isAndroid ? this.getElementByText('New Password') : $(`~New Password`);
  }

  get repeatNewPasswordField() {
    return driver.isAndroid ? this.getElementByText('Re-enter New Password') : $(`~Re-enter New Password`);
  }

  get passwordSaveButton() {
    return driver.isAndroid ? this.getElementByText('Save') : $(`~Save`);
  }

  get passwordsMustMatchErrorMessage() {
    return this.getElementByText('Passwords must match');
  }

  get passwordRulesViolationErrorMessage() {
    return this.getElementByText('Password must match pattern');
  }

  get updateRecoveryEmailHeader() {
    return driver.isAndroid ? this.getElementByText('Update Recovery Email') : $(`~Update Recovery Email`);
  }

  get recoveryEmailField() {
    return driver.isAndroid ? $(`android=new UiSelector().className("android.widget.EditText")`) : $(`~New Email`);
  }

  get recoveryEmailSaveButton() {
    return driver.isAndroid ? this.getElementByText('Save') : $(`~Save`);
  }

  get unconfirmedEmailLabel() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textStartsWith("Unconfirmed email address")`)
      : $(`-ios predicate string: label BEGINSWITH 'Unconfirmed email address'`);
  }

  get accountRecoveryEditLink() {
    return $$(`~Edit`)[2];
  }

  passwordField(index: number) {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.EditText").instance(${index})`)
      : $$(`-ios predicate string: type == 'XCUIElementTypeSecureTextField'`)[index];
  }
}

export default new HSIDSettingsScreen();
