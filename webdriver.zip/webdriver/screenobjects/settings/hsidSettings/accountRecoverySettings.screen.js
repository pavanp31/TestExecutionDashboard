// @flow

import AppScreen from '../../app.screen';

class AccountRecoverySettingsScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Account Recovery');
  }

  get subHeader() {
    return super.getElementByText('If you ever have trouble logging in, how should we confirm your identity?');
  }

  get recoveryMethodDropdown() {
    return $(`~RPicker.trigger`);
  }

  get recoveryPhoneField() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.EditText")`)
      : $(`~Phone Number, (555) 867-5309`);
  }

  get saveButton() {
    return $(`~Save`);
  }

  get invalidPhoneNumberMessage() {
    return super.getElementByText('Please enter your phone number with the correct format');
  }

  get recoveryMethodSecurityQuestionsOption() {
    return $(`~Security Questions`);
  }

  get question1Heading() {
    return super.getElementByText('Question #1');
  }

  get pleaseSelectAQuestionErrors() {
    return driver.android
      ? $$(`~Please select a question.`)
      : $$(
          `-ios predicate string: type == 'XCUIElementTypeButton' AND label CONTAINS 'Please select a question. Error'`,
        );
  }

  get answersCannotBeBlankErrors() {
    return driver.isAndroid
      ? $$(`~Answers cannot be blank.`)
      : $$(
          `-ios predicate string: type == 'XCUIElementTypeOther' AND label == 'Answer, Answers cannot be blank. Error'`,
        );
  }

  get question1Dropdown() {
    return $$(`~RPicker.trigger`)[1];
  }

  get question2Dropdown() {
    return $$(`~RPicker.trigger`)[2];
  }

  get question3Dropdown() {
    return $$(`~RPicker.trigger`)[3];
  }

  selectSecurityQuestions() {
    this.question1Dropdown.click();
    $(`~What was your first phone number?`).click();
    this.question2Dropdown.click();
    $(`~What is your best friend's name?`).click();
    this.question3Dropdown.click();
    $(`~What is your favorite color?`).click();
  }
}

export default new AccountRecoverySettingsScreen();
