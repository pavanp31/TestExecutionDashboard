// @flow

import AppScreen from '../app.screen';
import TouchActions from '../../interactions/touch.actions';
import { ScrollDirection } from '../../constants';

class AccountSettingsScreen extends AppScreen {
  get header() {
    return $(`~Account Settings`);
  }

  // Sections
  // Account Section
  get accountSectionHeader() {
    return this.getElementByText('Account');
  }

  get aboutSectionHeader() {
    return this.getElementByText('About');
  }

  get legalSectionHeader() {
    return this.getElementByText('Legal');
  }

  // Accessibility Section
  get accessibilitySectionHeader() {
    return this.getElementByText('Accessibility');
  }

  get accessibilityStatementLink() {
    return $(`~Accessibility Statement`);
  }

  scrollToAccessibilityStatementLink() {
    TouchActions.scrollToElement(this.accessibilityStatementLink, ScrollDirection.DOWN, 4);
  }

  // Support Section
  get supportSectionHeader() {
    return this.getElementByText('Support');
  }

  scrollToSupportSectionHeader() {
    TouchActions.scrollToElement(this.supportSectionHeader, ScrollDirection.DOWN, 4);
  }

  get applicationSupportLink() {
    return driver.isAndroid
      ? this.getElementByText('1-877-844-4999')
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND name='1 877-844-4999'`);
  }

  scrollToApplicationSupportLink() {
    TouchActions.scrollToElement(this.applicationSupportLink, ScrollDirection.DOWN, 4);
  }

  get logOutLink() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Log Out")`) : $(`~Log Out`);
  }

  scrollToLogoutLink() {
    TouchActions.scrollToElement(this.logOutLink, ScrollDirection.DOWN, 4);
  }

  get hsidSettingsLink() {
    return $(`~User HealthSafe ID™ Settings`);
  }

  get offlineIdCardsLabel() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Save ID Cards Offline")`)
      : $(`~Save ID Cards Offline`);
  }

  get disclaimersAndNoticesLink() {
    return $(`~Disclaimers & Notices`);
  }

  get disclaimersAndNoticesModalContent() {
    return this.getElementByText('The choice of provider is yours');
  }

  get termsOfUseLink() {
    return $(`~Terms of Use`);
  }

  get termsOfUseModalContent() {
    return this.getElementByText('ARBITRATION AGREEMENT AND CLASS ACTION WAIVER');
  }

  get privacyPolicyLink() {
    return $(`~Privacy Policy`);
  }

  get privacyPolicyModalContent() {
    return this.getElementByText('We recognize that the privacy of your information is important');
  }

  get chromeURL() {
    return driver.isAndroid
      ? $(`android=new UiSelector().resourceId("com.android.chrome:id/url_bar")`)
      : $(
          `-ios predicate string: (type == 'XCUIElementTypeTextField' OR type == 'XCUIElementTypeButton') AND name == 'URL'`,
        );
  }
}

export default new AccountSettingsScreen();
