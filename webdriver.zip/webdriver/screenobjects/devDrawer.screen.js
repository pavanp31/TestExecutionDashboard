// @flow

import AppScreen from './app.screen';
import { EXTRA_LONG_WAIT } from '../constants';
import TouchActions from '../interactions/touch.actions';

class DevDrawerScreen extends AppScreen {
  get environmentSwitcher() {
    return $(`~Switch Environment`);
  }

  switchEnvironment(environmentName: string) {
    // sometimes Android takes forever to bring up the dev drawer
    this.environmentSwitcher.waitForDisplayed(EXTRA_LONG_WAIT, false);

    // skip switching an environment if it's already selected
    if (
      (driver.isAndroid &&
        $(`android=new UiSelector().text("${environmentName}").className("android.widget.EditText")`).isExisting()) ||
      (driver.ios &&
        $(`-ios predicate string: type == 'XCUIElementTypeButton' AND label == '${environmentName}'`).isExisting())
    ) {
      this.closeButton.waitForDisplayed();
      this.closeButton.click();
      return;
    }

    // switch to desired environment
    TouchActions.clickUpperLeft(this.environmentSwitcher);
    const el = $(`~${environmentName}`);
    el.waitForEnabled();
    el.click();
    this.closeButton.waitForEnabled();
    this.closeButton.click();
  }
}

export default new DevDrawerScreen();
