// @flow

import AppScreen from '../app.screen';

class SecurityQuestionsScreen extends AppScreen {
  get securityQuestionsHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Security Questions")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Security Questions'`);
  }

  get questionOne() {
    return driver.isAndroid ? $(this.getElementByText('Question #1')) : $(`~Question #1`);
  }

  get answerOne() {
    const selector = '**/XCUIElementTypeOther[`name == "Answer"`][1]';
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.EditText").text("My answer #1")`)
      : $(`-ios class chain:${selector}`);
  }

  get questionTwo() {
    return driver.isAndroid ? $(this.getElementByText('Question #2')) : $(`~Question #2`);
  }

  get answerTwo() {
    const selector = '**/XCUIElementTypeOther[`name == "Answer"`][1]';
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.EditText").text("My answer #2")`)
      : $(`-ios class chain:${selector}`);
  }

  get questionThree() {
    return driver.isAndroid ? $(this.getElementByText('Question #3')) : $(`~Question #3`);
  }

  get answerThree() {
    const selector = '**/XCUIElementTypeOther[`name == "Answer"`][1]';
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.EditText").text("My answer #3")`)
      : $(`-ios class chain:${selector}`);
  }

  get questionsList() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.ScrollView")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeScrollView`);
  }

  get firstPhone() {
    return $(`~What was your first phone number?`);
  }

  get sportTeam() {
    return $(`~Who is your favorite sports team?`);
  }

  get favoriteColor() {
    return $(`~What is your favorite color?`);
  }
}

export default new SecurityQuestionsScreen();
