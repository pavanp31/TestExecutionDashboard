// @flow

import AppScreen from '../app.screen';
import TouchActions from '../../interactions/touch.actions';

class CreateAccountScreen extends AppScreen {
  get createAccountHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Create Account")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Create Account'`);
  }

  get hsidDesc() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.TextView").textContains("Create your HealthSafe ID™")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeStaticText' AND label CONTAINS 'Create your HealthSafe ID™'`);
  }

  get requiredFieldsText() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("All fields are required")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'All fields are required'`);
  }

  get usernameField() {
    const text = 'Username';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get usernameDesc() {
    return this.getElementByText('Username must be between 6 and 20 characters');
  }

  get passwordField() {
    const text = 'Password';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get passwordDesc() {
    return this.getElementByText('Your password must be at least 8 characters');
  }

  get confirmPasswordField() {
    const text = 'Re-Enter Password';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get emailField() {
    const text = 'Email';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get confirmEmailField() {
    const text = 'Re-Enter Email';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get whyEmailLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Why we need your email")`)
      : $(`~Why we need your email`);
  }

  get whyEmailText() {
    const text = 'We will use your email to help you access your account if you are unable to sign in.';
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.webkit.WebView").childSelector(new UiSelector().text("${text}"))`,
        )
      : this.getElementByText(text);
  }

  get recoveryMethodText() {
    return this.getElementByText('how would you like us to confirm your identity?');
  }

  get recoveryMethodDropdown() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionContains("tap to open a dropdown")`)
      : $(`~RPicker.trigger`);
  }

  get textMeSelection() {
    return $(`~Text Me`);
  }

  get securityQuestionsSelection() {
    return $(`~Security Questions`);
  }

  get phoneNumberField() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.EditText").index(19)`)
      : $(`~Phone Number`);
  }

  get rememberUsernameCheckbox() {
    return driver.isAndroid
      ? $(`~Remember my username on this device`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND label CONTAINS 'Remember my username'`);
  }

  get tosCheckbox() {
    return $(
      '~By Selecting this checkbox, I have reviewed and agree to the Terms of Use Privacy Policy and the Consumer Communications Notice.',
    );
  }

  get tosText() {
    const text = 'By selecting this checkbox, I have reviewed and agree to the Terms of Use';
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.TextView").textContains("${text}")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeStaticText' AND label CONTAINS '${text}'`);
  }

  /** * Form Validation Error Messages ** */
  get usernameError() {
    const text =
      'Username must be between 6 and 20 characters and include at least one letter. No spaces or special characters are allowed.';
    return driver.isAndroid ? this.getElementByText(text) : $(`~Username, Required Error`);
  }

  get usernamePatternError() {
    return $(`~Username, Test, Required Error`);
  }

  get passwordError() {
    const text =
      'Your password must be at least 8 characters and include at least 1 uppercase letter, 1 lowercase letter, and 1 number.';
    return driver.isAndroid ? this.getElementByText(text) : $(`~Password, Required Error`);
  }

  get passwordPatternError() {
    const text = 'Password must match pattern';
    return this.getElementByText(text);
  }

  get passwordMatchError() {
    const text = 'Passwords must match';
    return driver.isAndroid
      ? this.getElementByText(text)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH '${text} Error'`);
  }

  get emailMatchError() {
    const text = 'Emails must match';
    return driver.isAndroid
      ? this.getElementByText(text)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH '${text} Error'`);
  }

  get emailError() {
    const text = 'Required, must be in the format of "name@email.com"';
    return this.getElementByText(text);
  }

  get tosError() {
    const text = 'Please indicate that you agree to the above documents by checking this box.';
    return driver.isAndroid ? this.getElementByText(text) : $(`~Error ${text}`);
  }

  get phoneNumberError() {
    const text = 'Please enter your phone number with the correct format, e.g. xxx-xxx-xxxx';
    return this.getElementByText(text);
  }

  // Fill all text fields and check all checkboxes
  createTestAccount() {
    // this.usernameField.setValue('Testname');
    this.sendKeysToElement('Testname', this.usernameField);
    driver.hideKeyboard();

    TouchActions.scrollToElement(this.confirmPasswordField);
    // this.passwordField.setValue('Test1234');
    this.sendKeysToElement('Test1234', this.passwordField);
    driver.hideKeyboard();
    // this.confirmPasswordField.setValue('Test1234');
    this.sendKeysToElement('Test1234', this.confirmPasswordField);
    driver.hideKeyboard();

    TouchActions.scrollToElement(this.confirmEmailField);
    // this.emailField.setValue('Test@test.com');
    this.sendKeysToElement('Test@test.com', this.emailField);
    driver.hideKeyboard();
    // this.confirmEmailField.setValue('Test@test.com');
    this.sendKeysToElement('Test@test.com', this.confirmEmailField);
    driver.hideKeyboard();

    TouchActions.scrollToElement(this.recoveryMethodDropdown);
    this.recoveryMethodDropdown.click();
    this.securityQuestionsSelection.click();

    this.tosCheckbox.click();
  }
}

export default new CreateAccountScreen();
