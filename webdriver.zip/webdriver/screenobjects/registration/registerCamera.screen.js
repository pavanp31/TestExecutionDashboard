// @flow

import AppScreen from './../app.screen';

class RegisterCameraScreen extends AppScreen {
  get useCameraHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Use your camera to register")`)
      : $(`~Use your camera to register`);
  }

  get useCameraDesc() {
    const text = 'scan the back of your insurance card';
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("${text}")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS '${text}'`);
  }

  get useCameraButton() {
    return $(`~Use camera to register`);
  }

  get registerManuallyLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Register Manually")`)
      : $(`~Register Manually`);
  }

  /* Camera window screen */

  get placeBarcodeDesc() {
    const text = 'Place the barcode from your insurance card in the camera window.';
    return driver.isAndroid ? $(`android=new UiSelector().text("${text}")`) : $(`~${text}`);
  }

  get registerManuallyButton() {
    return driver.isAndroid
      ? $(`~Register Manually`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND label == 'Register Manually'`);
  }
}

export default new RegisterCameraScreen();
