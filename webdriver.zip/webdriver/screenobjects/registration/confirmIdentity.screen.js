// @flow

import AppScreen from './../app.screen';

class ConfirmIdentityScreen extends AppScreen {
  get confirmIdentityHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Confirm Identity")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Confirm Identity'`);
  }

  get completeRegistrationDesc() {
    const text = 'To complete registration and protect your information';
    return this.getElementByText(text);
  }

  get emailMeButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Email Me")`)
      : $(`~confirm-by-mail`);
  }

  get textMeButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Text Me*")`)
      : $(`~confirm-by-text`);
  }

  get dataRatesText() {
    const text = '*Messaging and voice data rates may apply';
    return driver.isAndroid ? this.getElementByText(text) : $(`~${text}`);
  }

  get callUsLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.TextView").textContains("Questions about this app?")`)
      : $(`~Questions about this app? Call Us`);
  }

  get textConfirmation() {
    const text = 'A Text Message Will Arrive Shortly';
    return driver.isAndroid ? this.getElementByText(text) : $(`~${text}`);
  }
}

export default new ConfirmIdentityScreen();
