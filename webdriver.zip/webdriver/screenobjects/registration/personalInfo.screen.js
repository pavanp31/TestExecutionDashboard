// @flow

import AppScreen from '../app.screen';
import TouchActions from '../../interactions/touch.actions';

class PersonalInfoScreen extends AppScreen {
  get personalInfoHeader() {
    return $(`~Personal Information`);
  }

  get personalInfoDesc() {
    const text = 'to secure your personal health information.';
    return driver.isAndroid ? $(`android=new UiSelector().text("${text}")`) : $(`~${text}`);
  }

  get HSIDInfoButton() {
    const text = 'HealthSafe ID™';
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.Button").textContains("${text}")`)
      : $(`~${text} `);
  }

  get optionalFieldsDesc() {
    const text = 'All fields are required unless indicated as optional.';
    return driver.isAndroid ? $(`android=new UiSelector().text("${text}")`) : $(`~${text}`);
  }

  get firstNameField() {
    const text = 'First Name';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionStartsWith("${text}")`) : $(`~${text}`);
  }

  get lastNameField() {
    const text = 'Last Name';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get chooseDate() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.Button").descriptionStartsWith("Date of Birth")`)
      : $(`~RPicker.trigger`);
  }

  get idCardDesc() {
    return this.getElementByText(`Do you have your member ID card?`);
  }

  get yesRadioButton() {
    return $(`~Yes`);
  }

  get noRadioButton() {
    return $(`~No`);
  }

  get memberIDField() {
    const text = 'Member ID';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get memberIDError() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Please select one")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'Please select one'`);
  }

  get groupNumberField() {
    const text = 'Group #';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get SSNField() {
    const text = 'SSN: Last 6 digits of your Social Security number';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get zipCodeField() {
    const text = 'Zip Code';
    return driver.isAndroid ? $(`android=new UiSelector().descriptionContains("${text}")`) : $(`~${text}`);
  }

  get SSNError() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Required, must be last six digits of SSN")`)
      : $(
          `-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'Required, must be last six digits of SSN Error'`,
        );
  }

  get clearTextField() {
    const selector = '**/XCUIElementTypeOther[`name == "Clear text"`]/XCUIElementTypeOther/XCUIElementTypeTextField';
    return $(`-ios class chain:${selector}`);
  }

  get zipCodeError() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Required, must be five digits")`)
      : $(
          `-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'Required, must be five digits Error'`,
        );
  }

  get notSureHSID() {
    const text = 'Not sure if you have a HealthSafe ID™?';
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("${text}")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS '${text}'`);
  }

  get infoModal() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.webkit.WebView")`)
      : $(`~Learn more about HealthSafe ID`);
  }

  /**
   Goes through the registration using member ID, to get to the next screen in multiple tests
   */
  registerWithCard() {
    this.firstNameField.waitForEnabled();
    // this.firstNameField.setValue('test');
    this.sendKeysToElement('test', this.firstNameField);
    // this.lastNameField.setValue('test');
    this.sendKeysToElement('test', this.lastNameField);
    driver.hideKeyboard();
    this.chooseDate.click();
    this.doneButton.waitForDisplayed();
    this.doneButton.click();
    this.yesRadioButton.click();
    TouchActions.scrollToElement(this.continueButton);
    // this.memberIDField.setValue('12345');
    this.memberIDField.waitForDisplayed();
    this.sendKeysToElement('12345', this.memberIDField);
    // driver.hideKeyboard();
    if (driver.isKeyboardShown()) {
      this.yesRadioButton.click();
    }
    // this.groupNumberField.setValue('12345');
    this.sendKeysToElement('12345', this.groupNumberField);
    driver.hideKeyboard();
    TouchActions.scrollToElement(this.continueButton);
    this.continueButton.click();
  }
}

export default new PersonalInfoScreen();
