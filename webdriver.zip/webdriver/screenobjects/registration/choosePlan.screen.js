// @flow

import AppScreen from './../app.screen';

class ChoosePlanScreen extends AppScreen {
  get choosePlanHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Choose your medical plan")`)
      : $(`~Choose your medical plan`);
  }

  get choosePlanDesc() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("To continue, please select")`)
      : $(`~To continue, please select an option below that most closely resembles your current medical health plan`);
  }

  get EnIButton() {
    return driver.isAndroid
      ? $(`~Individual & Family Plans, Employer Plans, and Short Term Health Plans`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND label CONTAINS 'Individual & Family Plans'`);
  }

  get MnRButton() {
    return driver.isAndroid
      ? $(`~Medicare Advantage Plans and Group Retiree Plans through UnitedHealthcare® or AARP®`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND label CONTAINS 'Medicare Advantage Plans'`);
  }

  get CnSButton() {
    return driver.isAndroid
      ? $(`~Medicaid & Dual Special Needs Plans (DSNP) through UnitedHealthcare®`)
      : $(
          `-ios predicate string: type == 'XCUIElementTypeButton' AND label CONTAINS 'Medicaid & Dual Special Needs Plans'`,
        );
  }

  // Different iOS accessibility ID than the other screens
  get continueButton() {
    return driver.isAndroid ? $(`~Continue`) : $(`~submit-button`);
  }

  get signInNow() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Sign in now")`)
      : $(`~Sign in now`);
  }

  get callUs() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.TextView").textContains("Questions about this app?")`)
      : $(`-ios predicate string: name BEGINSWITH "Questions about this app?"`);
  }

  /* M&R specific choose plan screen */
  get registerMedicareButton() {
    return $(`~Register with a Medicare Plan`);
  }

  get goBackButton() {
    return $(`~Go Back`);
  }
}

export default new ChoosePlanScreen();
