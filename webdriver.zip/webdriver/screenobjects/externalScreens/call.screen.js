// @flow

import AppScreen from './../app.screen';

class CallScreen extends AppScreen {
  isOnScreen() {
    this.getElementByText('Add to a contact').waitForExist();
  }

  goBack() {
    // takes three back presses to go back to the app
    driver.back();
    driver.back();
    driver.back();
  }
}

export default new CallScreen();
