// @flow

import { EXTRA_LONG_WAIT, LONG_WAIT } from '../../constants';
import AppScreen from '../app.screen';

class MapScreen extends AppScreen {
  checkAddress(address: string) {
    this.getElementByText(address).waitForExist(EXTRA_LONG_WAIT);
    this.getElementByText('Directions').waitForExist(LONG_WAIT);
  }

  goBack() {
    if (driver.isAndroid) {
      driver.back();
    } else {
      driver.touchPerform([{ action: 'press', options: { x: 10, y: 10 } }]);
    }
  }
}

export default new MapScreen();
