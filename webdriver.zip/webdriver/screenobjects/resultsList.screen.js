// @flow

import AppScreen from './app.screen';

class ResultsListScreen extends AppScreen {
  /** Work in progress, add elements that you need */

  // Android only
  get searchButton() {
    return $(`~Search`);
  }

  get mapButton() {
    return driver.isAndroid ? $(`android=new UiSelector().text("MAP")`) : $(`~Map`);
  }

  get filterButton() {
    return driver.isAndroid ? $(`android=new UiSelector().text("FILTER")`) : $(`~Filter`);
  }

  get viewCost() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionContains(" Cost")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Cost'`);
  }

  get firstProviderResult() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.widget.Button").descriptionStartsWith("Provider,")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND name BEGINSWITH[cd] 'Provider, '`);
  }

  getProviderResultsItem(itemIndex: number) {
    const items = driver.isAndroid
      ? $$(`android=new UiSelector().className("android.widget.Button").descriptionStartsWith("Provider,")`)
      : $$(`-ios predicate string: type == 'XCUIElementTypeButton' AND name BEGINSWITH[cd] 'Provider, '`);
    return items[itemIndex];
  }
}

export default new ResultsListScreen();
