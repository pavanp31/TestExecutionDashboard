// @flow
import AppScreen from '../app.screen';

class FinancialClaimsScreen extends AppScreen {
  get fsahcClaimDetailsLinks() {
    return driver.isAndroid
      ? $$(`android=new UiSelector().textStartsWith("FSA Claim #")`)
      : $$(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'FSA Claim #'`);
  }
}

export default new FinancialClaimsScreen();
