// @flow
import AppScreen from '../app.screen';

class ManageClaimsScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Claims');
  }

  get fsahcTab() {
    // android: accessibilityLabel, ios: testID
    return driver.isAndroid ? $('~Healthcare FSA tab') : $('~fsaHcTab');
  }

  get hraTab() {
    // android: accessibilityLabel, ios: testID
    return driver.isAndroid ? $('~Health Reimbursement Account tab') : $('~hraTab');
  }

  get noClaimsAvailable() {
    return super.getElementByText('There are no claims');
  }
}

export default new ManageClaimsScreen();
