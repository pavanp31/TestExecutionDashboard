// @flow

import AppScreen from './app.screen';
import { SHORT_WAIT, LONG_WAIT, SUPER_LONG_WAIT } from '../constants';

class SignInScreen extends AppScreen {
  get hsidNotice() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().className("android.widget.TextView").text("This app uses HealthSafe ID™ for sign in and registration.")`,
        )
      : $(`~This app uses HealthSafe ID™ for sign in and registration.`);
  }

  get usernameField() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().descriptionStartsWith("Username").childSelector(new UiSelector().className("android.widget.EditText"))`,
        )
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND name BEGINSWITH 'Username'`);
  }

  get passwordField() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().descriptionStartsWith("Password").childSelector(new UiSelector().className("android.widget.EditText"))`,
        )
      : $(`~Password`);
  }

  get rememberUsernameCheckbox() {
    return $(`~Remember my username on this device`);
  }

  get tosCheckbox() {
    return $(
      `~By Selecting this checkbox, I have reviewed and agree to the Terms of Use Privacy Policy and the Consumer Communications Notice.`,
    );
  }

  get signInButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("SIGN IN")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND name == 'signInButton'`);
  }

  get createAccountLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("New User? Create an account.")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeStaticText' AND name == 'New User? Create an account.'`);
  }

  get tosError() {
    return $(`~Error Please indicate that you agree to the above documents by checking this box.`);
  }

  /** Fingerprint login modal (Android only) */
  get fingerprintHeader() {
    return $(`android=new UiSelector().text("Fingerprint login")`);
  }
  get usePasswordButton() {
    return $(`android=new UiSelector().text("USE PASSWORD")`);
  }

  /** save password to iCloud message (iOS only) */
  get iCloudAlert() {
    return $(`~Save this password to iCloud Keychain?`);
  }
  get iCloudAlertNoButton() {
    return $(`~No`);
  }

  dismissFingerprintModal() {
    try {
      this.fingerprintHeader.waitForDisplayed();
      this.usePasswordButton.click();
    } catch (error) {
      // Fingerprint not enabled on the test device
    }
  }

  dismissiCloudMessage() {
    try {
      this.iCloudAlert.waitForDisplayed();
      this.iCloudAlertNoButton.click();
    } catch (error) {
      // no alert, no problem
    }
  }

  /** Log in without credentials, for local mock server */
  defaultLogIn(userName: string = 'test', password: string = 'test', superLongWait: boolean = false) {
    this.hsidNotice.waitForDisplayed();

    this.sendKeysToElement(userName, this.usernameField);
    this.sendKeysToElement(password, this.passwordField);
    driver.hideKeyboard();

    // Check the checkbox, with a try/catch in case it's not checked
    this.tosCheckbox.click();
    this.signInButton.click();
    try {
      this.tosError.waitForDisplayed(SHORT_WAIT, true);
    } catch (error) {
      this.tosCheckbox.click();
      this.signInButton.click();
    }
    if (driver.isAndroid) {
      this.dismissFingerprintModal();
    }
    if (!driver.isAndroid) {
      this.dismissiCloudMessage();
    }
    this.signInButton.waitForDisplayed(superLongWait ? SUPER_LONG_WAIT : LONG_WAIT, true);
  }
}

export default new SignInScreen();
