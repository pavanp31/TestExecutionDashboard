// @flow

import AppScreen from './app.screen';
import { MED_WAIT, EXTRA_LONG_WAIT } from '../constants';

class WelcomeScreen extends AppScreen {
  get welcomeLogo() {
    return driver.isAndroid
      ? $(`~United Healthcare`)
      : $(`-ios predicate string: type == "XCUIElementTypeImage" AND name BEGINSWITH "United Healthcare"`);
  }
  get welcomeTitle() {
    return $(`~Welcome to UnitedHealthcare`);
  }
  get signInBtn() {
    return driver.isAndroid
      ? $(`~Sign In`)
      : $(`-ios predicate string: type == "XCUIElementTypeButton" AND name CONTAINS "Sign In"`);
  }
  get createAccountBtn() {
    return $(`~Create Account`);
  }
  get questionsNotice() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Questions about this app?")`)
      : $(`-ios predicate string: type == "XCUIElementTypeStaticText" AND name CONTAINS "Questions about this app?"`);
  }
  get helpLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textStartsWith("Questions about this app?")`)
      : $(`-ios predicate string: name BEGINSWITH "Questions about this app?"`);
  }
  get supportPhoneNo() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().resourceIdMatches("com(\.google)?\.android\.dialer:id/digits")`, // eslint-disable-line no-useless-escape
        )
      : $(
          `-ios predicate string: type == "XCUIElementTypeStaticText" AND label CONTAINS "We were unable to initiate a phone call for you"`,
        );
  }

  waitForLoaded() {
    try {
      this.welcomeLogo.waitForDisplayed(MED_WAIT);
    } catch (error) {
      // if the close or cancel buttons are displayed it means we bypassed the welcome screen and
      // went straight to the login screen, so let's close that and go back
      if (this.closeButton.isDisplayed()) {
        this.closeButton.click();
      } else if (this.headerCancelButton.isDisplayed()) {
        this.headerCancelButton.click();
      }
    }
    this.welcomeLogo.waitForDisplayed(EXTRA_LONG_WAIT);
  }

  openDevDrawer() {
    this.welcomeLogo.waitForDisplayed();
    this.welcomeLogo.touchAction(['tap', 'tap', 'tap']);
  }
}

export default new WelcomeScreen();
