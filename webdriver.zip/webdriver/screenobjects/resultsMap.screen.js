// @flow

import AppScreen from './app.screen';

class ResultsMapScreen extends AppScreen {
  /** Work in progress, add elements that you need */

  get listButton() {
    return driver.isAndroid ? $(`android=new UiSelector().textContains("LIST")`) : $(`~List`);
  }

  get filterButton() {
    return driver.isAndroid ? $(`android=new UiSelector().textContains("FILTER")`) : $(`~Filter`);
  }
}

export default new ResultsMapScreen();
