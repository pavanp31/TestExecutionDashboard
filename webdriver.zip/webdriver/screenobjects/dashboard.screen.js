// @flow

import AppScreen from './app.screen';

class DashboardScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Dashboard');
  }
  // =========
  // NPS Modal
  // =========
  get npsModalTitle() {
    return this.getElementByText('How likely are you to recommend this app to others?');
  }

  // ===============
  // Section Headers
  // ===============
  get quickLinksHeader() {
    return this.getElementByText(`Quick Links`);
  }

  get savedHeader() {
    return this.getElementByText(`Saved`);
  }

  get idCardHeader() {
    return this.getElementByText(`ID Card`);
  }

  get accountHeader() {
    return this.getElementByText(`Account`);
  }

  get healthChecklistHeader() {
    return this.getElementByText(`Health Checklist`);
  }

  get contactUsHeader() {
    return this.getElementByText(`Contact Us`);
  }

  get claimsHeader() {
    return this.getElementByText(`Claims`);
  }

  // ===========
  // Quick Links
  // ===========
  get findUrgentCareQuickLink() {
    return driver.isAndroid ? $(`~Find Urgent Care`) : $(`~findUrgentLink`);
  }

  get findMedicalCareQuickLink() {
    return driver.isAndroid ? $(`~Find Medical Care`) : $(`~findDoctorsLink`);
  }

  get findMentalHealthCareQuickLink() {
    return driver.isAndroid ? $(`~Find Mental Health Care`) : $(`~findMentalLink`);
  }

  get manageClaimsQuickLink() {
    return driver.isAndroid ? $(`~Manage and Pay Claims`) : $(`~manageClaimsLink`);
  }

  // =============
  // Saved Section
  // =============
  get savedSeeAllLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().description("See All").instance(0)`)
      : $(`~Saved See All`).$(`~See All`);
  }

  // ======================
  // Member ID Card Section
  // ======================
  get memberIdCard() {
    return $(`~Member ID Card`);
  }

  get sendIdCardButton() {
    return $(`~Send ID Card`);
  }

  get findUrgentCareButton() {
    return driver.isAndroid ? $(`~Find Urgent Care`) : $(`~findUrgentLink`);
  }

  get findMedicalCareButton() {
    return driver.isAndroid ? $(`~Find Medical Care`) : $(`~findDoctorsLink`);
  }

  get findMentalHealthcareButton() {
    return driver.isAndroid ? $(`~Find Mental Health Care`) : $(`~findMentalLink`);
  }
}

export default new DashboardScreen();
