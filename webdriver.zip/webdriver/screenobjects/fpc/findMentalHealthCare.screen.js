// @flow

import AppScreen from '../app.screen';

class FindMentalHealthCareScreen extends AppScreen {
  get screenHeader() {
    return super._screenHeader('Find Mental Health Care');
  }
  get findCareNearHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Find Care Near")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Find Care Near'`);
  }

  get careUnavailable() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().textContains("We're sorry, Find Mental Health Care is currently unavailable for your healthcare plan.")`,
        )
      : $(
          `-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Find Mental Health Care is currently unavailable for your healthcare plan.'`,
        );
  }

  get currentLocationButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionContains("Current Location")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Current Location'`);
  }

  get categoriesHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Categories")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeStaticText' AND label CONTAINS 'Categories'`);
  }

  get peopleButton() {
    return driver.isAndroid
      ? $(`~People `)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'People'`);
  }

  get placesButton() {
    return driver.isAndroid
      ? $(`~Places `)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Places'`);
  }

  get careByConditionButton() {
    return driver.isAndroid
      ? $(`~Care by Conditions `)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Care by Conditions'`);
  }
}

export default new FindMentalHealthCareScreen();
