// @flow
import AppScreen from '../app.screen';

class FindServicesAndTreatmentsScreen extends AppScreen {
  get whatServicesOrTreatments() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("What kinds of services or treatments?")`)
      : $(`~What kinds of services or treatments?`);
  }

  get officeVisitsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Office Visits")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Office Visits'`);
  }

  get vaccinesButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Vaccines")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS "Vaccines"`);
  }

  get adultVaccinesButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Adult Vaccines")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS "Adult Vaccines"`);
  }

  get chickenpoxVaccineButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Vaccine - Chickenpox")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS "Vaccine - Chickenpox"`);
  }

  get testsAndImagingButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Tests and Imaging")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Tests and Imaging'`);
  }

  get wellVisitButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Well Visit")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Well Visit'`);
  }
}

export default new FindServicesAndTreatmentsScreen();
