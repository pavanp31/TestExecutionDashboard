// @flow
import AppScreen from './../app.screen';

class CostEstimatesScreen extends AppScreen {
  get costEstimatesHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("What would you like a cost estimate for?")`)
      : $(`~What would you like a cost estimate for?`);
  }

  get allButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("All")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'All'`);
  }

  get officeVisitsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Office Visits")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Office Visits'`);
  }

  get vaccinesButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Vaccines")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Vaccines'`);
  }

  get testsAndImagingButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Tests and Imaging")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Tests and Imaging'`);
  }

  get findByConditionButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Find by Condition")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Find by Condition'`);
  }
}

export default new CostEstimatesScreen();
