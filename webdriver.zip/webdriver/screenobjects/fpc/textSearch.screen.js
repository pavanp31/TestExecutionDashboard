// @flow

import AppScreen from '../app.screen';
import { textSearchTerm } from '../../constants';

class TextSearchScreen extends AppScreen {
  get allResultsHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Show All Results For")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'Show All Results For'`);
  }

  get allResultsLink() {
    return driver.isAndroid
      ? $(`~${textSearchTerm}`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label MATCHES '${textSearchTerm}'`);
  }

  get specialtiesHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Specialties")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'Specialties'`);
  }

  get specialtiesLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Federal Qualified Health Center")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label MATCHES 'Federal Qualified Health Center'`);
  }

  get keywordHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("keyword")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'keyword'`);
  }

  get keywordLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("medication questions")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label MATCHES 'medication questions'`);
  }

  get doctorsHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Health Care Professionals")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'Health Care Professionals'`);
  }

  get doctorLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Qrque, Roland S, MD")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label ENDSWITH 'Qrque, Roland S, MD'`);
  }

  get savedTabs() {
    return driver.isAndroid
      ? $$(
          `android=new UiSelector().className("android.widget.Button").childSelector(new UiSelector().className("android.widget.ImageView"))`,
        )
      : $$(`-ios predicate string: type == 'XCUIElementTypeOther' AND value CONTAINS 'checkbox'`);
  }

  get clinicsHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Clinics and Facilities")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'Clinics and Facilities'`);
  }

  get clinicLink() {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("Fusion Diagnostic Group")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label ENDSWITH 'Fusion Diagnostic Group'`);
  }

  get OONBanner() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("Out-of-Network")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label ENDSWITH 'Out-of-Network'`);
  }
}

export default new TextSearchScreen();
