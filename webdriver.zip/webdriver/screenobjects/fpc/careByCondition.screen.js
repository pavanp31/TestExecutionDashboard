// @flow
import AppScreen from './../app.screen';

class CareByConditionScreen extends AppScreen {
  get whatTreatmentHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("What are you looking to treat?")`)
      : $(`~What are you looking to treat?`);
  }

  get areaOfBodyButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Area of the Body")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Area of the Body'`);
  }

  get typeOfConditionButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Type of Condition")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Type of Condition'`);
  }
}

export default new CareByConditionScreen();
