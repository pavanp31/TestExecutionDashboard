// @flow
import AppScreen from './../app.screen';

class AreaOfBodyScreen extends AppScreen {
  get areaOfBodyHeader() {
    return driver.isAndroid ? $(`android=new UiSelector().textContains("Area of the Body")`) : $(`~Area of the Body`);
  }

  get bladderKidneyUrinaryButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Bladder, Kidney and Urinary Tract")`)
      : $(
          `-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Bladder, Kidney and Urinary Tract'`,
        );
  }

  get bonesJointsMusclesSpineButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Bones, Joints, Muscles and Spine")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Bones, Joints, Muscles and Spine'`);
  }

  get breathingAndLungsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Breathing and Lungs")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Breathing and Lungs'`);
  }

  get earNoseAndThroatButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Ear, Nose and Throat")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Ear, Nose and Throat'`);
  }

  get endocrineAndMetabolicButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Endocrine and Metabolic")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Endocrine and Metabolic'`);
  }

  get gallbladderLiverPancreasButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Gallbladder, Liver and Pancreas")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Gallbladder, Liver and Pancreas'`);
  }

  get heartAndCirculationButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Heart and Circulation")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Heart and Circulation'`);
  }

  get immuneSystemButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Immune System")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Immune System'`);
  }

  get mensHealthButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Men's Health")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS "Men's Health"`);
  }

  get pregnancyAndChildbirth() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Pregnancy and Childbirth")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Pregnancy and Childbirth'`);
  }

  get preventiveMedicineButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Preventive Medicine/Vaccines")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Preventive Medicine/Vaccines'`);
  }

  get skinHairAndNails() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Skin, Hair and Nails")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Skin, Hair and Nails'`);
  }

  get stomachBowelAndRectalButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Stomach, Bowel and Rectal")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Stomach, Bowel and Rectal'`);
  }

  get womensHealthButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Women's Health")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS "Women's Health"`);
  }
}

export default new AreaOfBodyScreen();
