// @flow
import AppScreen from './../app.screen';

class TypeOfConditionScreen extends AppScreen {
  get typeOfConditionHeader() {
    return driver.isAndroid ? $(`android=new UiSelector().textContains("Type of Condition")`) : $(`~Type of Condition`);
  }

  get allergiesButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Allergies")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Allergies'`);
  }

  get arthritisButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Arthritis")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Arthritis'`);
  }

  get asthmaButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Asthma")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Asthma'`);
  }

  get backPainButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Back Pain")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Back Pain'`);
  }

  get breastCancerButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Breast Cancer")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Breast Cancer'`);
  }

  get childrensHealthButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Children's Health Concerns")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS "Children's Health Concerns"`);
  }

  get coldOrFluButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Cold or Flu")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Cold or Flu'`);
  }

  get diabetesButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Diabetes")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Diabetes'`);
  }

  get digestiveProblemsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Digestive Problems")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Digestive Problems'`);
  }

  get emphysemaButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Emphysema (COPD)")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Emphysema (COPD)'`);
  }

  get heartDiseaseButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Heart Disease")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Heart Disease'`);
  }

  get highBloodPressureButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("High Blood Pressure")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'High Blood Pressure'`);
  }

  get injuriesButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Injuries')`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Injuries'`);
  }

  get lungCancerButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Lung Cancer")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Lung Cancer'`);
  }

  get measlesButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Measles")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Measles'`);
  }

  get mensHealthButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Men's Health Concerns")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS "Men's Health Concerns"`);
  }

  get pregnancyButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Pregnancy")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Pregnancy'`);
  }

  get prostateCancerButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Prostate Cancer")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Prostate Cancer'`);
  }

  get stiButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Sexually Transmitted Infections")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Sexually Transmitted Infections'`);
  }

  get skinConditionsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Skin Conditions")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Skin Conditions'`);
  }

  get strokeButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Stroke")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Stroke'`);
  }

  get womensHealthButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Women's Health Concerns")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS "Women's Health Concerns"`);
  }
}

export default new TypeOfConditionScreen();
