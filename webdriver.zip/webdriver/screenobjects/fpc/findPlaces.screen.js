// @flow
import AppScreen from './../app.screen';

class FindPlacesScreen extends AppScreen {
  get whichPlaceHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Which type of place?")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Which type of place?'`);
  }

  get clinicsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Clinics")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Clinics'`);
  }

  get hospitalsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Hospitals")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Hospitals'`);
  }

  get specialtyCentersButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Specialty Centers")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Specialty Centers'`);
  }

  get labsAndImagingButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Labs and Imaging")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Labs and Imaging'`);
  }

  get medicalSuppliersButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Medical Suppliers")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Medical Suppliers'`);
  }

  /* Types of Clinics */

  get primaryCareClinic() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Primary Care Clinic")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND name BEGINSWITH 'Primary Care Clinic'`);
  }

  get convenienceClinic() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Convenience Clinic")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND name BEGINSWITH 'Convenience Clinic'`);
  }

  get urgentCareClinic() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Urgent Care Clinic")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND name BEGINSWITH 'Urgent Care Clinic'`);
  }

  get virtualVisits() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Virtual Visits")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND name BEGINSWITH 'Virtual Visits'`);
  }
}

export default new FindPlacesScreen();
