// @flow
import AppScreen from '../app.screen';

class FindPeopleScreen extends AppScreen {
  get whoYouLookingForHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Who are you looking for?")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Who are you looking for?'`);
  }

  get primaryCareButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Primary Care")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Primary Care'`);
  }

  get specialityCareButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Specialty Care")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Specialty Care'`);
  }

  get medicalGroupsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Medical Groups")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Medical Groups'`);
  }

  get virtualVisitsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionStartsWith("Virtual Visits")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Virtual Visits'`);
  }

  get allPrimaryCarePhysicians() {
    return $(`~All Primary Care Physicians`);
  }
}

export default new FindPeopleScreen();
