// @flow

import AppScreen from '../app.screen';

class FindUrgentCareScreen extends AppScreen {
  get screenHeader() {
    return $(`~Find Urgent Care`);
  }
  get kindOfCareHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("What kind of care do you need?")`)
      : $(`~What kind of care do you need?`);
  }

  get convenienceClinicButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionContains("Convenience Clinic")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Convenience Clinic'`);
  }

  get urgentCareClinicButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionContains("Urgent Care Clinic")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Urgent Care Clinic'`);
  }

  get virtualVisitsButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionContains("Virtual Visits")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Virtual Visits'`);
  }

  get emergencyCallText() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("Have an emergency? Call 911")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Have an emergency? Call 911'`);
  }
}

export default new FindUrgentCareScreen();
