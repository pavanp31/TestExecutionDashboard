// @flow

import AppScreen from '../app.screen';

class FindMedicalCareScreen extends AppScreen {
  get findCareNearHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Find Care Near")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Find Care Near'`);
  }

  get currentLocationButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionContains("Current Location")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Current Location'`);
  }

  get categoriesHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Categories")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Categories'`);
  }

  get peopleButton() {
    return driver.isAndroid
      ? $(`~People `)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'People'`);
  }

  get placesButton() {
    return driver.isAndroid
      ? $(`~Places `)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Places'`);
  }

  get servicesAndTreatmentsButton() {
    return driver.isAndroid
      ? $(`~Services and Treatments `)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Services and Treatments'`);
  }

  get careByConditionButton() {
    return driver.isAndroid
      ? $(`~Care by Condition `)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Care by Condition'`);
  }

  get costEstimatesButton() {
    return driver.isAndroid
      ? $(`~Cost Estimates `)
      : $(`-ios predicate string: type == 'XCUIElementTypeLink' AND label CONTAINS 'Cost Estimates'`);
  }
}

export default new FindMedicalCareScreen();
