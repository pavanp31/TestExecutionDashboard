// @flow

import AppScreen from '../app.screen';

class FacilityDetailsScreen extends AppScreen {
  get overviewTab() {
    return driver.isAndroid ? $(`android=new UiSelector().textContains("Overview")`) : $(`~Overview tab`);
  }

  get locationsTab() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Locations")`) : $(`~Locations tab`);
  }

  get physicianDirectoryTab() {
    return driver.isAndroid ? $(`android=new UiSelector().text("Physician Directory")`) : $(`~Physician Directory tab`);
  }

  get telephoneLink() {
    return driver.isAndroid ? $(`android=new UiSelector().textContains("Tel")`) : $(`~phone.link`);
  }

  get saveButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("Save")`)
      : $(`-ios predicate string: name BEGINSWITH 'Save'`);
  }

  get shareButton() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("Share")`)
      : $(`-ios predicate string: name BEGINSWITH 'Share'`);
  }
}

export default new FacilityDetailsScreen();
