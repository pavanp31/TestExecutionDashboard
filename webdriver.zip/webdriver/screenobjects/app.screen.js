// @flow

import TouchActions from '../interactions/touch.actions';
import { SHORT_WAIT, EXTRA_LONG_WAIT, MED_MARGIN } from '../constants';

export default class AppScreen {
  get splashScreenLogo() {
    return $(`~UHC logo`);
  }

  get okButton() {
    return $(`~OK`);
  }

  // Usually the OK button for native modals
  get doneButton() {
    return driver.isAndroid ? $(`android=new UiSelector().resourceId("android:id/button1")`) : $(`~Done`);
  }

  get yesButton() {
    return driver.isAndroid ? $(`android=new UiSelector().text("YES")`) : $(`~Yes`);
  }

  get closeButton() {
    return driver.isAndroid
      ? $(`~close`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND name == 'close'`);
  }

  /* For permissions modals */
  get allowButton() {
    return $(`~Allow`);
  }

  get headerCancelButton() {
    return driver.isAndroid
      ? $(`~close`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND name == 'Cancel'`);
  }

  get menuButton() {
    return driver.isAndroid
      ? $(`~Menu`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label == 'Menu'`);
  }

  get statusBar() {
    return $(`-ios predicate string: type == 'XCUIElementTypeStatusBar'`);
  }

  get actionBar() {
    return $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label == 'Dashboard Menu'`);
  }

  /* iOS and Android have text search in different places */
  get textSearchField() {
    return driver.isAndroid
      ? $(`android.widget.EditText`)
      : $(
          `-ios predicate string: type == 'XCUIElementTypeOther' AND name BEGINSWITH 'Search doctors, facilities, conditions' AND label ENDSWITH 'search results found'`,
        );
  }

  get androidTextSearchButton() {
    return $(`~Search`);
  }

  get continueButton() {
    return driver.isAndroid
      ? $(`~Continue`)
      : $(`-ios predicate string: type == 'XCUIElementTypeButton' AND name == 'Continue'`);
  }

  get backButton() {
    return $(`~Back`);
  }

  get loadingSpinner() {
    return driver.isAndroid ? $(`android.widget.ProgressBar`) : $(`XCUIElementTypeActivityIndicator`);
  }

  get requiredError() {
    return driver.isAndroid ? $(`~Required, Error`) : $(`-ios predicate string: label ENDSWITH 'Required Error'`);
  }

  get requiredErrors() {
    return driver.isAndroid ? $$(`~Required, Error`) : $$(`-ios predicate string: label ENDSWITH 'Required Error'`);
  }

  get dismissReact() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Dismiss All")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND name CONTAINS 'Dismiss All'`);
  }

  getElementByText(text: string) {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("${text}")`)
      : $(`-ios predicate string: name CONTAINS '${text}'`);
  }

  getElementsByText(text: string) {
    return driver.isAndroid
      ? $$(`android=new UiSelector().textContains("${text}")`)
      : $$(`-ios predicate string: name CONTAINS '${text}'`);
  }

  getElementByDesc(desc: string) {
    return driver.isAndroid
      ? $(`android=new UiSelector().descriptionContains("${desc}")`)
      : $(`-ios predicate string: label CONTAINS '${desc}'`);
  }

  /** Appium has trouble accessing iOS text fields in RN 61.
   This workaround clicks an element and splits a string into a char array for the driver */
  sendKeysToElement(text: string, element: WDElement) {
    this.waitForKeyboardHidden();
    TouchActions.clickLowerRight(element);
    try {
      this.waitForKeyboardShown();
    } catch (error) {
      // Click in the middle of the element, mostly for fields with description text
      const location = element.getLocation();
      TouchActions.clickAtCoordinates(location.x + MED_MARGIN, location.y + MED_MARGIN);
    }
    driver.sendKeys([...text]);
    driver.pause(250);
  }

  // picker wheel command that defaults to clicking below the active element in the iOS picker wheel
  selectFromPickerWheel(text: string, element: WDElement, clickSectionAbove: boolean = false) {
    // if clickSectionAbove parameter is set to true, it will set the click location 108 pixels
    // from the top of the picker wheel component, just above the active element. If set to
    // false the clickSectionAbove parameter will set the click location 176 pixels from
    // the top of the picker wheel component, just below the active element
    const clickBelowActivePickerElement = element.getLocation('y') + 176;

    const clickAboveActivePickerElement = element.getLocation('y') + 108;

    const y = clickSectionAbove ? clickAboveActivePickerElement : clickBelowActivePickerElement;

    let currentValue = element.getValue();
    let counter = 0;

    while (currentValue !== text) {
      TouchActions.clickAtCoordinates(0, y);
      driver.pause(250);
      currentValue = element.getValue();
      if (counter === 10) {
        throw new Error(
          `We've clicked a lot in this direction and element wasn't found with selector '${
            element.selector
          }', element may not exist in the pickerwheel.`,
        );
      }
      counter += 1;
    }
  }

  // TODO: there's often not a clear distinction between titles/buttons on a page and the actual screen header
  // maybe we can add some attribute to the screen header component so we can target it more precisely?
  _screenHeader(text: string) {
    return driver.isAndroid
      ? $(`android=new UiSelector().className("android.view.View").text("${text}")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND name == '${text}' AND label == '${text}'`);
  }

  waitForSplashScreen() {
    this.splashScreenLogo.waitForDisplayed(EXTRA_LONG_WAIT, true);
  }

  waitForLoading() {
    this.loadingSpinner.waitForDisplayed(EXTRA_LONG_WAIT, true);
  }

  waitForKeyboardHidden() {
    try {
      driver.waitUntil(
        () => driver.isKeyboardShown() === false,
        SHORT_WAIT,
        'Keyboard is still shown, expected to be hidden',
      );
    } catch (error) {
      driver.hideKeyboard();
    }
  }

  waitForKeyboardShown() {
    driver.waitUntil(() => driver.isKeyboardShown(), SHORT_WAIT, 'Keyboard is hidden, expected to be shown');
  }

  dismissReactWarnings() {
    try {
      TouchActions.clickLowerRight(this.dismissReact);
    } catch (error) {
      // No warnings, that's nice
    }
  }
}
