// @flow

import AppScreen from './app.screen';
import TouchActions from '../interactions/touch.actions';

class GuidedSearchScreen extends AppScreen {
  // NOTE: the guided search screen uses a custom header which is not visible to Appium in iOS,
  // so we actually look for a testID applied to the content wrapper instead of a screen header
  findCareHeader(text: string) {
    return driver.isAndroid ? this.getElementByText(text) : this.getElementByText(`guidedSearch ${text}`);
  }

  // and we also need to use the hardware "go back" functionality
  goBack() {
    TouchActions.hardwareBack();
  }

  get urgentCareHeader() {
    return this.findCareHeader(`Find Urgent Care`);
  }

  get medicalCareHeader() {
    return this.findCareHeader(`Find Medical Care`);
  }

  get mentalCareHeader() {
    return this.findCareHeader(`Find Mental Health Care`);
  }

  get findCareNearHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().textContains("Find Care Near")`)
      : $(`-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS 'Find Care Near'`);
  }

  get kindOfCareHeader() {
    return driver.isAndroid
      ? $(`android=new UiSelector().text("What kind of care do you need?")`)
      : $(`~What kind of care do you need?`);
  }

  get careUnavailable() {
    return driver.isAndroid
      ? $(
          `android=new UiSelector().textContains("We're sorry, Find Mental Health Care is currently unavailable for your healthcare plan.")`,
        )
      : $(
          `-ios predicate string: type == 'XCUIElementTypeOther' AND label CONTAINS "We're sorry, Find Mental Health Care is currently unavailable for your healthcare plan."`,
        );
  }
}

export default new GuidedSearchScreen();
