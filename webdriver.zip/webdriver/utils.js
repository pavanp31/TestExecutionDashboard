// @flow

import fs from 'fs';
import os from 'os';

/**
 * write the current screen's xml representation out to a file to help with building selectors
 */
export function logSource(name: string = 'pageSource') {
  const filename = `${os.homedir()}/Downloads/${name}.${
    driver.isAndroid ? 'android' : 'ios'
  }.xml`;
  fs.writeFileSync(filename, driver.getPageSource());
  // eslint-disable-next-line no-console
  console.log(`file written at: ${filename}`);
}
