// @flow

const { config } = require('./wdio.shared.conf');

// ============
// Specs
// ============
config.specs = ['./tests/**/*.test.js'];

// ============
// Appium Capabilities
// ============
// For all capabilities please check
// http://appium.io/docs/en/writing-running-appium/caps/#general-capabilities
config.capabilities = [
  {
    platformName: 'Android',
    maxInstances: 1,
    appPackage: 'com.mobile.uhc.internal',
    'appium:deviceName': '988d91415456583043',
    'appium:automationName': 'UiAutomator2',
    'appium:appActivity': 'com.mobile.uhc.SplashActivity',
    'appium:appWaitActivity': 'com.mobile.uhc.MainActivity',
    'appium:noReset': true,
    'appium:autoGrantPermissions': true,
    'appium:newCommandTimeout': 240,
  },
];

// ============
// Appium Config https://webdriver.io/docs/appium-service.html
// ============
config.services = [['appium']];
exports.config = config;
