// @flow

const merge = require('deepmerge');
const { config } = require('../wdio.shared.conf');

// ============
// Specs
// ============
config.specs = ['./tests/**/*.test.js'];

// ============
// Appium Capabilities
// ============
// For all capabilities please check
// http://appium.io/docs/en/writing-running-appium/caps/#general-capabilities
config.capabilities = [
  {
    deviceName: 'Android Emulator',
    platformName: 'Android',
    platformVersion: '8.0',
    app: 'sauce-storage:app-release.apk',
    appiumVersion: '1.16.0',
    maxInstances: 1,
    'appium:automationName': 'UiAutomator2',
    'appium:appActivity': 'com.mobile.uhc.SplashActivity',
    'appium:appWaitActivity': 'com.mobile.uhc.MainActivity',
    'appium:noReset': false,
    'appium:autoGrantPermissions': true,
    'appium:newCommandTimeout': 240,
  },
];

// ============
// SauceLabs Config
// ============
config.services = ['sauce'];

// Change local port to Sauce port
delete config.port;

// Sauce Credentials
exports.config = merge(config, {
  // These should be defined locally in .zshrc or .bashrc, or exported to PATH
  user: process.env.SAUCE_USERNAME,
  key: process.env.SAUCE_KEY,
});
