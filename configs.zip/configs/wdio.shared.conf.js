// @flow
/* eslint-disable global-require */
exports.config = {
  // ====================
  // Runner and framework
  // Configuration
  // ====================
  runner: 'local',
  framework: 'jasmine',
  jasmineNodeOpts: {
    // Updated the timeout to 30 seconds due to possible longer appium calls
    // When using XPATH
    defaultTimeoutInterval: 90000,
  },
  hostname: 'localhost',
    port: 4723,
    path: '/wd/hub',
  sync: true,
  logLevel: 'error',
  coloredLogs: true,
  deprecationWarnings: true,
  bail: 0,
  baseUrl: 'https://us-sf.headspin.io:7011/v0/eeb2f2de21cb4061be3a0b7c2fdbfeaf/wd/hub', //'https://us-nyc.headspin.io:7004/v0/eeb2f2de21cb4061be3a0b7c2fdbfeaf/',//'http://localhost',
  waitforTimeout: 16000,
  connectionRetryTimeout: 90000,
  connectionRetryCount: 3,
  reporters: ['spec'],

  // Webdriver services and their configurations
  services: ['appium'],

  // Appium Configuration
  appium: {
    // command to use globally installed Appium
    command: 'appium',
    // For options see
    // https://github.com/webdriverio/webdriverio/tree/master/packages/wdio-appium-service
    args: {

      // For arguments see
      // https://github.com/webdriverio/webdriverio/tree/master/packages/wdio-appium-service
    },
  },

  // Default Appium port
  //port:8200,

  // ====================
  // Some hooks
  // ====================
  beforeSession: () => {
    require('@babel/register');
  },

  // ==============================
  // Placeholders to appease Flow
  // ==============================
  specs: [],
  suites: {
    rx: ['./rx/tests/**/*.test.js'],
    pharmacy: ['./rx/tests/pharmacyLocator/*.test.js'],
    drug: ['./rx/tests/findAndPriceDrug/*.test.js'],
    medCab: ['./rx/tests/*.test.js'],
  },
  capabilities: [],
};
