// @flow

const merge = require('deepmerge');
const { config } = require('./wdio.shared.conf');

// ============
// Specs
// ============
config.specs = ['./tests/**/*.test.js'];

// ============
// Appium Capabilities
// ============
// For all capabilities please check
// http://appium.io/docs/en/writing-running-appium/caps/#general-capabilities
config.capabilities = [
  {
    // deviceName: 'Android Emulator',
    // platformName: 'Android',
    // platformVersion: '8.0',
    // app: 'sauce-storage:app-release.apk',
    // appiumVersion: '1.16.0',
    // maxInstances: 1,
    // 'appium:automationName': 'UiAutomator2',
    // 'appium:appActivity': 'com.mobile.uhc.SplashActivity',
    // 'appium:appWaitActivity': 'com.mobile.uhc.MainActivity',
    // 'appium:noReset': false,
    // 'appium:autoGrantPermissions': true,
    // 'appium:newCommandTimeout': 240,

    // deviceName: 'iPhone',
    // udid: '9baae427cc83233291d6f442c531abb5890f7d06',
    // platformName: 'iOS',
    // automationName: 'XCUITest',
    // useSimpleBuildTest: true,
    // platformVersion: '11.2',
    // bundleId: 'com.apple.Preferences'

  //   {
  //     "deviceName": "LGMP260613de4e5",
  //     "autoAcceptAlerts": "true",
  //     "udid": "LGMP260613de4e5",
  //     "appPackage": "com.android.settings",
  //     "automationName": "UiAutomator2",
  //     "platformName": "Android",
  //     "appActivity": "com.android.settings.Settings"
  // }
    platformName: 'Android',
    maxInstances: 1,
    //noReset: true,
    appPackage: 'com.mobile.uhc.internal',//'com.mobile.uhc.debug',//'com.mobile.uhc',//'com.example.android.myApp',
    'appium:deviceName': '988d91415456583043',
   // 'appium:deviceName': '988bdc3147334e3254',
    //'appium:deviceName': 'us-sf.headspin.io:19694',
    //'appium:udid':'LGMP260613de4e5',
    'appium:automationName': 'UiAutomator2',
    //'appium:apppackage': 'com.mobile.uhc.internal',
    'appium:appActivity': 'com.mobile.uhc.SplashActivity',
    'appium:appWaitActivity': 'com.mobile.uhc.MainActivity',
    'appium:noReset': false,
    'appium:autoGrantPermissions': true,
    'appium:newCommandTimeout': 240,
    'appium:app': 'https://ci.rally-dev.com/teams-care-beta-users/job/care-beta-users/job/UHC_Mobile/job/development/lastSuccessfulBuild/artifact/packages/arcade/android/app/build/outputs/apk/release/app-release.apk',//'/Users/pavan.patel/apk/app-release (2).apk',
    // '/Users/pavan.patel/code/ReactNativeMobileApp/uhc-react-native/packages/arcade/android/app/build/outputs/apk/debug/app-debug.apk',
  },
];

// ============
// Headspin Config https://webdriver.io/docs/appium-service.html
// ============
config.services = [
  ['appium'],
  
  // {
  //   deviceName: 'iPhone',
  //   udid: '9baae427cc83233291d6f442c531abb5890f7d06',
  //   platformName: 'iOS',
  //   automationName: 'XCUITest',
  //   useSimpleBuildTest: true,
  //   platformVersion: '11.2',
  //   bundleId: 'com.apple.Preferences',
  // },
];
//config.baseUrl = "http://localhost:8200";
  //'https://us-nyc.headspin.io:7004/v0/eeb2f2de21cb4061be3a0b7c2fdbfeaf/wd/hub';

// Change local port to Sauce port
//delete config.port;

// Sauce Credentials
exports.config = config;
//  merge(config, {
//   // These should be defined locally in .zshrc or .bashrc, or exported to PATH
//   user: process.env.SAUCE_USERNAME,
//   key: process.env.SAUCE_KEY,
// });
